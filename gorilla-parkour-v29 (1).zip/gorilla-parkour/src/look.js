// Внешность: цвет (радуга) и косметика (можно носить несколько сразу). Хранится на устройстве и передаётся другим игрокам.
export const COLORS = [null, 0xe53935, 0xfb8c00, 0xfdd835, 0x43a047, 0x29b6f6, 0x3f51b5, 0x8e24aa]; // 0 — классический тёмный, дальше цвета радуги
export const SWATCH = ['#17171c', '#e53935', '#fb8c00', '#fdd835', '#43a047', '#29b6f6', '#3f51b5', '#8e24aa'];
export const COS_COUNT = 4; // 0 банан, 1 перчатки, 2 флаг, 3 костюм (биты маски)
const KEY = 'gp_look_v1';
export const colorHex = (c) => COLORS[(c | 0) >= 0 && (c | 0) < COLORS.length ? c | 0 : 0];
export function loadLook() {
  try {
    const o = JSON.parse(localStorage.getItem(KEY) || 'null') || {};
    return { c: Math.max(0, Math.min(COLORS.length - 1, o.c | 0)), k: (o.k | 0) & ((1 << COS_COUNT) - 1) };
  } catch { return { c: 0, k: 0 }; }
}
export function saveLook(l) { try { localStorage.setItem(KEY, JSON.stringify(l)); } catch { /* */ } }
