import * as THREE from 'three';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { World, makeBody, stepBody, P } from './physics.js';
import { generateCourse, FINISH_H, CP_HEIGHTS, TOWER_R, ZONE_NAMES, zoneAt } from './course.js';
import { buildWorld, SKY } from './world.js';
import { createGorilla } from './gorilla.js';
import { cleanNick, loadNick, saveNick, loadSave, writeSave, clearSave, fetchBoard, submitScore, fmtTime } from './store.js';

const $ = (id) => document.getElementById(id);
const canvas = $('c');
const isTouch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
if (!isTouch) document.body.classList.add('desktop');

/* ---------------- рендер ---------------- */
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
const resize = () => {
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  menuCam.aspect = innerWidth / innerHeight; menuCam.updateProjectionMatrix();
};

const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0x8fd3ff, 60, 260);
scene.background = new THREE.Color(0x8fd3ff);
const camera = new THREE.PerspectiveCamera(65, 1, 0.1, 900);
scene.add(new THREE.HemisphereLight(0xffffff, 0x556655, 1.15));
const sun = new THREE.DirectionalLight(0xffffff, 1.4);
sun.position.set(30, 60, 20);
scene.add(sun, sun.target);

// сцена меню: большая горилла
const menuScene = new THREE.Scene();
menuScene.background = new THREE.Color(0x16323f);
menuScene.add(new THREE.HemisphereLight(0xffffff, 0x334455, 1.4));
const menuLight = new THREE.DirectionalLight(0xffe2a8, 1.6); menuLight.position.set(3, 4, 5); menuScene.add(menuLight);
const menuCam = new THREE.PerspectiveCamera(40, 1, 0.1, 50);
menuCam.position.set(0, 1.4, 5.2); menuCam.lookAt(0, 1.1, 0);
const menuGorilla = createGorilla();
menuGorilla.object.scale.setScalar(1.25);
menuScene.add(menuGorilla.object);
const menuFloor = new THREE.Mesh(new THREE.CircleGeometry(3, 40), new THREE.MeshLambertMaterial({ color: 0x244a3a }));
menuFloor.rotation.x = -Math.PI / 2; menuScene.add(menuFloor);

/* ---------------- мир и игрок ---------------- */
const course = generateCourse();
const physWorld = new World(course.solids);
const visuals = buildWorld(course, scene);

const player = createGorilla();
scene.add(player.object);
const body = makeBody();
let facing = 0;

/* ---------------- состояние ---------------- */
let state = 'loading'; // loading | menu | playing | paused | finished
let nick = loadNick();
let cp = -1;           // индекс последнего чекпоинта
let elapsed = 0;       // секунды игры
let maxH = 0;
let saveTimer = 0;
let toastTimer = 0;

const camSt = { yaw: 0, pitch: 0.45, dist: 6.5 };
const keys = {};
let jumpHeld = false;
const stick = { id: null, cx: 0, cy: 0, x: 0, y: 0 };
const look = { id: null, lx: 0, ly: 0 };

/* ---------------- UI ---------------- */
const show = (id, on) => $(id).classList.toggle('hidden', !on);
function toast(text, ms = 2200) {
  const t = $('toast'); t.textContent = text; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), ms);
}
function fillBoard(ol, rows, me) {
  ol.innerHTML = '';
  if (!rows.length) { const li = document.createElement('div'); li.className = 'empty'; li.textContent = 'Пока никто не прошёл. Будь первым!'; ol.appendChild(li); return; }
  rows.forEach((r, i) => {
    const li = document.createElement('li');
    if (me && r.name === me) li.className = 'me';
    const n = document.createElement('span'); n.className = 'n'; n.textContent = i + 1;
    const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = r.name; // textContent — без XSS
    const t = document.createElement('span'); t.className = 't'; t.textContent = fmtTime(r.t);
    li.append(n, nm, t); ol.appendChild(li);
  });
}
async function refreshBoard() { fillBoard($('lbMenu'), await fetchBoard(), nick); }

function refreshMenu() {
  const s = loadSave();
  $('btnPlay').textContent = s && s.cp >= -1 && (s.t > 0 || s.cp >= 0) ? 'ПРОДОЛЖИТЬ' : 'ИГРАТЬ';
  show('btnReset', !!s);
  $('nick').value = nick;
}
function enterMenu() {
  saveProgress();
  state = 'menu';
  ['hud', 'pause', 'confirm', 'finish'].forEach((i) => show(i, false));
  show('menu', true);
  refreshMenu(); refreshBoard();
}

/* ---------------- прогресс ---------------- */
function saveProgress() {
  if (state !== 'playing' && state !== 'paused') return;
  writeSave({ nick, cp, t: elapsed, maxH });
}
function spawnPoint(idx) {
  if (idx < 0) return { x: course.start.x, y: 0.05, z: course.start.z };
  const c = course.checkpoints[idx];
  return { x: c.x, y: c.y + 0.05, z: c.z };
}
function respawn() {
  const p = spawnPoint(cp);
  body.x = p.x; body.y = p.y; body.z = p.z; body.vx = body.vy = body.vz = 0; body.grounded = false;
  // камера смотрит на башню (чтобы увидеть следующую платформу)
  camSt.yaw = Math.atan2(p.x, p.z) + 0.0; // камера «снаружи» от оси башни
  camSt.pitch = 0.45;
  facing = camSt.yaw + Math.PI;
}
function startGame() {
  const s = loadSave();
  const r = cleanNick($('nick').value);
  if (r.length < 2) { $('nickErr').textContent = 'Ник: минимум 2 символа'; $('nick').focus(); return; }
  $('nickErr').textContent = '';
  if (s && s.nick && s.nick !== r) { // другой ник = новая игра
    clearSave(); cp = -1; elapsed = 0; maxH = 0;
  } else if (s) { cp = s.cp; elapsed = s.t; maxH = s.maxH; }
  else { cp = -1; elapsed = 0; maxH = 0; }
  nick = r; saveNick(nick);
  respawn();
  show('menu', false); show('hud', true);
  state = 'playing';
  saveProgress();
  if (cp >= 0) toast('Продолжаем с чекпоинта ' + CP_HEIGHTS[cp] + ' м');
}
function deleteProgress() {
  clearSave(); cp = -1; elapsed = 0; maxH = 0;
  show('confirm', false);
  if (state === 'paused') { respawn(); show('pause', false); state = 'playing'; toast('Прогресс удалён'); }
  else refreshMenu();
}
function pause() { if (state !== 'playing') return; state = 'paused'; saveProgress(); show('pause', true); resetInput(); }
function resume() { if (state !== 'paused') return; show('pause', false); state = 'playing'; }
function quitApp() {
  saveProgress();
  try { if (Capacitor.isNativePlatform()) { CapApp.exitApp(); return; } } catch { /* веб */ }
  window.close();
  $('btnQuit').textContent = 'Можно закрыть вкладку';
}

async function finishGame() {
  state = 'finished';
  const t = elapsed;
  clearSave(); const myNick = nick;
  cp = -1; elapsed = 0; maxH = 0;
  resetInput(); show('hud', false); show('finish', true);
  $('finTime').textContent = fmtTime(t);
  $('finRank').textContent = 'Сохраняю результат…';
  const place = await submitScore(myNick, t);
  $('finRank').textContent = place ? 'Ты на ' + place + ' месте в топ-10!' : 'В топ-10 пока не попал — попробуй быстрее!';
  fillBoard($('lbFinish'), await fetchBoard(), myNick);
}

/* ---------------- ввод ---------------- */
function resetInput() {
  for (const k in keys) keys[k] = false;
  jumpHeld = false; $('jump').classList.remove('down');
  stick.id = look.id = null; stick.x = stick.y = 0;
  $('stick').classList.remove('on'); $('knob').style.transform = '';
}
addEventListener('keydown', (e) => {
  if (e.target && e.target.tagName === 'INPUT') { if (e.key === 'Enter') $('btnPlay').click(); return; }
  if (e.code === 'Escape') { state === 'playing' ? pause() : state === 'paused' ? resume() : 0; return; }
  if (state !== 'playing') return;
  keys[e.code] = true;
  if (e.code === 'Space') { jumpHeld = true; e.preventDefault(); }
  if (e.code === 'KeyR') { respawn(); }
});
addEventListener('keyup', (e) => { keys[e.code] = false; if (e.code === 'Space') jumpHeld = false; });
addEventListener('blur', () => { resetInput(); if (state === 'playing') pause(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) { saveProgress(); if (state === 'playing') pause(); } });
addEventListener('pagehide', saveProgress);

canvas.addEventListener('contextmenu', (e) => e.preventDefault());
canvas.addEventListener('wheel', (e) => { camSt.dist = Math.min(14, Math.max(2.5, camSt.dist + Math.sign(e.deltaY) * 0.6)); }, { passive: true });

// камера и джойстик (как в Roblox: слева — ходьба, справа — вращение камеры)
canvas.addEventListener('pointerdown', (e) => {
  if (state !== 'playing') return;
  if (e.pointerType === 'mouse') { look.id = e.pointerId; look.lx = e.clientX; look.ly = e.clientY; canvas.setPointerCapture(e.pointerId); return; }
  if (e.clientX < innerWidth * 0.45 && stick.id === null) {
    stick.id = e.pointerId; stick.cx = e.clientX; stick.cy = e.clientY; stick.x = stick.y = 0;
    const el = $('stick'); el.style.left = e.clientX - 65 + 'px'; el.style.bottom = 'auto'; el.style.top = e.clientY - 65 + 'px'; el.classList.add('on');
  } else if (look.id === null) { look.id = e.pointerId; look.lx = e.clientX; look.ly = e.clientY; }
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointermove', (e) => {
  if (e.pointerId === look.id) {
    const k = e.pointerType === 'mouse' ? 0.005 : 0.0065;
    camSt.yaw -= (e.clientX - look.lx) * k;
    camSt.pitch = Math.min(1.35, Math.max(-0.25, camSt.pitch + (e.clientY - look.ly) * k));
    look.lx = e.clientX; look.ly = e.clientY;
  } else if (e.pointerId === stick.id) {
    let dx = e.clientX - stick.cx, dy = e.clientY - stick.cy;
    const L = Math.hypot(dx, dy), M = 55;
    if (L > M) { dx = dx / L * M; dy = dy / L * M; }
    stick.x = dx / M; stick.y = -dy / M;
    $('knob').style.transform = `translate(${dx}px,${dy}px)`;
  }
});
const endPtr = (e) => {
  if (e.pointerId === look.id) look.id = null;
  if (e.pointerId === stick.id) { stick.id = null; stick.x = stick.y = 0; $('stick').classList.remove('on'); $('knob').style.transform = ''; }
};
canvas.addEventListener('pointerup', endPtr);
canvas.addEventListener('pointercancel', endPtr);

const jb = $('jump');
jb.addEventListener('pointerdown', (e) => { e.preventDefault(); jumpHeld = true; jb.classList.add('down'); jb.setPointerCapture(e.pointerId); });
const jbUp = () => { jumpHeld = false; jb.classList.remove('down'); };
jb.addEventListener('pointerup', jbUp); jb.addEventListener('pointercancel', jbUp);

$('btnPlay').addEventListener('click', startGame);
$('btnQuit').addEventListener('click', quitApp);
$('btnReset').addEventListener('click', () => show('confirm', true));
$('btnRespawn').addEventListener('click', () => { if (state === 'playing') { respawn(); toast('Респавн'); } });
$('btnPause').addEventListener('click', pause);
$('pResume').addEventListener('click', resume);
$('pRespawn').addEventListener('click', () => { show('pause', false); state = 'playing'; respawn(); });
$('pReset').addEventListener('click', () => show('confirm', true));
$('pMenu').addEventListener('click', enterMenu);
$('cYes').addEventListener('click', deleteProgress);
$('cNo').addEventListener('click', () => show('confirm', false));
$('fMenu').addEventListener('click', enterMenu);
$('nick').addEventListener('input', () => { $('nickErr').textContent = ''; });
try {
  CapApp.addListener('backButton', () => {
    if (!$('confirm').classList.contains('hidden')) show('confirm', false);
    else if (state === 'playing') pause();
    else if (state === 'paused') resume();
    else if (state === 'menu') quitApp();
  });
  CapApp.addListener('pause', () => { saveProgress(); if (state === 'playing') pause(); });
} catch { /* веб-режим */ }

/* ---------------- игровой цикл ---------------- */
const skyTmp = new THREE.Color();
function updateSky(h) {
  let a = SKY[0], b = SKY[SKY.length - 1];
  for (let i = 0; i < SKY.length - 1; i++) if (h >= SKY[i][0] && h <= SKY[i + 1][0]) { a = SKY[i]; b = SKY[i + 1]; break; }
  const t = a === b ? 0 : (h - a[0]) / (b[0] - a[0]);
  skyTmp.copy(a[1]).lerp(b[1], Math.min(1, Math.max(0, t)));
  scene.background.copy(skyTmp); scene.fog.color.copy(skyTmp);
  visuals.stars.material.opacity = Math.min(1, Math.max(0, (h - 650) / 250));
}

function moveInput() {
  let ix = (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0);
  let iy = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0);
  ix += stick.x; iy += stick.y;
  const l = Math.hypot(ix, iy);
  if (l > 1) { ix /= l; iy /= l; }
  if (l < 0.12) return { mx: 0, mz: 0 };
  const s = Math.sin(camSt.yaw), c = Math.cos(camSt.yaw);
  // вперёд = от камеры к игроку (-s, -c); вправо = (c, -s)
  return { mx: -s * iy + c * ix, mz: -c * iy - s * ix };
}

function updateCheckpoints() {
  for (const c of course.checkpoints) {
    if (c.index <= cp) continue;
    if (Math.abs(body.y - c.y) < 0.6 && Math.hypot(body.x - c.x, body.z - c.z) < c.r) {
      if (c.finish) { finishGame(); return; }
      cp = c.index; saveProgress();
      toast('✔ Чекпоинт ' + c.height + ' м — прогресс сохранён');
    }
  }
}

function tickPhysics(dt) {
  const mv = moveInput();
  stepBody(body, { mx: mv.mx, mz: mv.mz, jump: jumpHeld || keys.Space }, dt, physWorld);
  if (body.y < -30) respawn();
  const sp = Math.hypot(body.vx, body.vz);
  if (sp > 0.6) { const target = Math.atan2(body.vx, body.vz); let d = target - facing; d = Math.atan2(Math.sin(d), Math.cos(d)); facing += d * Math.min(1, dt * 14); }
  if (body.y > maxH) maxH = body.y;
  updateCheckpoints();
}

let last = performance.now(), acc = 0, menuT = 0;
const STEP = 1 / 120;
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.1, (now - last) / 1000); last = now;

  if (state === 'menu' || state === 'loading') {
    menuT += dt; menuGorilla.beat(menuT);
    menuGorilla.object.rotation.y = Math.sin(menuT * 0.6) * 0.4;
    renderer.render(menuScene, menuCam);
    return;
  }

  if (state === 'playing') {
    elapsed += dt;
    saveTimer += dt; if (saveTimer > 4) { saveTimer = 0; saveProgress(); }
    acc += dt;
    while (acc >= STEP && state === 'playing') { tickPhysics(STEP); acc -= STEP; }
  }

  // визуал
  const sp = Math.min(1, Math.hypot(body.vx, body.vz) / P.SPEED);
  player.object.position.set(body.x, body.y, body.z);
  player.object.rotation.y = facing;
  player.animate(dt, sp, !body.grounded);

  // камера от третьего лица
  const cx = Math.sin(camSt.yaw) * Math.cos(camSt.pitch), cy = Math.sin(camSt.pitch), cz = Math.cos(camSt.yaw) * Math.cos(camSt.pitch);
  const tx = body.x, ty = body.y + 1.3, tz = body.z;
  let d = camSt.dist;
  while (d > 1.2) { // не пускаем камеру внутрь центральной колонны
    const px = tx + cx * d, pz = tz + cz * d;
    if (Math.hypot(px, pz) > TOWER_R + 0.7) break;
    d -= 0.4;
  }
  camera.position.set(tx + cx * d, ty + cy * d, tz + cz * d);
  camera.lookAt(tx, ty, tz);
  sun.position.set(body.x + 30, body.y + 60, body.z + 20); sun.target.position.set(body.x, body.y, body.z);

  const h = Math.max(0, body.y);
  updateSky(h);
  const t = performance.now() / 1000;
  for (const f of visuals.flags) { f.flag.rotation.y = Math.sin(t * 3 + f.index) * 0.25; f.ring.material.color.set(f.index <= cp ? 0x7dffb3 : 0xffffff); }

  // HUD
  if (state === 'playing') {
    $('meters').firstChild.nodeValue = Math.floor(h) + ' ';
    $('bar').firstChild.style.width = Math.min(100, h / FINISH_H * 100) + '%';
    $('timer').textContent = fmtTime(elapsed, false) + '.' + Math.floor((elapsed % 1) * 10);
    $('zone').textContent = ZONE_NAMES[zoneAt(h)] + (cp >= 0 ? ' · чекпоинт ' + CP_HEIGHTS[cp] + ' м' : '');
  }
  renderer.render(scene, camera);
}

/* ---------------- старт ---------------- */
addEventListener('resize', resize);
resize();
$('nick').value = nick;
requestAnimationFrame((t) => { last = t; frame(t); });
setTimeout(() => { show('loading', false); enterMenu(); }, 400);
