// Сохранения и лидерборд. Всё локально (localStorage); если задан VITE_LEADERBOARD_URL — ещё и общий онлайн-лидерборд.
const KEY_SAVE = 'gp_save_v1';
const KEY_NICK = 'gp_nick_v1';
const KEY_LB = 'gp_lb_v1';
const API = (import.meta.env && import.meta.env.VITE_LEADERBOARD_URL) || '';

const get = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const set = (k, v) => { try { localStorage.setItem(k, v); } catch { /* приватный режим */ } };
const del = (k) => { try { localStorage.removeItem(k); } catch { /* */ } };

export function cleanNick(s) {
  return String(s || '').replace(/[\u0000-\u001f<>&"']/g, '').replace(/\s+/g, ' ').trim().slice(0, 14);
}
export const loadNick = () => cleanNick(get(KEY_NICK) || '');
export const saveNick = (n) => set(KEY_NICK, cleanNick(n));

// { nick, cp: индекс последнего чекпоинта (-1 — старт), t: секунды, maxH }
export function loadSave() {
  try {
    const o = JSON.parse(get(KEY_SAVE) || 'null');
    if (!o || typeof o.t !== 'number') return null;
    return { nick: cleanNick(o.nick), cp: Math.max(-1, Math.min(6, o.cp | 0)), t: Math.max(0, o.t), maxH: Math.max(0, +o.maxH || 0) };
  } catch { return null; }
}
export const writeSave = (s) => set(KEY_SAVE, JSON.stringify(s));
export const clearSave = () => del(KEY_SAVE);

function localBoard() {
  try {
    const a = JSON.parse(get(KEY_LB) || '[]');
    return Array.isArray(a) ? a.filter((e) => e && typeof e.t === 'number') : [];
  } catch { return []; }
}
const sortTop = (a) => a.slice().sort((x, y) => x.t - y.t).slice(0, 10);

export async function fetchBoard() {
  const local = sortTop(localBoard());
  if (!API) return local;
  try {
    const r = await fetch(API.replace(/\/$/, '') + '/api/leaderboard', { cache: 'no-store' });
    if (!r.ok) throw new Error(String(r.status));
    const remote = await r.json();
    return sortTop(remote.map((e) => ({ name: cleanNick(e.name), t: +e.t })).filter((e) => e.name && e.t > 0));
  } catch { return local; }
}

// Возвращает место в топе (1..10) или 0
export async function submitScore(name, t) {
  const all = localBoard();
  all.push({ name, t, d: Date.now() });
  set(KEY_LB, JSON.stringify(sortTop(all)));
  if (API) {
    try {
      await fetch(API.replace(/\/$/, '') + '/api/score', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, t }),
      });
    } catch { /* офлайн — останется только локальная запись */ }
  }
  const board = await fetchBoard();
  const i = board.findIndex((e) => e.name === name && Math.abs(e.t - t) < 0.01);
  return i >= 0 ? i + 1 : 0;
}

export function fmtTime(t, cs = true) {
  const m = Math.floor(t / 60), s = t - m * 60;
  const sec = cs ? s.toFixed(2).padStart(5, '0') : Math.floor(s).toString().padStart(2, '0');
  return String(m).padStart(2, '0') + ':' + sec;
}
