// Необязательный общий лидерборд (без зависимостей). Запуск: node server/server.js
// API: GET /api/leaderboard -> [{name,t}], POST /api/score {name,t}
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const FILE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'scores.json');
const MIN_TIME = 240; // быстрее 4 минут пройти нереально — отсекаем явные подделки
const load = () => { try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return []; } };
const top = (a) => a.sort((x, y) => x.t - y.t).slice(0, 10);
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' };

http.createServer((req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
  if (req.url === '/api/leaderboard' && req.method === 'GET') {
    res.writeHead(200, { ...cors, 'Content-Type': 'application/json' });
    return res.end(JSON.stringify(top(load())));
  }
  if (req.url === '/api/score' && req.method === 'POST') {
    let b = '';
    req.on('data', (c) => { b += c; if (b.length > 1000) req.destroy(); });
    req.on('end', () => {
      try {
        const { name, t } = JSON.parse(b);
        const n = String(name || '').replace(/[\u0000-\u001f<>&"']/g, '').trim().slice(0, 14);
        if (n.length < 2 || !(t >= MIN_TIME) || t > 86400) throw new Error('bad');
        const all = load(); all.push({ name: n, t: +t });
        fs.writeFileSync(FILE, JSON.stringify(top(all)));
        res.writeHead(200, cors); res.end('ok');
      } catch { res.writeHead(400, cors); res.end('bad'); }
    });
    return;
  }
  res.writeHead(404, cors); res.end();
}).listen(process.env.PORT || 3000, () => console.log('leaderboard on :' + (process.env.PORT || 3000)));
