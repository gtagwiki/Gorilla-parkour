// Оригинальный персонаж «Горилла» по рисунку автора: круглое тело, тёмная шерсть, светлая морда,
// коричневые уши и живот, длинные руки. Собран из простых фигур.
import * as THREE from 'three';

export function createGorilla(tint) {
  const col = (hex) => new THREE.MeshLambertMaterial({ color: hex, flatShading: true });
  const fur = col(tint ?? 0x17171c);
  const furLight = col(tint != null ? new THREE.Color(tint).multiplyScalar(1.5).getHex() : 0x2c2c33);
  const tan = col(0xb98a6a);      // живот и уши
  const face = col(0xece6dc);     // светлая морда
  const tips = col(0xa89a8c);     // кончики пальцев
  const black = new THREE.MeshBasicMaterial({ color: 0x0b0b0d });

  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  const add = (geo, mat, x = 0, y = 0, z = 0, parent = body, sx = 1, sy = 1, sz = 1) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z); m.scale.set(sx, sy, sz);
    parent.add(m);
    return m;
  };
  const ball = (r) => new THREE.SphereGeometry(r, 16, 12);

  // туловище: широкая «груша» + плечи
  add(ball(0.62), fur, 0, 0.98, 0, body, 1.0, 0.98, 0.82);
  add(ball(0.5), fur, 0, 1.42, 0, body, 1.3, 0.66, 0.82);
  add(ball(0.5), tan, 0, 1.0, 0.36, body, 0.82, 1.02, 0.4);   // коричневый живот
  add(ball(0.4), furLight, 0, 0.62, -0.02, body, 1.1, 0.7, 0.9);

  // голова
  const head = new THREE.Group();
  head.position.set(0, 1.82, 0.08);
  body.add(head);
  add(ball(0.32), fur, 0, 0, 0, head);
  add(ball(0.3), face, 0, -0.04, 0.12, head, 0.72, 0.9, 0.55);   // светлая морда-овал
  for (const sx of [-1, 1]) {
    add(ball(0.12), tan, sx * 0.34, 0.06, -0.02, head, 1, 1, 0.55);        // уши
    add(ball(0.045), black, sx * 0.1, 0.07, 0.3, head);                      // глаза
  }
  add(new THREE.BoxGeometry(0.22, 0.06, 0.05), black, 0, -0.04, 0.33, head); // «усы»/нос
  add(new THREE.BoxGeometry(0.12, 0.035, 0.05), black, 0, -0.13, 0.31, head); // рот

  // руки (длинные) — пивот в плече; на рисунке раскинуты в стороны
  const arms = [];
  for (const sx of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(sx * 0.78, 1.46, 0);
    body.add(pivot);
    add(new THREE.CapsuleGeometry(0.15, 0.85, 4, 10), fur, 0, -0.58, 0, pivot);
    add(ball(0.2), fur, 0, -1.16, 0.02, pivot);
    add(ball(0.11), tips, 0, -1.3, 0.05, pivot, 1.3, 0.8, 1);                // светлые кончики пальцев
    arms.push(pivot);
  }
  // ноги
  const legs = [];
  for (const sx of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(sx * 0.3, 0.6, 0);
    body.add(pivot);
    add(new THREE.CapsuleGeometry(0.19, 0.3, 4, 8), fur, 0, -0.28, 0, pivot);
    add(new THREE.BoxGeometry(0.3, 0.14, 0.42), furLight, 0, -0.55, 0.08, pivot);
    legs.push(pivot);
  }

  body.rotation.x = 0.06;
  let phase = 0;

  return {
    object: root,
    // speed 0..1, air — в воздухе
    animate(dt, speed, air) {
      phase += dt * (6 + speed * 8);
      const s = Math.sin(phase);
      if (air) { // в прыжке руки раскинуты в стороны, как на рисунке
        arms[0].rotation.x = arms[1].rotation.x = 0;
        arms[0].rotation.z = -1.25; arms[1].rotation.z = 1.25;
        legs[0].rotation.x = -0.5; legs[1].rotation.x = 0.4;
      } else {
        const a = speed * 0.9;
        arms[0].rotation.x = s * a; arms[1].rotation.x = -s * a;
        arms[0].rotation.z = -0.12; arms[1].rotation.z = 0.12;
        legs[0].rotation.x = -s * a; legs[1].rotation.x = s * a;
      }
      body.position.y = air ? 0 : Math.abs(Math.sin(phase)) * 0.06 * speed;
      head.rotation.y = 0;
    },
    // меню: руки раскинуты и слегка покачиваются
    beat(t) {
      arms[0].rotation.x = arms[1].rotation.x = 0;
      arms[0].rotation.z = -1.35 + Math.sin(t * 3) * 0.12;
      arms[1].rotation.z = 1.35 - Math.sin(t * 3 + 1) * 0.12;
      body.position.y = Math.abs(Math.sin(t * 3)) * 0.04;
      head.rotation.y = Math.sin(t * 1.3) * 0.35;
      legs[0].rotation.x = legs[1].rotation.x = 0;
    },
  };
}
