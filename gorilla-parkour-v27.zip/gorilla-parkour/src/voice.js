// Голосовой чат по расстоянию: WebRTC напрямую между игроками, сигналы идут через Firebase.
import { applyEvent, dbUrl } from './net.js';
import { TURN } from './config.js';

const ICE = { iceServers: [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }, ...(TURN ? [TURN] : [])] };
const MAX_PEERS = 5, NEAR = 40, FAR = 60, STUCK_MS = 20000;
const ID_RE = /^GP-[A-Z0-9]{6}$/;

export function createVoice() {
  let room = '', me = '', stream = null, es = null, tree = {}, on = false, muted = false;
  const peers = new Map(); // id -> { pc, audio, initiator, queue, remoteSet, since }
  const done = new Set();

  const sig = (to, k, d) => fetch(dbUrl(`voice/${room}/sig/${to}/${me}`), { method: 'POST', body: JSON.stringify({ k, d: JSON.stringify(d), t: Date.now() }) }).catch(() => {});
  const wipe = (from, key) => fetch(dbUrl(`voice/${room}/sig/${me}/${from}/${key}`), { method: 'DELETE' }).catch(() => {});

  function closePeer(id) {
    const p = peers.get(id); if (!p) return;
    peers.delete(id);
    try { p.pc.close(); } catch { /* */ }
    if (p.audio) { p.audio.pause(); p.audio.srcObject = null; }
  }

  function makePeer(id, initiator) {
    closePeer(id);
    const pc = new RTCPeerConnection(ICE);
    const p = { pc, audio: null, initiator, queue: [], remoteSet: false, since: Date.now() };
    peers.set(id, p);
    for (const tr of stream.getTracks()) pc.addTrack(tr, stream);
    pc.onicecandidate = (e) => { if (e.candidate) sig(id, 'ice', e.candidate.toJSON()); };
    pc.ontrack = (e) => {
      if (!p.audio) { p.audio = new Audio(); p.audio.autoplay = true; }
      p.audio.srcObject = e.streams[0]; p.audio.play().catch(() => {});
    };
    pc.onconnectionstatechange = () => { if (['failed', 'closed', 'disconnected'].includes(pc.connectionState)) setTimeout(() => { if (peers.get(id) === p && pc.connectionState !== 'connected') closePeer(id); }, 1500); };
    if (initiator) {
      pc.createOffer().then((o) => pc.setLocalDescription(o)).then(() => sig(id, 'offer', pc.localDescription.toJSON())).catch(() => closePeer(id));
    }
    return p;
  }

  async function handle(from, m) {
    if (!on || !ID_RE.test(from)) return;
    let d; try { d = JSON.parse(m.d); } catch { return; }
    if (m.k === 'offer') {
      if (peers.size >= MAX_PEERS && !peers.has(from)) return;
      const p = makePeer(from, false);
      try {
        await p.pc.setRemoteDescription(d); p.remoteSet = true;
        for (const c of p.queue) await p.pc.addIceCandidate(c).catch(() => {});
        p.queue = [];
        const a = await p.pc.createAnswer(); await p.pc.setLocalDescription(a);
        sig(from, 'answer', p.pc.localDescription.toJSON());
      } catch { closePeer(from); }
    } else if (m.k === 'answer') {
      const p = peers.get(from); if (!p || !p.initiator || p.remoteSet) return;
      try {
        await p.pc.setRemoteDescription(d); p.remoteSet = true;
        for (const c of p.queue) await p.pc.addIceCandidate(c).catch(() => {});
        p.queue = [];
      } catch { closePeer(from); }
    } else if (m.k === 'ice') {
      const p = peers.get(from); if (!p) return;
      if (p.remoteSet) p.pc.addIceCandidate(d).catch(() => {}); else p.queue.push(d);
    }
  }

  function process() {
    const now = Date.now();
    for (const [from, box] of Object.entries(tree)) {
      if (!box || typeof box !== 'object') continue;
      for (const key of Object.keys(box).sort()) {
        const id = from + '/' + key;
        if (done.has(id)) continue;
        done.add(id);
        const m = box[key];
        wipe(from, key);
        if (!m || typeof m.k !== 'string' || typeof m.d !== 'string' || now - (+m.t || 0) > 30000) continue;
        handle(from, m);
      }
    }
    if (done.size > 2000) done.clear();
  }

  function listen() {
    es = new EventSource(dbUrl(`voice/${room}/sig/${me}`));
    const onEv = (type) => (e) => { try { const m = JSON.parse(e.data); tree = applyEvent(tree, type, m.path, m.data); process(); } catch { /* */ } };
    es.addEventListener('put', onEv('put'));
    es.addEventListener('patch', onEv('patch'));
  }

  return {
    isOn: () => on,
    isMuted: () => muted,
    count: () => [...peers.values()].filter((p) => p.pc.connectionState === 'connected').length,
    async start(r, id) {
      if (on) return;
      stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false });
      room = r; me = id; on = true; muted = false; tree = {}; done.clear();
      listen();
    },
    setMuted(m) { muted = m; if (stream) stream.getAudioTracks().forEach((tr) => { tr.enabled = !m; }); },
    // players: [{id,x,y,z,v}], pos: {x,y,z}; вызывать раз в ~0.5 с
    update(players, pos) {
      if (!on) return;
      const now = Date.now(), near = [];
      for (const p of players) {
        if (!p.v) continue;
        const dist = Math.hypot(p.x - pos.x, p.y - pos.y, p.z - pos.z);
        near.push({ id: p.id, dist });
      }
      near.sort((a, b) => a.dist - b.dist);
      const want = new Set();
      for (const n of near) {
        const have = peers.get(n.id);
        if (have ? n.dist < FAR : n.dist < NEAR && want.size < MAX_PEERS) want.add(n.id);
        if (have && have.audio) have.audio.volume = Math.max(0, Math.min(1, 1 - n.dist / FAR));
      }
      for (const id of [...peers.keys()]) {
        const p = peers.get(id);
        if (!want.has(id)) { closePeer(id); continue; }
        if (p.pc.connectionState !== 'connected' && now - p.since > STUCK_MS) closePeer(id);
      }
      for (const n of near) { // звонит тот, у кого ID «меньше» — чтобы не было встречных предложений
        if (want.has(n.id) && !peers.has(n.id) && me < n.id) makePeer(n.id, true);
      }
    },
    stop() {
      if (!on && !stream) return;
      on = false;
      for (const id of [...peers.keys()]) closePeer(id);
      try { es && es.close(); } catch { /* */ }
      es = null; tree = {};
      if (stream) { stream.getTracks().forEach((tr) => tr.stop()); stream = null; }
      if (room && me) fetch(dbUrl(`voice/${room}/sig/${me}`), { method: 'DELETE', keepalive: true }).catch(() => {});
    },
  };
}
