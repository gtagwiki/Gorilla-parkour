// Лабиринт хоррор-режима. Детерминированный (seed) — у всех игроков одинаковый.
export const N = 15, W = 2 * N + 1, S = 3, H = 3.4; // клеток, блоков, метров на блок, высота
export const EXIT = [1, 1];            // выход «B» — левый верхний угол
export const START = [W - 2, W - 2];   // старт — правый нижний угол
export const ZONES = [[3, 3], [11, 6], [5, 11]]; // центры трёх кругов (в клетках)
const D4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];

function rng(a) {
  return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}

export function buildMaze(seed = 1337) {
  const r = rng(seed), G = Array.from({ length: W }, () => Array(W).fill(1));
  const vis = Array.from({ length: N }, () => Array(N).fill(false));
  vis[N - 1][N - 1] = true; G[W - 2][W - 2] = 0;
  const st = [[N - 1, N - 1]];
  while (st.length) {
    const [cx, cy] = st[st.length - 1];
    const nb = D4.map(([dx, dy]) => [cx + dx, cy + dy, dx, dy])
      .filter(([x, y]) => x >= 0 && y >= 0 && x < N && y < N && !vis[y][x]);
    if (!nb.length) { st.pop(); continue; }
    const [x, y, dx, dy] = nb[(r() * nb.length) | 0];
    vis[y][x] = true; G[2 * y + 1][2 * x + 1] = 0; G[2 * cy + 1 + dy][2 * cx + 1 + dx] = 0; st.push([x, y]);
  }
  for (let j = 1; j < W - 1; j++) for (let i = 1; i < W - 1; i++)
    if (G[j][i] === 1 && (i + j) % 2 === 1 && r() < 0.09) G[j][i] = 0; // петли
  return G;
}

export function bfs(G, si, sj) {
  const d = new Int16Array(W * W).fill(-1), p = new Int16Array(W * W).fill(-1), q = [si + sj * W];
  d[q[0]] = 0;
  for (let h = 0; h < q.length; h++) {
    const c = q[h], x = c % W, y = (c / W) | 0;
    for (const [dx, dy] of D4) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= W || G[ny][nx]) continue;
      const k = nx + ny * W;
      if (d[k] < 0) { d[k] = d[c] + 1; p[k] = c; q.push(k); }
    }
  }
  return { d, p, q };
}

// Маршруты монстров (красные линии): от центра круга до клетки в 12 блоках от него
export function patrols(G) {
  return ZONES.map(([cx, cy]) => {
    const si = 2 * cx + 1, sj = 2 * cy + 1, { d, p, q } = bfs(G, si, sj);
    let t = q[0];
    for (const k of q) { if (d[k] <= 12) t = k; else break; }
    const path = [];
    for (let k = t; k >= 0; k = p[k]) path.push([k % W, (k / W) | 0]);
    return { zi: si, zj: sj, path: path.reverse() };
  });
}
