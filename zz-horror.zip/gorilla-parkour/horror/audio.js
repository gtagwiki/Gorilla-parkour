// Процедурные звуки хоррора (без файлов): ветер, гул, жуткие шорохи, крики монстров.
export function createAudio() {
  const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null;
  const ctx = new AC(), out = ctx.createGain(); out.gain.value = 0.9; out.connect(ctx.destination);
  const nb = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate), nd = nb.getChannelData(0);
  for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
  const noise = () => { const s = ctx.createBufferSource(); s.buffer = nb; s.loop = true; return s; };
  const lfo = (hz, depth, param) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = hz; g.gain.value = depth; o.connect(g); g.connect(param); o.start(); return o; };
  const filt = (type, f, q = 1) => { const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q; return b; };
  const gain = (v) => { const g = ctx.createGain(); g.gain.value = v; return g; };
  const pan = (v) => { if (!ctx.createStereoPanner) return gain(1); const p = ctx.createStereoPanner(); p.pan.value = v; return p; };
  const loops = [];

  // страшный ветер: свистящий шум + низкий гул + вой
  const w = noise(), wb = filt('bandpass', 500, 0.7), wg = gain(0.22); w.connect(wb); wb.connect(wg); wg.connect(out); w.start(); loops.push(w);
  loops.push(lfo(0.13, 300, wb.frequency), lfo(0.07, 0.12, wg.gain));
  const r = noise(), rl = filt('lowpass', 180), rg = gain(0.3); r.connect(rl); rl.connect(rg); rg.connect(out); r.start(); loops.push(r, lfo(0.05, 0.1, rg.gain));
  const h = ctx.createOscillator(), hg = gain(0.03); h.type = 'sine'; h.frequency.value = 420; h.connect(hg); hg.connect(out); h.start(); loops.push(h, lfo(0.09, 150, h.frequency), lfo(0.11, 0.025, hg.gain));
  // тревожный гул
  const dl = filt('lowpass', 140), dg = gain(0.07); dl.connect(dg); dg.connect(out);
  for (const f of [48, 51.5]) { const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f; o.connect(dl); o.start(); loops.push(o); }
  loops.push(lfo(0.2, 0.03, dg.gain));

  // случайные жуткие звуки раз в 6–18 секунд
  const oneShot = () => {
    const t = ctx.currentTime, k = (Math.random() * 3) | 0, p = pan(Math.random() * 1.6 - 0.8); p.connect(out);
    if (k === 0) { // скрип
      const o = ctx.createOscillator(), f = filt('bandpass', 400, 6), g = gain(0), f0 = 90 + Math.random() * 80, d = 1.2 + Math.random();
      o.type = 'sawtooth'; o.frequency.setValueAtTime(f0, t); o.frequency.linearRampToValueAtTime(f0 * (0.6 + Math.random() * 0.9), t + d);
      g.gain.linearRampToValueAtTime(0.14, t + 0.3); g.gain.linearRampToValueAtTime(0, t + d); o.connect(f); f.connect(g); g.connect(p); o.start(t); o.stop(t + d + 0.1);
    } else if (k === 1) { // шёпот
      const n = noise(), f = filt('bandpass', 2000, 3), g = gain(0); f.frequency.linearRampToValueAtTime(3200, t + 1.6);
      g.gain.linearRampToValueAtTime(0.16, t + 0.5); g.gain.linearRampToValueAtTime(0, t + 1.6); n.connect(f); f.connect(g); g.connect(p); n.start(t); n.stop(t + 1.7);
    } else { // глухие удары
      for (const dt of [0, 0.28]) { const o = ctx.createOscillator(), g = gain(0); o.frequency.value = 55; g.gain.setValueAtTime(0, t + dt);
        g.gain.linearRampToValueAtTime(0.6, t + dt + 0.03); g.gain.exponentialRampToValueAtTime(0.001, t + dt + 0.3); o.connect(g); g.connect(p); o.start(t + dt); o.stop(t + dt + 0.35); }
    }
  };
  let timer = 0; const tick = () => { if (ctx.state === 'running') oneShot(); timer = setTimeout(tick, 6000 + Math.random() * 12000); }; timer = setTimeout(tick, 3000);

  const shape = ctx.createWaveShaper(), curve = new Float32Array(256); for (let i = 0; i < 256; i++) curve[i] = Math.tanh((i / 128 - 1) * 4); shape.curve = curve;
  // крик монстра в точке (x,y,z); loud — громкость
  const scream = (x, y, z, loud = 1) => {
    const t = ctx.currentTime, d = 1.1 + Math.random() * 0.6, base = 380 + Math.random() * 150, pn = ctx.createPanner();
    pn.panningModel = 'HRTF'; pn.distanceModel = 'inverse'; pn.refDistance = 3; pn.rolloffFactor = 1.2; pn.maxDistance = 60;
    if (pn.positionX) { pn.positionX.value = x; pn.positionY.value = y; pn.positionZ.value = z; } else pn.setPosition(x, y, z);
    const g = gain(0), mix = gain(1), ws = ctx.createWaveShaper(); ws.curve = curve;
    g.gain.linearRampToValueAtTime(0.9 * loud, t + 0.08); g.gain.exponentialRampToValueAtTime(0.001, t + d);
    const stop = [];
    for (const type of ['sawtooth', 'square']) { const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(base, t);
      o.frequency.linearRampToValueAtTime(base * 2.2, t + 0.35); o.frequency.linearRampToValueAtTime(base * 0.6, t + d); o.connect(mix); stop.push(o); }
    const wob = ctx.createOscillator(), wg = gain(40); wob.frequency.value = 30; wob.connect(wg); wg.connect(stop[0].frequency); stop.push(wob);
    const n = noise(), ng = gain(0.5); n.connect(ng); ng.connect(mix); stop.push(n);
    mix.connect(ws); for (const f of [filt('bandpass', 900, 4), filt('bandpass', 2200, 4)]) { ws.connect(f); f.connect(g); }
    g.connect(pn); pn.connect(out); for (const s of stop) { s.start(t); s.stop(t + d + 0.1); }
  };
  const update = (x, y, z, dir) => { const L = ctx.listener;
    if (L.positionX) { L.positionX.value = x; L.positionY.value = y; L.positionZ.value = z; L.forwardX.value = dir.x; L.forwardY.value = dir.y; L.forwardZ.value = dir.z; L.upX.value = 0; L.upY.value = 1; L.upZ.value = 0; }
    else { L.setPosition(x, y, z); L.setOrientation(dir.x, dir.y, dir.z, 0, 1, 0); } };
  return { scream, update, resume: () => { if (ctx.state !== 'running') ctx.resume().catch(() => {}); }, close: () => { clearTimeout(timer); ctx.close().catch(() => {}); } };
}
