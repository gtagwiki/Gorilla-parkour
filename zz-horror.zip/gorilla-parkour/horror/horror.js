// Хоррор-режим Gorilla Parkour: от 1-го лица, лабиринт, 3 монстра, мультиплеер (3 игрока, 10 серверов).
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { W, S, H, EXIT, START, buildMaze, bfs, patrols } from './maze.js';

const DB = 'https://gorilla-parkour-default-rtdb.firebaseio.com';
const SERVERS = 10, MAXP = 3, SPAWN_R = 14, LEAVE_R = 20; // радиусы в блоках (20 блоков = 10 клеток)
const SPEED = 4.2, TURBO_X = 5, TURBO_T = 10, TURBO_CD = 90, LAMP_T = 180, MON_SPEED = 1.3;
const LIFE_TOUCH = 2; // сколько жизней снимает монстр при касании (поменяй, если нужно)
const SAVE_KEY = 'gp_horror_v1';

const $ = (id) => document.getElementById(id);
const ls = (k, v) => { try { return v === undefined ? localStorage.getItem(k) : localStorage.setItem(k, v); } catch { return null; } };
const api = (p, m = 'GET', b) => fetch(`${DB}/${p}.json`, { method: m, cache: 'no-store', keepalive: m !== 'GET',
  body: b === undefined ? undefined : JSON.stringify(b) }).then((r) => { if (!r.ok) throw r.status; return r.json(); });
const pid = () => {
  let id = ls('gp_id_v1');
  if (!/^GP-[A-Z0-9]{6}$/.test(id || '')) { const a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    id = 'GP-' + Array.from({ length: 6 }, () => a[(Math.random() * a.length) | 0]).join(''); ls('gp_id_v1', id); }
  return id;
};
const nick = () => ($('nick') && $('nick').value.trim()) || ls('gp_nick_v1') || 'Player';

const css = document.createElement('style');
css.textContent = `
#hz,#hzSel{position:fixed;inset:0;z-index:9999;background:#000;color:#f4f1ea;font-family:system-ui,sans-serif;touch-action:none;user-select:none;-webkit-user-select:none}
#hz canvas{position:absolute;inset:0;width:100%;height:100%}
#hz button,#hzSel button{font:inherit;font-weight:700;border:0;border-radius:12px;padding:12px 16px;color:#1b1200;background:linear-gradient(#ffb703,#fb8500)}
#hz .b{position:absolute;min-width:92px;min-height:60px;opacity:.9}#hzT{right:16px;bottom:96px}#hzF{right:16px;bottom:20px}
#hzX{left:12px;top:12px;min-width:0!important;min-height:0!important;padding:8px 12px!important;background:rgba(255,255,255,.2)!important;color:#fff!important}
#hzHud{position:absolute;top:10px;left:0;right:0;text-align:center;font-size:20px;text-shadow:0 2px 4px #000;pointer-events:none}
#hzBar{width:180px;height:10px;margin:4px auto;background:#300;border-radius:6px;overflow:hidden}#hzBar i{display:block;height:100%;background:#e53935}
#hzStick{position:absolute;left:30px;bottom:30px;width:120px;height:120px;border-radius:50%;background:rgba(255,255,255,.1);border:2px solid rgba(255,255,255,.25)}
#hzKnob{position:absolute;left:40px;top:40px;width:40px;height:40px;border-radius:50%;background:rgba(255,255,255,.45)}
#hzMsg{pointer-events:none;position:absolute;inset:0;display:none;align-items:center;justify-content:center;font-size:38px;font-weight:800;text-align:center;background:rgba(0,0,0,.6)}
#hzRed{position:absolute;inset:0;background:#c00;opacity:0;pointer-events:none;transition:opacity .5s}
#hzSel{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;background:rgba(8,8,12,.96)}
#hzSel .g{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;width:min(640px,94vw)}#hzSel button:disabled{opacity:.4}`;
document.head.appendChild(css);

let g = null; // состояние активной игры
let glb = null;
new GLTFLoader().load(new URL('./character.glb', import.meta.url).href, (r) => { glb = r.scene; }, undefined, () => {});

// ---------- меню: кнопка + выбор сервера ----------
function injectButton() {
  const m = $('menuMain'), play = $('btnPlay');
  if (!m || !play || $('btnHorror')) return;
  const b = document.createElement('button');
  b.id = 'btnHorror'; b.className = 'sec'; b.textContent = '👁 ХОРРОР';
  b.onclick = openSelect; m.insertBefore(b, play.nextSibling);
}

async function openSelect() {
  if (g || $('hzSel')) return;
  const el = document.createElement('div'); el.id = 'hzSel';
  el.innerHTML = '<h2 style="margin:0">👁 Хоррор — выбери сервер</h2><div class="g"></div><button id="hzBack" style="background:rgba(255,255,255,.15);color:#fff">Назад</button>';
  document.body.appendChild(el);
  $('hzBack').onclick = () => el.remove();
  const grid = el.querySelector('.g'), now = Date.now();
  for (let i = 1; i <= SERVERS; i++) {
    const b = document.createElement('button'); b.textContent = `${i} S`; grid.appendChild(b);
    api(`horror/s${i}/slots`).catch(() => null).then((pl) => {
      const n = Object.values(pl || {}).filter((v) => v && now - v.t < 15000).length;
      b.textContent = `${i} S · ${n}/${MAXP}`; b.disabled = n >= MAXP;
      b.onclick = () => { el.remove(); start(i); };
    });
  }
}

async function start(i) {
  const room = 's' + i, id = pid(), name = nick().slice(0, 14), now = Date.now();
  let slot = -1;
  try {
    const sl = (await api(`horror/${room}/slots`).catch(() => null)) || {};
    const order = [0, 1, 2].sort((p, q) => (sl[p] && sl[p].id === id ? -1 : 0) - (sl[q] && sl[q].id === id ? -1 : 0));
    for (const k of order) {
      const v = sl[k]; if (v && v.id !== id && now - v.t < 15000) continue;
      try { await api(`horror/${room}/slots/${k}`, 'PUT', { id, n: name, x: START[0] * S, z: START[1] * S, r: 0, t: Date.now() }); slot = k; break; } catch (e) { if (e !== 401 && e !== 403) throw e; }
    }
  } catch (e) { return alert('Не удалось войти на сервер (' + e + '). Проверь правила Firebase для horror.'); }
  if (slot < 0) return alert('Сервер полон');
  let saved = null;
  try { saved = JSON.parse(ls(SAVE_KEY) || 'null'); } catch {}
  if (!saved) saved = await api(`horrorProgress/${id}`).catch(() => null);
  run(room, id, name, i, saved, slot);
}

// ---------- игра ----------
function run(room, id, name, sv, saved, slot) {
  const release = () => api(`horror/${room}/slots/${slot}`, 'PUT', { id, n: '', x: 0, z: 0, r: 0, t: 0 }).catch(() => {});
  const G = buildMaze(), pats = patrols(G);
  const solid = (x, z) => { const i = Math.floor(x / S), j = Math.floor(z / S); return i < 0 || j < 0 || i >= W || j >= W || G[j][i] === 1; };
  const blocked = (x, z) => { const r = 0.45; return solid(x - r, z - r) || solid(x + r, z - r) || solid(x - r, z + r) || solid(x + r, z + r); };

  const root = document.createElement('div'); root.id = 'hz';
  root.innerHTML = `<canvas></canvas><div id="hzRed"></div><div id="hzHud"><div id="hzLife"></div><div id="hzBar"><i></i></div><div id="hzInfo"></div></div>
    <button id="hzX">☰ Выход</button><div id="hzStick"><div id="hzKnob"></div></div>
    <button class="b" id="hzT">⚡ ТУРБО</button><button class="b" id="hzF">🔦 ФОНАРИК</button><div id="hzMsg"></div>`;
  document.body.appendChild(root);
  const menu = $('menu'); if (menu) menu.classList.add('hidden');

  const renderer = new THREE.WebGLRenderer({ canvas: root.querySelector('canvas') });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0); scene.fog = new THREE.FogExp2(0, 0.09);
  const cam = new THREE.PerspectiveCamera(75, 1, 0.05, 60); cam.rotation.order = 'YXZ'; scene.add(cam);
  scene.add(new THREE.AmbientLight(0x2a2a40, 0.25));
  const lamp = new THREE.SpotLight(0xfff2cc, 90, 28, 0.55, 0.5, 1.6); cam.add(lamp); cam.add(lamp.target); lamp.target.position.set(0, 0, -1);

  const walls = G.flat().filter(Boolean).length;
  const im = new THREE.InstancedMesh(new THREE.BoxGeometry(S, H, S), new THREE.MeshStandardMaterial({ color: 0x4a4a52, roughness: 0.95 }), walls);
  const m4 = new THREE.Matrix4(); let k = 0;
  for (let j = 0; j < W; j++) for (let i = 0; i < W; i++) if (G[j][i]) { m4.setPosition((i + 0.5) * S, H / 2, (j + 0.5) * S); im.setMatrixAt(k++, m4); }
  scene.add(im);
  const plane = (y, rx, c) => { const p = new THREE.Mesh(new THREE.PlaneGeometry(W * S, W * S), new THREE.MeshStandardMaterial({ color: c, roughness: 1 }));
    p.rotation.x = rx; p.position.set(W * S / 2, y, W * S / 2); scene.add(p); };
  plane(0, -Math.PI / 2, 0x1c1c20); plane(H, Math.PI / 2, 0x141416);

  const label = (t, c, w) => { const cv = document.createElement('canvas'); cv.width = 256; cv.height = 96; const x = cv.getContext('2d');
    x.font = 'bold 48px sans-serif'; x.textAlign = 'center'; x.lineWidth = 6; x.strokeStyle = '#000'; x.fillStyle = c; x.strokeText(t, 128, 64); x.fillText(t, 128, 64);
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(cv), transparent: true, fog: false })); s.scale.set(w, w * 0.375, 1); return s; };
  const ex = new THREE.Group(); ex.position.set((EXIT[0] + 0.5) * S, 0, (EXIT[1] + 0.5) * S);
  const pil = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, H, 12), new THREE.MeshBasicMaterial({ color: 0x33ff66 })); pil.position.y = H / 2;
  const el = new THREE.PointLight(0x33ff66, 40, 14); el.position.y = 2; const lb = label('B', '#6f6', 1.6); lb.position.y = 2.6; ex.add(pil, el, lb); scene.add(ex);

  // монстр: модель из character_3d, висит вниз головой на потолке, светится красным
  const MON_SCALE = 1.3, MON_CY = H - MON_SCALE; // центр тела по высоте
  const glow = (m) => { m = m.clone(); if (m.emissive) m.emissive.set(0x550000); return m; };
  const monster = () => {
    const gr = new THREE.Group(); let body;
    if (glb) { body = glb.clone(true); body.traverse((o) => { if (o.isMesh) o.material = Array.isArray(o.material) ? o.material.map(glow) : glow(o.material); }); }
    else { body = new THREE.Mesh(new THREE.CapsuleGeometry(0.4, 1.2, 4, 8), new THREE.MeshStandardMaterial({ color: 0x050505, emissive: 0x550000 })); body.position.y = 1; }
    body.scale.setScalar(MON_SCALE); body.rotation.x = Math.PI; gr.add(body); return gr;
  };
  const mons = pats.map((p, i) => ({ ...p, mesh: null, on: false, sc: 0, ph: i * 7 }));

  // другие игроки
  const av = new Map();
  const mkAv = (n) => { const o = new THREE.Group(); let body;
    if (glb) body = glb.clone(true); else { body = new THREE.Mesh(new THREE.CapsuleGeometry(0.4, 1.2, 4, 8), new THREE.MeshStandardMaterial({ color: 0x111111 })); body.position.y = 1; }
    const t = label(n, '#fff', 1.4); t.position.y = 2.5; o.add(body, t); scene.add(o); return o; };

  // состояние
  const st = saved && typeof saved.x === 'number' && !blocked(saved.x, saved.z) ? saved : { x: START[0] * S, z: START[1] * S };
  g = { room, id, hp: 100, lives: 3, t: 0, turbo: 0, cd: 0, lamp: true, lt: 0, hitCd: 0, touchCd: 0, over: false, best: saved && saved.best, yaw: 0, pitch: 0,
    px: (Math.floor(st.x / S) + 0.5) * S, pz: (Math.floor(st.z / S) + 0.5) * S, bi: -1, bj: -1, dist: null, keys: {}, mv: [0, 0] };
  if (saved && typeof saved.x === 'number' && !blocked(saved.x, saved.z)) { g.px = saved.x; g.pz = saved.z; }

  const msg = (t, ms) => { const m = $('hzMsg'); m.textContent = t; m.style.display = 'flex'; if (ms) setTimeout(() => { m.style.display = 'none'; }, ms); };
  const hud = () => { $('hzLife').textContent = '❤️'.repeat(g.lives) + '💔'.repeat(3 - g.lives); $('hzBar').firstChild.style.width = g.hp + '%';
    const t = g.turbo > 0 ? `⚡ ${Math.ceil(g.turbo)}` : g.cd > 0 ? `⚡ ${Math.ceil(g.cd)}с` : '⚡ ТУРБО'; $('hzT').textContent = t; $('hzT').style.opacity = g.cd > 0 && g.turbo <= 0 ? 0.4 : 0.9;
    $('hzF').textContent = g.lamp ? '🔦 ВКЛ' : '🔦 ВЫКЛ'; const s = Math.floor(g.t); $('hzInfo').textContent = `${sv} S · ${String(s / 60 | 0).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };
  const flash = () => { const r = $('hzRed'); r.style.transition = 'none'; r.style.opacity = 0.7; requestAnimationFrame(() => { r.style.transition = 'opacity .5s'; r.style.opacity = 0; }); };
  const save = () => { const o = { x: +g.px.toFixed(1), z: +g.pz.toFixed(1) }; if (g.best) o.best = g.best; ls(SAVE_KEY, JSON.stringify(o)); api(`horrorProgress/${id}`, 'PUT', o).catch(() => {}); };
  const leave = () => { if (!g) return; const me = g; g = null; clearInterval(me.net); clearInterval(me.sv); cancelAnimationFrame(me.raf);
    removeEventListener('keydown', kd); removeEventListener('keyup', ku); removeEventListener('pagehide', ph); removeEventListener('resize', resize); renderer.dispose(); root.remove(); if (menu) menu.classList.remove('hidden');
    release(); };
  const exit = () => { if (g) save(); leave(); };
  const die = () => { g.over = true; save(); msg('💀 ТЫ ПОГИБ', 2200); setTimeout(leave, 2300); };
  const hurt = (n) => { g.hp -= n; flash(); if (g.hp <= 0) { g.hp = 100; g.lives--; if (g.lives <= 0) { hud(); die(); return; } msg('💔 Жизнь треснула', 1000); } hud(); };
  const loseLives = (n) => { flash(); g.hp = 100; g.lives = Math.max(0, g.lives - n); hud(); if (g.lives <= 0) die(); else msg(`💔 −${n} жизни`, 1000); };
  const toggleLamp = () => { g.lamp = !g.lamp; if (g.lamp) g.lt = 0; hud(); };
  const turbo = () => { if (g.turbo <= 0 && g.cd <= 0) { g.turbo = TURBO_T; hud(); } };
  const kd = (e) => { g.keys[e.code] = true; if (e.code === 'KeyF') toggleLamp(); if (e.code === 'KeyT' || e.code === 'ShiftLeft') turbo(); if (e.code === 'Escape') exit(); };
  const ku = (e) => { if (g) g.keys[e.code] = false; };
  const ph = () => { if (g) { save(); release(); } };
  addEventListener('keydown', kd); addEventListener('keyup', ku); addEventListener('pagehide', ph);
  $('hzX').onclick = exit; $('hzT').onclick = turbo; $('hzF').onclick = toggleLamp;
  for (const b of root.querySelectorAll('button')) b.addEventListener('pointerdown', (e) => e.stopPropagation());

  // управление: левая часть экрана (тач) — стик, остальное — камера
  const ptr = new Map(), stick = $('hzStick'), knob = $('hzKnob');
  root.addEventListener('pointerdown', (e) => { if (!g) return; root.setPointerCapture(e.pointerId);
    ptr.set(e.pointerId, { x: e.clientX, y: e.clientY, js: e.pointerType !== 'mouse' && e.clientX < innerWidth * 0.4 }); });
  root.addEventListener('pointermove', (e) => { const p = ptr.get(e.pointerId); if (!p || !g) return;
    if (p.js) { const r = stick.getBoundingClientRect(); let dx = (e.clientX - r.left - 60) / 50, dy = (e.clientY - r.top - 60) / 50; const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; }
      g.mv = [dx, dy]; knob.style.transform = `translate(${dx * 40}px,${dy * 40}px)`; }
    else { g.yaw -= (e.clientX - p.x) * 0.005; g.pitch = Math.max(-1.2, Math.min(1.2, g.pitch - (e.clientY - p.y) * 0.005)); p.x = e.clientX; p.y = e.clientY; } });
  const up = (e) => { const p = ptr.get(e.pointerId); if (p && p.js && g) { g.mv = [0, 0]; knob.style.transform = ''; } ptr.delete(e.pointerId); };
  root.addEventListener('pointerup', up); root.addEventListener('pointercancel', up);
  const resize = () => { renderer.setSize(innerWidth, innerHeight, false); cam.aspect = innerWidth / innerHeight; cam.updateProjectionMatrix(); }; resize(); addEventListener('resize', resize);

  // сеть
  g.net = setInterval(() => { if (!g) return; const me = g;
    api(`horror/${room}/slots/${slot}`, 'PUT', { id, n: name, x: +me.px.toFixed(2), z: +me.pz.toFixed(2), r: +me.yaw.toFixed(2), t: Date.now() }).catch(() => {});
    api(`horror/${room}/slots`).then((pl) => { if (g !== me) return; const seen = new Set();
      for (const v of Object.values(pl || {})) { if (!v || v.id === id || Date.now() - v.t > 15000) continue; const k = v.id; seen.add(k);
        let a = av.get(k); if (!a) { a = { o: mkAv(v.n || 'Player') }; a.o.position.set(v.x, 0, v.z); av.set(k, a); } a.x = v.x; a.z = v.z; a.r = v.r; }
      for (const [k, a] of av) if (!seen.has(k)) { scene.remove(a.o); av.delete(k); } }).catch(() => {}); }, 300);
  g.sv = setInterval(() => { if (g && !g.over) save(); }, 5000);

  const los = (x0, z0, x1, z1) => { const n = Math.ceil(Math.hypot(x1 - x0, z1 - z0) / 0.5); for (let i = 1; i < n; i++) if (solid(x0 + (x1 - x0) * i / n, z0 + (z1 - z0) * i / n)) return false; return true; };
  const dir = new THREE.Vector3(), clock = new THREE.Clock();
  msg('Найди выход «B»', 2500); hud();

  const frame = () => { if (!g) return; g.raf = requestAnimationFrame(frame); const dt = Math.min(clock.getDelta(), 0.05), now = Date.now() / 1000;
    if (!g.over) {
      g.t += dt;
      if (g.turbo > 0) { g.turbo -= dt; if (g.turbo <= 0) g.cd = TURBO_CD; } else if (g.cd > 0) g.cd -= dt;
      if (g.lamp) { g.lt += dt; if (g.lt >= LAMP_T) { g.lamp = false; msg('🔦 Фонарик погас! Нажми кнопку', 1800); } }
      const k = g.keys; let f = -g.mv[1], r = g.mv[0];
      if (k.KeyW || k.ArrowUp) f += 1; if (k.KeyS || k.ArrowDown) f -= 1; if (k.KeyD || k.ArrowRight) r += 1; if (k.KeyA || k.ArrowLeft) r -= 1;
      const len = Math.hypot(f, r); if (len > 1) { f /= len; r /= len; }
      const sp = SPEED * (g.turbo > 0 ? TURBO_X : 1) * dt, dx = (-Math.sin(g.yaw) * f + Math.cos(g.yaw) * r) * sp, dz = (-Math.cos(g.yaw) * f - Math.sin(g.yaw) * r) * sp;
      const n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / 0.2));
      for (let i = 0; i < n; i++) { if (!blocked(g.px + dx / n, g.pz)) g.px += dx / n; if (!blocked(g.px, g.pz + dz / n)) g.pz += dz / n; }
      const bi = Math.floor(g.px / S), bj = Math.floor(g.pz / S); if (bi !== g.bi || bj !== g.bj) { g.bi = bi; g.bj = bj; g.dist = bfs(G, bi, bj).d; }
      g.hitCd -= dt; g.touchCd -= dt;
      cam.getWorldDirection(dir);
      for (const m of mons) {
        const L = m.path.length - 1, f0 = (now * MON_SPEED + m.ph) % (2 * L), ff = f0 > L ? 2 * L - f0 : f0, a = Math.floor(ff), b = Math.min(a + 1, L), fr = ff - a;
        const wx = ((m.path[a][0] + 0.5) * (1 - fr) + (m.path[b][0] + 0.5) * fr) * S, wz = ((m.path[a][1] + 0.5) * (1 - fr) + (m.path[b][1] + 0.5) * fr) * S;
        const dc = g.dist[m.zi + m.zj * W], dm = g.dist[Math.floor(wx / S) + Math.floor(wz / S) * W];
        if (!m.on && dc >= 0 && dc <= SPAWN_R && dm >= 0 && dm <= LEAVE_R) m.on = true;
        if (m.on && (dm < 0 || dm > LEAVE_R)) m.on = false;
        if (m.on && !m.mesh) { m.mesh = monster(); scene.add(m.mesh); }
        m.sc = Math.max(0, Math.min(1, m.sc + (m.on ? dt * 2 : -dt * 4)));
        if (m.mesh) { m.mesh.visible = m.sc > 0; m.mesh.scale.setScalar(m.sc); m.mesh.position.set(wx, H, wz);
          m.mesh.rotation.y = Math.atan2(g.px - wx, g.pz - wz) + Math.PI; m.mesh.rotation.z = Math.sin(now * 3 + m.ph) * 0.08; }
        if (!m.on) continue;
        const vx = wx - g.px, vy = MON_CY - 1.6, vz = wz - g.pz, d3 = Math.hypot(vx, vy, vz);
        if (g.hitCd <= 0 && d3 < 20 && (vx * dir.x + vy * dir.y + vz * dir.z) / d3 > 0.9 && los(g.px, g.pz, wx, wz)) { g.hitCd = 3; hurt(50); if (g.over) break; }
        if (g.touchCd <= 0 && Math.hypot(vx, vz) < 1.4) { g.touchCd = 4; loseLives(LIFE_TOUCH); if (g.over) break; }
      }
      if (!g.over && Math.hypot(g.px - ex.position.x, g.pz - ex.position.z) < 2) { g.over = true; g.best = Math.min(g.best || 1e9, g.t); const s = g.t.toFixed(1);
        g.px = START[0] * S; g.pz = START[1] * S; save(); msg(`🎉 Выход найден! ${s} с`, 3000); setTimeout(leave, 3100); }
      hud();
    }
    for (const [, a] of av) { a.o.position.x += (a.x - a.o.position.x) * 0.25; a.o.position.z += (a.z - a.o.position.z) * 0.25; a.o.rotation.y += (a.r - a.o.rotation.y) * 0.25; }
    cam.position.set(g.px, 1.6, g.pz); cam.rotation.set(g.pitch, g.yaw, 0); lamp.visible = g.lamp;
    renderer.render(scene, cam); };
  frame();
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injectButton); else injectButton();
