// Другие игроки: гориллы с цветом по ID, ником над головой и плавным движением.
import * as THREE from 'three';
import { createGorilla } from './gorilla.js';
import { colorHex } from './look.js';

const MAX_SHOWN = 24, MAX_DIST = 220, NAME_DIST = 70;

function nameSprite(text) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64;
  const g = c.getContext('2d');
  g.font = 'bold 34px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  const w = Math.min(244, g.measureText(text).width + 28);
  g.fillStyle = 'rgba(0,0,0,.55)'; g.beginPath(); g.roundRect(128 - w / 2, 8, w, 48, 24); g.fill();
  g.fillStyle = '#fff'; g.fillText(text, 128, 33, 230);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, fog: false }));
  sp.scale.set(2.4, 0.6, 1); sp.position.y = 2.35;
  return sp;
}
function dispose(o) {
  o.traverse((m) => {
    if (m.geometry) m.geometry.dispose();
    if (m.material) { if (m.material.map && !(m.material.map.userData && m.material.map.userData.shared)) m.material.map.dispose(); m.material.dispose(); }
  });
}

export function createRemotes(scene) {
  const map = new Map(); // id -> { g, label, tx,ty,tz,tf, s,a, n, built }
  return {
    set(list) {
      const ids = new Set();
      for (const p of list) {
        ids.add(p.id);
        let r = map.get(p.id);
        if (!r) { r = { n: p.n, g: null, label: null, x: p.x, y: p.y, z: p.z, f: p.f }; map.set(p.id, r); }
        r.tx = p.x; r.ty = p.y; r.tz = p.z; r.tf = p.f; r.s = p.s; r.a = p.a; r.c = p.c; r.k = p.k;
        if (r.n !== p.n) { r.n = p.n; if (r.label) { r.g.object.remove(r.label); dispose(r.label); r.label = null; } }
      }
      for (const [id, r] of map) if (!ids.has(id)) { if (r.g) { scene.remove(r.g.object); dispose(r.g.object); } map.delete(id); }
    },
    update(dt, cam) {
      const k = 1 - Math.exp(-dt * 7);
      const arr = [];
      for (const [id, r] of map) {
        r.x += (r.tx - r.x) * k; r.y += (r.ty - r.y) * k; r.z += (r.tz - r.z) * k;
        let d = r.tf - r.f; d = Math.atan2(Math.sin(d), Math.cos(d)); r.f += d * k;
        arr.push([Math.hypot(r.x - cam.x, r.y - cam.y, r.z - cam.z), id, r]);
      }
      arr.sort((a, b) => a[0] - b[0]);
      arr.forEach(([dist, id, r], i) => {
        const vis = i < MAX_SHOWN && dist < MAX_DIST;
        if (vis && !r.g) { r.g = createGorilla(); scene.add(r.g.object); r.lc = -1; }
        if (!r.g) return;
        r.g.object.visible = vis;
        if (!vis) return;
        const lk = (r.c | 0) * 64 + (r.k | 0);
        if (r.lc !== lk) { r.lc = lk; r.g.setLook(colorHex(r.c), r.k | 0); }
        if (!r.label) { r.label = nameSprite(r.n); r.g.object.add(r.label); }
        r.label.visible = dist < NAME_DIST;
        r.g.object.position.set(r.x, r.y, r.z);
        r.g.object.rotation.y = r.f;
        r.g.animate(dt, r.s, !!r.a);
      });
    },
    count: () => map.size,
    clear() { this.set([]); },
  };
}
