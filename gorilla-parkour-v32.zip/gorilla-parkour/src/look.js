// Внешность: цвет (радуга) и косметика (можно носить несколько сразу). Хранится на устройстве и передаётся другим игрокам.
export const COLORS = [null, 0xe53935, 0xfb8c00, 0xfdd835, 0x43a047, 0x29b6f6, 0x3f51b5, 0x8e24aa]; // 0 — классический тёмный, дальше цвета радуги
export const SWATCH = ['#17171c', '#e53935', '#fb8c00', '#fdd835', '#43a047', '#29b6f6', '#3f51b5', '#8e24aa'];
export const COS_COUNT = 4; // 0 банан, 1 перчатки, 2 флаг, 3 костюм (биты маски)
const KEY = 'gp_look_v1';
export const colorHex = (c) => COLORS[(c | 0) >= 0 && (c | 0) < COLORS.length ? c | 0 : 0];
export function loadLook() {
  try {
    const o = JSON.parse(localStorage.getItem(KEY) || 'null') || {};
    return { c: Math.max(0, Math.min(COLORS.length - 1, o.c | 0)), k: (o.k | 0) & ((1 << COS_COUNT) - 1) };
  } catch { return { c: 0, k: 0 }; }
}
export function saveLook(l) { try { localStorage.setItem(KEY, JSON.stringify(l)); } catch { /* */ } }

// ---- монеты и покупки ----
export const PRICES = [10, 15, 35, 10];   // банан, перчатки, флаг, костюм
export const COINS_PER_50M = 10;
const KW = 'gp_wallet_v1', KE = 'gp_econ_v1';
export function loadWallet() {
  try {
    const o = JSON.parse(localStorage.getItem(KW) || 'null') || {};
    return { coins: Math.max(0, Math.min(1e9, o.coins | 0)), owned: (o.owned | 0) & ((1 << COS_COUNT) - 1) };
  } catch { return { coins: 0, owned: 0 }; }
}
export function saveWallet(w) { try { localStorage.setItem(KW, JSON.stringify(w)); } catch { /* */ } }
// До появления магазина косметика была бесплатной. При первом запуске новой версии всё надетое, но не купленное, снимается (в том числе костюм).
export function migrateEconomy() {
  try {
    if (localStorage.getItem(KE)) return;
    localStorage.setItem(KE, '1');
    const l = loadLook(); l.k &= loadWallet().owned; saveLook(l);
  } catch { /* */ }
}
