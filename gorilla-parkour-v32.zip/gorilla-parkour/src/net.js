// Мультиплеер на Firebase Realtime Database через обычный REST + SSE (без SDK и без секретов).
import { DB_URL, ADMIN_HASH } from './config.js';

const base = DB_URL.replace(/\/$/, '');
const url = (p, q = '') => `${base}/${p}.json${q}`;
export const dbUrl = url;
const STALE_MS = 45000;
export const ROOM_IDS = ['en', 'ru', 'kz'];

async function jget(p, q = '') {
  const r = await fetch(url(p, q), { cache: 'no-store' });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}
const jput = (p, v, keepalive = false) => fetch(url(p), { method: 'PUT', body: JSON.stringify(v), keepalive });

// ---- слияние событий SSE в дерево (экспортируется для тестов) ----
export function setAt(root, path, data) {
  const seg = String(path).split('/').filter(Boolean);
  if (!seg.length) return data == null ? {} : data;
  if (root == null || typeof root !== 'object') root = {};
  let cur = root;
  for (let i = 0; i < seg.length - 1; i++) {
    if (cur[seg[i]] == null || typeof cur[seg[i]] !== 'object') cur[seg[i]] = {};
    cur = cur[seg[i]];
  }
  const last = seg[seg.length - 1];
  if (data == null) delete cur[last]; else cur[last] = data;
  return root;
}
export function applyEvent(root, type, path, data) {
  if (type === 'put') return setAt(root, path, data);
  if (type === 'patch' && data && typeof data === 'object') {
    for (const k of Object.keys(data)) root = setAt(root, (path === '/' ? '' : path) + '/' + k, data[k]);
  }
  return root;
}
const validPlayer = (id, v) => /^GP-[A-Z0-9]{6}$/.test(id) && v && typeof v === 'object'
  && typeof v.x === 'number' && typeof v.y === 'number' && typeof v.z === 'number';

export function createNet() {
  let es = null, room = '', myId = '', myNick = '', tree = {}, online = false, stopped = true;
  let cbPlayers = null, cbStatus = null, hb = 0, sweep = 0, retry = 0, inflight = false;
  let st = null, lastSent = '', lastSentAt = 0;
  const seen = new Map(); // id -> { t, at } — устаревание считаем по времени получения, а не по часам телефона

  function setOnline(v) { if (online !== v) { online = v; cbStatus && cbStatus(v); } }

  function emit() {
    const now = Date.now(), list = [];
    for (const [id, v] of Object.entries(tree)) {
      if (id === myId || !validPlayer(id, v)) continue;
      let s = seen.get(id);
      if (!s || s.t !== v.t) { s = { t: v.t, at: now }; seen.set(id, s); }
      if (now - s.at > STALE_MS) { if (now - s.at > STALE_MS + 15000) fetch(url(`rooms/${room}/players/${id}`), { method: 'DELETE' }).catch(() => {}); continue; }
      list.push({ id, n: String(v.n || '?').slice(0, 14), x: v.x, y: v.y, z: v.z, f: +v.f || 0, s: +v.s || 0, a: v.a ? 1 : 0, v: v.v ? 1 : 0, c: v.c | 0, k: v.k | 0 });
    }
    for (const id of seen.keys()) if (!tree[id]) seen.delete(id);
    cbPlayers && cbPlayers(list);
  }

  function open() {
    if (stopped) return;
    try { es && es.close(); } catch { /* */ }
    es = new EventSource(url(`rooms/${room}/players`));
    const onEv = (type) => (e) => {
      try {
        const m = JSON.parse(e.data);
        tree = applyEvent(tree, type, m.path, m.data);
        setOnline(true); emit();
      } catch { /* битое событие игнорируем */ }
    };
    es.addEventListener('put', onEv('put'));
    es.addEventListener('patch', onEv('patch'));
    es.addEventListener('keep-alive', () => setOnline(true));
    es.onopen = () => setOnline(true);
    es.onerror = () => {
      setOnline(false);
      if (es && es.readyState === 2) { clearTimeout(retry); retry = setTimeout(open, 3000); }
    };
  }

  function push(force) {
    if (stopped || inflight || !st) return;
    const now = Date.now();
    const body = { n: myNick, x: +st.x.toFixed(2), y: +st.y.toFixed(2), z: +st.z.toFixed(2), f: +st.f.toFixed(2), s: +st.s.toFixed(2), a: st.a ? 1 : 0, v: st.v ? 1 : 0, c: st.c | 0, k: st.k | 0 };
    const key = JSON.stringify(body);
    if (!force && key === lastSent && now - lastSentAt < 4000) return;
    inflight = true; lastSent = key; lastSentAt = now;
    body.t = now;
    jput(`rooms/${room}/players/${myId}`, body).then((r) => { if (r.ok) setOnline(true); }).catch(() => setOnline(false)).finally(() => { inflight = false; });
  }

  return {
    connect(r, id, nick, onPlayers, onStatus) {
      this.disconnect();
      room = r; myId = id; myNick = nick; cbPlayers = onPlayers; cbStatus = onStatus; stopped = false; tree = {}; seen.clear(); online = false;
      open();
      hb = setInterval(() => push(false), 250);
      sweep = setInterval(emit, 2000);
    },
    setState(s) { st = s; },
    disconnect() {
      if (stopped && !es) return;
      stopped = true; clearInterval(hb); clearInterval(sweep); clearTimeout(retry);
      try { es && es.close(); } catch { /* */ }
      es = null; online = false; tree = {}; seen.clear(); st = null; lastSent = '';
      if (room && myId) { try { fetch(url(`rooms/${room}/players/${myId}`), { method: 'DELETE', keepalive: true }).catch(() => {}); } catch { /* */ } }
    },
    isOnline: () => online,
  };
}

// сколько игроков онлайн на каждом сервере (для меню)
export async function fetchCounts() {
  const out = {};
  await Promise.all(ROOM_IDS.map(async (r) => {
    try {
      const o = (await jget(`rooms/${r}/players`)) || {};
      const now = Date.now();
      out[r] = Object.entries(o).filter(([id, v]) => validPlayer(id, v) && typeof v.t === 'number' && now - v.t < STALE_MS).length;
    } catch { out[r] = null; }
  }));
  return out;
}

// ---- лидерборд: отдельный на каждом сервере, у одного ID только лучшее время ----
export async function fetchBoardNet(r) {
  let o;
  try { o = await jget(`board/${r}`, '?orderBy=%22t%22&limitToFirst=10'); }
  catch { o = await jget(`board/${r}`); }
  return Object.entries(o || {})
    .filter(([, v]) => v && typeof v.t === 'number' && v.t > 0 && typeof v.n === 'string')
    .map(([id, v]) => ({ id, name: v.n, t: v.t }))
    .sort((a, b) => a.t - b.t).slice(0, 10);
}
export async function submitScoreNet(r, id, name, t) {
  const cur = await jget(`board/${r}/${id}`).catch(() => null);
  if (!cur || typeof cur.t !== 'number' || t < cur.t) await jput(`board/${r}/${id}`, { n: name, t: +t.toFixed(2), d: Date.now() });
  else if (cur.n !== name) await jput(`board/${r}/${id}`, { n: name, t: cur.t, d: cur.d || Date.now() });
}

// ---- общие баны по ID (пишутся только с ключом админа) ----
export async function getBanNet(id) {
  const v = await jget(`bans/${id}`);
  return v && typeof v.u === 'number' ? Math.max(0, v.u - Date.now()) : 0;
}
export async function listBansNet() {
  const o = (await jget('bans')) || {}, now = Date.now();
  return Object.entries(o).filter(([id, v]) => /^GP-[A-Z0-9]{6}$/.test(id) && v && v.u > now).map(([id, v]) => ({ id, until: v.u })).sort((a, b) => a.until - b.until);
}
export async function setBanNet(id, ms) {
  const r = await jput(`bans/${id}`, { u: ms > 0 ? Date.now() + ms : 0, k: ADMIN_HASH });
  if (!r.ok) throw new Error('HTTP ' + r.status);
}

// ---- чат: у каждого сервера свой, хранятся только последние сообщения ----
export const CHAT_MAX = 120;
export function createChat() {
  let es = null, room = '', tree = {}, cb = null, stopped = true, retry = 0;
  const emit = () => {
    const list = Object.entries(tree)
      .filter(([, v]) => v && typeof v.m === 'string' && typeof v.n === 'string' && typeof v.i === 'string')
      .sort((a, b) => (a[0] < b[0] ? -1 : 1)).slice(-40)
      .map(([k, v]) => ({ k, i: v.i, n: v.n.slice(0, 14), m: v.m.slice(0, CHAT_MAX), t: +v.t || 0 }));
    cb && cb(list);
  };
  function open() {
    if (stopped) return;
    try { es && es.close(); } catch { /* */ }
    es = new EventSource(url(`chat/${room}`, '?orderBy=%22%24key%22&limitToLast=40'));
    const onEv = (type) => (e) => { try { const m = JSON.parse(e.data); tree = applyEvent(tree, type, m.path, m.data); emit(); } catch { /* */ } };
    es.addEventListener('put', onEv('put'));
    es.addEventListener('patch', onEv('patch'));
    es.onerror = () => { if (es && es.readyState === 2) { clearTimeout(retry); retry = setTimeout(open, 3000); } };
  }
  return {
    connect(r, onMessages) { this.disconnect(); room = r; cb = onMessages; stopped = false; tree = {}; open(); },
    disconnect() { stopped = true; clearTimeout(retry); try { es && es.close(); } catch { /* */ } es = null; tree = {}; },
  };
}
export async function sendChat(r, id, nick, text) {
  const res = await fetch(url(`chat/${r}`), { method: 'POST', body: JSON.stringify({ i: id, n: nick, m: text, t: Date.now() }) });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  if (Math.random() < 0.12) { // иногда подчищаем старые сообщения (оставляем 100)
    try {
      const keys = Object.keys((await jget(`chat/${r}`, '?shallow=true')) || {}).sort();
      if (keys.length > 100) {
        const patch = {}; keys.slice(0, keys.length - 100).forEach((k) => { patch[k] = null; });
        await fetch(url(`chat/${r}`), { method: 'PATCH', body: JSON.stringify(patch) });
      }
    } catch { /* не страшно */ }
  }
}
export async function getMuteNet(id) {
  const v = await jget(`mutes/${id}`);
  return v && typeof v.u === 'number' ? Math.max(0, v.u - Date.now()) : 0;
}
export async function setMuteNet(id, ms) {
  const r = await jput(`mutes/${id}`, { u: ms > 0 ? Date.now() + ms : 0, k: ADMIN_HASH });
  if (!r.ok) throw new Error('HTTP ' + r.status);
}
