// Платформы-предметы: вместо одинаковых ящиков и балок — автобусы, картины, холодильники и т.д.
// Меняется только внешний вид: невидимая «коробка» для столкновений остаётся прежней, поэтому трасса так же проходима.
// Координаты локальные: начало в центре коробки, ось x вдоль hx, z вдоль hz, верх платформы на y = +th/2.
import * as THREE from 'three';

const B = (w, h, d, x, y, z, c) => ({ g: new THREE.BoxGeometry(w, h, d).translate(x, y, z), c });
const Cyl = (r, h, x, y, z, c, axis = 'y', seg = 10) => {
  const g = new THREE.CylinderGeometry(r, r, h, seg);
  if (axis === 'z') g.rotateX(Math.PI / 2); else if (axis === 'x') g.rotateZ(Math.PI / 2);
  return { g: g.translate(x, y, z), c };
};
const pick = (arr, r) => arr[Math.floor(r * arr.length) % arr.length];
const EPS = 0.012; // накладки выступают над верхом не больше, чем на 1 см

function wheels(W, D, th, xs) {
  const r = Math.min(0.3, th * 0.5 + 0.06), out = [];
  for (const x of xs) for (const sz of [-1, 1]) {
    out.push(Cyl(r, 0.14, x, -th / 2 + 0.02, sz * (D / 2 - 0.03), 0x151517, 'z', 10));
    out.push(Cyl(r * 0.5, 0.16, x, -th / 2 + 0.02, sz * (D / 2 - 0.03), 0xb8bec6, 'z', 8));
  }
  return out;
}

const STYLES = {
  bus(W, D, th, r) {
    const body = pick([0xf2c500, 0xf2c500, 0xe65100, 0x2e7d32], r);
    const win = 0x25323f;
    return [
      B(W, th, D, 0, 0, 0, body),
      B(W * 0.96, EPS, D * 0.9, 0, th / 2 + EPS / 2, 0, 0xfff3b0),             // светлая крыша
      B(W * 0.84, th * 0.34, 0.02, -W * 0.03, th * 0.12, D / 2 + 0.01, win),
      B(W * 0.84, th * 0.34, 0.02, -W * 0.03, th * 0.12, -D / 2 - 0.01, win),
      B(0.02, th * 0.4, D * 0.72, W / 2 + 0.01, th * 0.08, 0, win),             // лобовое
      B(W, 0.05, D + 0.02, 0, -th * 0.2, 0, 0x3a3a3a),                           // полоса по борту
      B(0.04, 0.1, 0.14, W / 2 + 0.02, -th * 0.28, D * 0.3, 0xffffe0),
      B(0.04, 0.1, 0.14, W / 2 + 0.02, -th * 0.28, -D * 0.3, 0xffffe0),
      ...wheels(W, D, th, [-W * 0.3, W * 0.3]),
    ];
  },
  car(W, D, th, r) {
    const body = pick([0xd32f2f, 0x1976d2, 0x7b1fa2, 0xfb8c00], r);
    return [
      B(W, th, D, 0, 0, 0, body),
      B(W * 0.96, EPS, D * 0.9, 0, th / 2 + EPS / 2, 0, 0xffffff),
      B(W * 0.5, th * 0.38, 0.02, -W * 0.05, th * 0.1, D / 2 + 0.01, 0x25323f),
      B(W * 0.5, th * 0.38, 0.02, -W * 0.05, th * 0.1, -D / 2 - 0.01, 0x25323f),
      B(0.04, 0.12, 0.2, W / 2 + 0.02, -th * 0.15, D * 0.28, 0xffffe0),
      B(0.04, 0.12, 0.2, W / 2 + 0.02, -th * 0.15, -D * 0.28, 0xffffe0),
      ...wheels(W, D, th, [-W * 0.28, W * 0.28]),
    ];
  },
  container(W, D, th, r) {
    const c = pick([0xc0392b, 0x2874a6, 0x229954, 0xd68910], r);
    const out = [B(W, th, D, 0, 0, 0, c), B(W * 0.96, EPS, D * 0.9, 0, th / 2 + EPS / 2, 0, 0xffffff)];
    const n = Math.max(3, Math.floor(W / 0.5));
    for (let i = 0; i < n; i++) {
      const x = -W / 2 + (i + 0.5) * (W / n);
      out.push(B(0.07, th * 0.9, 0.03, x, 0, D / 2 + 0.015, 0x1c1c1c), B(0.07, th * 0.9, 0.03, x, 0, -D / 2 - 0.015, 0x1c1c1c));
    }
    out.push(B(0.03, th * 0.8, D * 0.04, W / 2 + 0.015, 0, 0, 0x1c1c1c));
    return out;
  },
  piano(W, D, th) {
    const out = [B(W, th, D, 0, 0, 0, 0x1a1a1d), B(W * 0.96, EPS, D * 0.88, 0, th / 2 + EPS / 2, 0, 0x4a4a52), B(W * 0.92, th * 0.45, 0.03, 0, th * 0.12, D / 2 + 0.015, 0xf5f5f5)];
    const n = Math.max(6, Math.floor(W / 0.22));
    for (let i = 1; i < n; i++) if (i % 7 !== 3 && i % 7 !== 0) out.push(B(0.09, th * 0.28, 0.05, -W * 0.46 + i * (W * 0.92 / n), th * 0.2, D / 2 + 0.03, 0x111111));
    return out;
  },
  painting(W, D, th, r) {
    const sky = pick([0x6ec6ff, 0xffb86b, 0xa0d8ef, 0xf6a8c8], r);
    const iw = W - 0.34, id = D - 0.34;
    return [
      B(W, th, D, 0, 0, 0, 0x8d5a2b),
      B(W, 0.05, D, 0, th / 2 - 0.02, 0, 0xd4a017),                              // золотая рама сверху
      B(iw, EPS, id, 0, th / 2 + EPS / 2, 0, sky),                              // небо
      B(iw, EPS + 0.002, id * 0.45, 0, th / 2 + EPS / 2, id * 0.275, 0x4caf50), // холмы
      Cyl(Math.min(iw, id) * 0.12, EPS + 0.004, -iw * 0.28, th / 2 + EPS / 2, -id * 0.22, 0xfff176, 'y', 12), // солнце
    ];
  },
  books(W, D, th, r) {
    const n = Math.max(3, Math.min(6, Math.round(th / 0.17))), h = th / n, out = [];
    const cols = [0xc62828, 0x1565c0, 0x2e7d32, 0xf9a825, 0x6a1b9a, 0x00838f, 0xef6c00];
    for (let i = 0; i < n; i++) {
      const k = i === n - 1 ? 1 : 0.9 + ((r * (i + 3) * 7.13) % 1) * 0.1;
      out.push(B(W * k, h * 0.96, D * (i === n - 1 ? 1 : 0.94 + ((r * (i + 5) * 3.7) % 1) * 0.06), 0, -th / 2 + h * (i + 0.5), 0, cols[(Math.floor(r * 100) + i * 3) % cols.length]));
    }
    out.push(B(W * 0.96, EPS, D * 0.9, 0, th / 2 + EPS / 2, 0, 0xfff8e1));
    return out;
  },
  cheese(W, D, th) {
    const out = [B(W, th, D, 0, 0, 0, 0xf4c430), B(W * 0.96, EPS, D * 0.9, 0, th / 2 + EPS / 2, 0, 0xffe27a)];
    const holes = [[-0.25, 0.1, 0.16], [0.2, -0.1, 0.12], [0.35, 0.15, 0.09]];
    for (const [fx, fy, rr] of holes) {
      const x = fx * W * 0.8, rad = Math.min(rr, th * 0.3);
      out.push(Cyl(rad, 0.03, x, fy * th, D / 2 + 0.005, 0xc99a1a, 'z', 8), Cyl(rad, 0.03, -x, -fy * th, -D / 2 - 0.005, 0xc99a1a, 'z', 8));
    }
    return out;
  },
  woodcrate(W, D, th) {
    const out = [B(W, th, D, 0, 0, 0, 0xa9733d)];
    const n = Math.max(3, Math.floor(D / 0.5));
    for (let i = 1; i < n; i++) out.push(B(W * 0.98, EPS, 0.04, 0, th / 2 + EPS / 2, -D / 2 + i * (D / n), 0x7c5126)); // доски сверху
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) out.push(B(0.14, th + 0.02, 0.14, sx * (W / 2 - 0.06), 0, sz * (D / 2 - 0.06), 0x6e4a22));
    return out;
  },
  suitcase(W, D, th, r) {
    const c = pick([0x8e4a2b, 0x00796b, 0x5d4037, 0x37474f], r);
    const out = [B(W, th, D, 0, 0, 0, c), B(W * 0.96, EPS, D * 0.9, 0, th / 2 + EPS / 2, 0, 0xf1e3c8)];
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) out.push(B(0.18, th + 0.03, 0.18, sx * (W / 2 - 0.07), 0, sz * (D / 2 - 0.07), 0xb0b4ba));
    for (const x of [-W * 0.22, W * 0.22]) out.push(B(0.1, th + 0.012, D + 0.012, x, 0, 0, 0x2e2118));
    return out;
  },
  fridge(W, D, th) {
    return [
      B(W, th, D, 0, 0, 0, 0xe8eef2), B(W * 0.96, EPS, D * 0.9, 0, th / 2 + EPS / 2, 0, 0xbfe3f5),
      B(W * 0.55, 0.07, 0.05, 0, th * 0.1, D / 2 + 0.025, 0x8e98a1),
      B(W, 0.02, 0.01, 0, -th * 0.15, D / 2 + 0.006, 0x9aa3ab),
      B(0.18, 0.18, 0.02, -W * 0.3, th * 0.3, D / 2 + 0.011, 0xe53935),
    ];
  },
  tv(W, D, th) {
    return [
      B(W, th, D, 0, 0, 0, 0x15161a), B(W * 0.96, EPS, D * 0.9, 0, th / 2 + EPS / 2, 0, 0x2b2d36),
      B(W * 0.84, th * 0.72, 0.02, 0, 0, D / 2 + 0.011, 0x3a7bd5), B(W * 0.84, th * 0.72, 0.02, 0, 0, -D / 2 - 0.011, 0x3a7bd5),
      B(0.1, 0.1, 0.03, W * 0.4, -th * 0.38, D / 2 + 0.016, 0x55e07a),
    ];
  },
};
const CRATE_STYLES = ['painting', 'books', 'cheese', 'woodcrate', 'suitcase', 'fridge', 'tv', 'painting', 'books'];
const BEAM_STYLES = ['bus', 'car', 'container', 'piano', 'bus'];

// kind: 'crate' | 'beam'; r — псевдослучайное число 0..1 (одно и то же для одной платформы)
export function makeProp(kind, hx, hz, th, r) {
  const style = kind === 'beam' ? pick(BEAM_STYLES, r) : pick(CRATE_STYLES, (r * 13.7) % 1);
  return STYLES[style](hx * 2, hz * 2, th, r);
}
export const PROP_STYLES = Object.keys(STYLES);

// ---- шина (едущая платформа) и бочка (крутится вокруг своей оси): единичные формы, масштабируются в instanced-меше ----
function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo; g.deleteAttribute('uv');
  const c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3));
  return g;
}
export function tireParts() { // y от -0.5 до 0.5, радиус 0.5
  const ps = [
    [new THREE.CylinderGeometry(0.5, 0.5, 1, 24), 0x1d1d20],
    [new THREE.CylinderGeometry(0.504, 0.504, 0.14, 24), 0xe9e9ec],                              // белая полоса на боку
    [new THREE.CylinderGeometry(0.43, 0.43, 0.02, 24).translate(0, 0.505, 0), 0x2f2f34],           // протектор сверху
    [new THREE.CylinderGeometry(0.3, 0.3, 0.025, 20).translate(0, 0.51, 0), 0xaab0b8],             // диск
  ];
  for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2; ps.push([new THREE.CylinderGeometry(0.035, 0.035, 0.03, 6).translate(Math.cos(a) * 0.17, 0.52, Math.sin(a) * 0.17), 0x555a63]); }
  return ps.map(([g, c]) => colored(g, c));
}
export function barrelParts() { // белое тело (красится цветом экземпляра), тёмные обручи, крест и полоска — чтобы вращение было видно
  const ps = [
    [new THREE.CylinderGeometry(0.5, 0.5, 1, 20), 0xffffff],
    [new THREE.CylinderGeometry(0.508, 0.508, 0.1, 20).translate(0, 0.3, 0), 0x555960],
    [new THREE.CylinderGeometry(0.508, 0.508, 0.1, 20).translate(0, -0.3, 0), 0x555960],
    [new THREE.CylinderGeometry(0.44, 0.44, 0.02, 20).translate(0, 0.505, 0), 0xe8e8e8],
    [new THREE.BoxGeometry(0.86, 0.025, 0.1).translate(0, 0.52, 0), 0x2d2d33],
    [new THREE.BoxGeometry(0.1, 0.025, 0.86).translate(0, 0.52, 0), 0x2d2d33],
    [new THREE.BoxGeometry(0.14, 0.9, 0.03).translate(0, 0, 0.5), 0xffe082],
  ];
  return ps.map(([g, c]) => colored(g, c));
}
