// Оригинальный персонаж «Горилла» по рисунку автора: круглое тело, тёмная шерсть, светлая морда,
// коричневые уши и живот, длинные руки. Собран из простых фигур.
import * as THREE from 'three';

let flagTex = null; // общая текстура флага для всех горилл
function getFlagTexture() {
  if (flagTex || typeof document === 'undefined') return flagTex;
  const c = document.createElement('canvas'); c.width = 256; c.height = 308;
  const g = c.getContext('2d');
  g.fillStyle = '#0b0b0d'; g.fillRect(0, 0, 256, 154);
  g.fillStyle = '#ffffff'; g.fillRect(0, 154, 256, 154);
  g.fillStyle = '#0b0b0d'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = '900 46px Arial Black, Arial, sans-serif';
  g.fillText('GORILLA', 128, 205, 232);
  g.fillText('PARKOUR', 128, 258, 232);
  flagTex = new THREE.CanvasTexture(c);
  flagTex.colorSpace = THREE.SRGBColorSpace;
  flagTex.userData.shared = true;
  return flagTex;
}

export function createGorilla() {
  const col = (hex) => new THREE.MeshLambertMaterial({ color: hex, flatShading: true });
  const fur = col(0x17171c);
  const furLight = col(0x2c2c33);
  const tan = col(0xb98a6a);      // живот и уши
  const face = col(0xece6dc);     // светлая морда
  const tips = col(0xa89a8c);     // кончики пальцев
  const black = new THREE.MeshBasicMaterial({ color: 0x0b0b0d });

  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  const add = (geo, mat, x = 0, y = 0, z = 0, parent = body, sx = 1, sy = 1, sz = 1) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z); m.scale.set(sx, sy, sz);
    parent.add(m);
    return m;
  };
  const ball = (r) => new THREE.SphereGeometry(r, 16, 12);

  // туловище: широкая «груша» + плечи
  add(ball(0.62), fur, 0, 0.98, 0, body, 1.0, 0.98, 0.82);
  add(ball(0.5), fur, 0, 1.42, 0, body, 1.3, 0.66, 0.82);
  add(ball(0.5), tan, 0, 1.0, 0.36, body, 0.82, 1.02, 0.4);   // коричневый живот
  add(ball(0.42), furLight, 0, 0.6, -0.02, body, 1.1, 0.72, 0.9);   // низ тела (ног нет)

  // голова
  const head = new THREE.Group();
  head.position.set(0, 1.82, 0.08);
  body.add(head);
  add(ball(0.32), fur, 0, 0, 0, head);
  add(ball(0.3), face, 0, -0.04, 0.12, head, 0.72, 0.9, 0.55);   // светлая морда-овал
  for (const sx of [-1, 1]) {
    add(ball(0.12), tan, sx * 0.34, 0.06, -0.02, head, 1, 1, 0.55);        // уши
    add(ball(0.045), black, sx * 0.1, 0.07, 0.3, head);                      // глаза
  }
  add(new THREE.BoxGeometry(0.22, 0.06, 0.05), black, 0, -0.04, 0.33, head); // «усы»/нос
  add(new THREE.BoxGeometry(0.12, 0.035, 0.05), black, 0, -0.13, 0.31, head); // рот

  // руки (длинные) — пивот в плече; на рисунке раскинуты в стороны
  const arms = [];
  for (const sx of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(sx * 0.78, 1.46, 0);
    body.add(pivot);
    add(new THREE.CapsuleGeometry(0.15, 0.95, 4, 10), fur, 0, -0.63, 0, pivot);
    add(ball(0.21), fur, 0, -1.26, 0.02, pivot);
    add(ball(0.11), tips, 0, -1.4, 0.05, pivot, 1.3, 0.8, 1);                // светлые кончики пальцев
    arms.push(pivot);
  }
  // ---- косметика (все предметы созданы заранее, включаются маской) ----
  const cosGroups = [];
  const mk = (bit, grp) => { grp.visible = false; cosGroups[bit] = grp; return grp; };
  // 0: банан на голове
  const banana = mk(0, new THREE.Group());
  head.add(banana);
  const bYellow = col(0xf5d90a), bBrown = col(0x6b4a1a);
  const bInner = new THREE.Group(); bInner.rotation.y = Math.PI / 2; bInner.position.y = 0.05; banana.add(bInner);
  const ARC = Math.PI * 0.72;
  const bMesh = add(new THREE.TorusGeometry(0.3, 0.075, 8, 16, ARC), bYellow, 0, 0, 0, bInner);
  bMesh.rotation.z = Math.PI / 2 - ARC / 2;
  for (const a of [0, ARC]) {
    const ang = Math.PI / 2 - ARC / 2 + a;
    add(ball(0.045), bBrown, Math.cos(ang) * 0.3, Math.sin(ang) * 0.3, 0, bInner);
  }
  // 1: белые перчатки (три полоски на тыльной стороне)
  const white = col(0xffffff);
  const gloves = mk(1, new THREE.Group());
  body.add(gloves);
  const gloveParts = [];
  for (const sx of [-1, 1]) {
    const gp = arms[sx < 0 ? 0 : 1];
    const g1 = add(ball(0.26), white, 0, -1.27, 0.02, gp);
    const g2 = add(new THREE.CylinderGeometry(0.19, 0.19, 0.14, 12), white, 0, -1.06, 0, gp);
    const l1 = [-0.07, 0, 0.07].map((dx) => add(new THREE.BoxGeometry(0.02, 0.13, 0.02), black, dx, -1.27, -0.25, gp));
    gloveParts.push(g1, g2, ...l1);
  }
  gloveParts.forEach((m) => { m.visible = false; });
  // 2: флаг игры за спиной (сверху чёрный, снизу белый с надписью)
  const flag = mk(2, new THREE.Group());
  flag.position.set(0, 1.66, -0.5); body.add(flag);
  const flagGeo = new THREE.PlaneGeometry(1.0, 1.2); flagGeo.translate(0, -0.6, 0);
  const flagMat = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });
  const ft = getFlagTexture(); if (ft) flagMat.map = ft;
  const flagMesh = new THREE.Mesh(flagGeo, flagMat); flagMesh.rotation.y = Math.PI; flag.add(flagMesh);
  // 3: официальный костюм: пиджак, рубашка, галстук, рукава
  const suit = mk(3, new THREE.Group());
  body.add(suit);
  const navy = col(0x1d2433), shirt = col(0xf4f4f4), tieRed = col(0xc62828);
  add(ball(0.66), navy, 0, 0.96, 0, suit, 1.04, 0.98, 0.9);
  add(ball(0.52), navy, 0, 1.42, 0, suit, 1.3, 0.66, 0.9);
  add(new THREE.BoxGeometry(0.28, 0.6, 0.04), shirt, 0, 1.2, 0.6, suit);
  add(new THREE.BoxGeometry(0.075, 0.5, 0.04), tieRed, 0, 1.12, 0.63, suit);
  add(new THREE.BoxGeometry(0.12, 0.09, 0.05), tieRed, 0, 1.4, 0.63, suit);
  const sleeves = [];
  for (const sx of [-1, 1]) {
    const lap = add(new THREE.BoxGeometry(0.08, 0.5, 0.04), col(0x2b354a), sx * 0.2, 1.15, 0.6, suit); lap.rotation.z = sx * 0.28;
    const sl = add(new THREE.CylinderGeometry(0.2, 0.2, 0.62, 12), navy, 0, -0.42, 0, arms[sx < 0 ? 0 : 1]); sl.visible = false; sleeves.push(sl);
  }

  const furTmp = new THREE.Color();
  function setLook(hex, mask) {
    if (hex == null) { fur.color.setHex(0x17171c); furLight.color.setHex(0x2c2c33); }
    else { fur.color.setHex(hex); furTmp.setHex(hex); furLight.color.copy(furTmp.multiplyScalar(1.3)); }
    cosGroups.forEach((grp, i) => { grp.visible = !!((mask >> i) & 1); });
    gloves.visible = false; // перчатки — на руках, управляем ими отдельно
    for (const gpart of gloveParts) gpart.visible = !!((mask >> 1) & 1);
    for (const sl of sleeves) sl.visible = !!((mask >> 3) & 1);
  }

  body.rotation.x = 0.06;
  let phase = 0, flagSwing = 0;

  return {
    object: root,
    setLook,
    // speed 0..1, air — в воздухе
    animate(dt, speed, air) {
      phase += dt * (6 + speed * 8);
      const s = Math.sin(phase);
      if (air) { // в прыжке руки раскинуты в стороны, как на рисунке
        arms[0].rotation.x = arms[1].rotation.x = 0;
        arms[0].rotation.z = -1.25; arms[1].rotation.z = 1.25;
      } else {
        // ходьба на руках: руки поочерёдно упираются в землю и отталкиваются, тело качается
        const a = speed * 1.0;
        arms[0].rotation.x = s * a; arms[1].rotation.x = -s * a;
        arms[0].rotation.z = -0.1; arms[1].rotation.z = 0.1;
      }
      body.rotation.x = air ? 0.05 : 0.06 + speed * 0.14;
      body.position.y = air ? 0 : Math.abs(Math.sin(phase)) * 0.07 * speed;
      head.rotation.y = 0;
      flagSwing = speed; flag.rotation.x = 0.06 + speed * 0.28 + Math.sin(phase * 0.5) * 0.05 * (0.4 + speed);
    },
    // меню: руки раскинуты и слегка покачиваются
    beat(t) {
      arms[0].rotation.x = arms[1].rotation.x = 0;
      arms[0].rotation.z = -1.35 + Math.sin(t * 3) * 0.12;
      arms[1].rotation.z = 1.35 - Math.sin(t * 3 + 1) * 0.12;
      body.position.y = Math.abs(Math.sin(t * 3)) * 0.04;
      head.rotation.y = Math.sin(t * 1.3) * 0.35;
      flag.rotation.x = 0.08 + Math.sin(t * 2) * 0.05;
    },
  };
}
