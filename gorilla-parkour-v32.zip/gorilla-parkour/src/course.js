// Генерация трассы: спиральная башня высотой 1000 м вокруг центральной колонны.
// Всегда одна и та же (фиксированный seed), чтобы у всех игроков трасса была одинаковой.
// Чистый JS без three.js — используется и в игре, и в scripts/verify.mjs.
import { P, SPIKE_CYCLE } from './physics.js';

export const CP_HEIGHTS = [50, 150, 350, 555, 750, 900];
export const FINISH_H = 1000;
export const TOWER_R = 3.6;      // радиус центральной колонны
export const PATH_R = 11;        // средний радиус спирали
export const GROUND_R = 45;      // остров в основании
export const PLAZA_R = 5.5;      // чекпоинт-площадка
export const SUMMIT_R = 5.8;     // вершина
export const LEDGE_STEP = 36;                 // балкон-«страховка» каждые ~36 м
export const LEDGE_THICK = 0.8;
export const LEDGE_OUT = { rIn: 14.5, rOut: 17.3 };
export const LEDGE_IN = { rIn: TOWER_R, rOut: 6.8 };
export const SPIN_W = 0.9;     // скорость вращения лопастей, рад/с
export const MOVER_T = 7;      // период езды едущей платформы, с (туда и обратно)
export const ZONE_BOUNDS = [150, 350, 555, 750, 900];
export const ZONE_NAMES = ['Джунгли', 'Руины', 'Завод', 'Небеса', 'Ледник', 'Золотая вершина'];

export function zoneAt(h) {
  let z = 0;
  for (const b of ZONE_BOUNDS) if (h >= b) z++;
  return z;
}

export function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Время, когда прыжок на нисходящей ветке снова оказывается на высоте dy, и пройденное по горизонтали расстояние.
export function tDesc(dy) {
  const disc = P.JUMP_V * P.JUMP_V - 2 * P.GRAVITY * dy;
  if (disc < 0) return 0;
  return (P.JUMP_V + Math.sqrt(disc)) / P.GRAVITY;
}
export function reach(dy) { return P.SPEED * tDesc(dy); }

/* ---------- геометрия ---------- */
function rectPoly(s) {
  const pts = [];
  for (const [a, b] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
    const lx = a * s.hx, lz = b * s.hz;
    pts.push([s.x + lx * s.c - lz * s.s, s.z + lx * s.s + lz * s.c]);
  }
  return pts;
}
function ptSegDist(px, pz, ax, az, bx, bz) {
  const abx = bx - ax, abz = bz - az;
  const l2 = abx * abx + abz * abz;
  let t = l2 > 0 ? ((px - ax) * abx + (pz - az) * abz) / l2 : 0;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return Math.hypot(px - (ax + abx * t), pz - (az + abz * t));
}
function satOverlap(A, B) {
  for (const poly of [A, B]) {
    for (let i = 0; i < 4; i++) {
      const p = poly[i], q = poly[(i + 1) % 4];
      const nx = -(q[1] - p[1]), nz = q[0] - p[0];
      let minA = Infinity, maxA = -Infinity, minB = Infinity, maxB = -Infinity;
      for (const v of A) { const d = v[0] * nx + v[1] * nz; if (d < minA) minA = d; if (d > maxA) maxA = d; }
      for (const v of B) { const d = v[0] * nx + v[1] * nz; if (d < minB) minB = d; if (d > maxB) maxB = d; }
      if (maxA < minB || maxB < minA) return false;
    }
  }
  return true;
}
// Расстояние между основаниями двух тел в плоскости XZ (<0 — пересекаются)
export function shapeDist(a, b) {
  if (a.type === 'cyl' && b.type === 'cyl') return Math.hypot(a.x - b.x, a.z - b.z) - a.r - b.r;
  if (a.type === 'cyl' || b.type === 'cyl') {
    const c = a.type === 'cyl' ? a : b, r = a.type === 'cyl' ? b : a;
    const dx = c.x - r.x, dz = c.z - r.z;
    const lx = dx * r.c + dz * r.s, lz = -dx * r.s + dz * r.c;
    const ex = Math.max(Math.abs(lx) - r.hx, 0), ez = Math.max(Math.abs(lz) - r.hz, 0);
    const d = Math.hypot(ex, ez);
    return d === 0 ? -c.r : d - c.r;
  }
  const A = rectPoly(a), B = rectPoly(b);
  if (satOverlap(A, B)) return -1;
  let m = Infinity;
  for (const p of A) for (let i = 0; i < 4; i++) { const q = B[i], r = B[(i + 1) % 4]; m = Math.min(m, ptSegDist(p[0], p[1], q[0], q[1], r[0], r[1])); }
  for (const p of B) for (let i = 0; i < 4; i++) { const q = A[i], r = A[(i + 1) % 4]; m = Math.min(m, ptSegDist(p[0], p[1], q[0], q[1], r[0], r[1])); }
  return m;
}
function farExtent(s) {
  if (s.type === 'cyl') return Math.hypot(s.x, s.z) + s.r;
  let m = 0;
  for (const p of rectPoly(s)) m = Math.max(m, Math.hypot(p[0], p[1]));
  return m;
}
function nearExtent(s) {
  if (s.type === 'cyl') return Math.hypot(s.x, s.z) - s.r;
  const P4 = rectPoly(s);
  let m = Infinity;
  for (let i = 0; i < 4; i++) { const a = P4[i], b = P4[(i + 1) % 4]; m = Math.min(m, ptSegDist(0, 0, a[0], a[1], b[0], b[1])); }
  return m;
}

/* ---------- генерация ---------- */
export function generateCourse(seed = 20261102) {
  const rnd = mulberry32(seed);
  const R = (a, b) => a + (b - a) * rnd();
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  const ground = { type: 'cyl', x: 0, z: 0, r: GROUND_R, top: 0, bottom: -60, kind: 'ground' };
  const pillar = { type: 'cyl', x: 0, z: 0, r: TOWER_R, top: FINISH_H + 40, bottom: -60, kind: 'pillar' };
  const solids = [ground, pillar];
  const path = [];
  const checkpoints = [];

  const startPad = { type: 'cyl', x: PATH_R, z: 0, r: 4.5, top: 0, bottom: -1, kind: 'start' };
  const start = { x: PATH_R, y: 0, z: 0, r: 4.5 };

  const startEl = { kind: 'start', main: startPad, coll: startPad, entry: startPad, exit: startPad, solids: [startPad], land: [startPad] };
  let theta = 0, prev = startEl, y = 0, cpIdx = 0, lastSpecial = false;
  let stepsSinceRest = 0, restEvery = Math.round(R(20, 28));
  let wave = { amp: R(0.5, 2), phase: R(0, 6.28) };
  const spinBars = [], movers = [], hazards = [];

  const pickDy = () => {
    const r = rnd();
    if (r < 0.2) return R(0.7, 0.95);
    if (r < 0.75) return R(0.95, 1.3);
    return R(1.3, 1.5);
  };

  const rollSpec = (h) => {
    const r = rnd();
    const pPole = 0.01 + 0.07 * h, pBeam = 0.05 + 0.10 * h, pCyl = 0.34;
    const thick = R(0.5, 1.1);
    if (r < pPole) return { type: 'cyl', r: R(0.9, 1.1), thick: R(1.2, 2.2), kind: 'pole' };
    if (r < pPole + pBeam) return { type: 'box', hx: R(1.9, 2.6), hz: R(0.6, 0.8), thick, kind: 'beam', yawJit: R(-0.25, 0.25) };
    if (r < pPole + pBeam + pCyl) return { type: 'cyl', r: lerp(1.7, 1.05, h) + R(-0.15, 0.3), thick, kind: 'barrel' };
    const s = lerp(3.1, 2.0, h) + R(-0.25, 0.35);
    return { type: 'box', hx: (s / 2) * R(0.9, 1.15), hz: (s / 2) * R(0.9, 1.15), thick, kind: 'crate', yawJit: R(-0.5, 0.5) };
  };

  // ---------- элементы трассы ----------
  // Каждый элемент: main (основное тело), coll (охватывающая фигура для проверки пересечений),
  // entry/exit (откуда/куда прыгаем — для проверки проходимости), solids (всё, что идёт в физику), land (на что можно приземлиться).
  const boxS = (x, z, hx, hz, yaw, top, thick, kind) => ({ type: 'box', x, z, hx, hz, yaw, c: Math.cos(yaw), s: Math.sin(yaw), top, bottom: top - thick, kind });
  const cylS = (x, z, r, top, thick, kind) => ({ type: 'cyl', x, z, r, top, bottom: top - thick, kind });

  const makeNormal = (spec, Rn, th, top) => {
    const x = Rn * Math.cos(th), z = Rn * Math.sin(th);
    const s = spec.type === 'cyl' ? cylS(x, z, spec.r, top, spec.thick, spec.kind)
      : boxS(x, z, spec.hx, spec.hz, th + Math.PI / 2 + (spec.yawJit || 0), top, spec.thick, spec.kind);
    return { kind: spec.kind, main: s, coll: s, entry: s, exit: s, solids: [s], land: [s], thAfter: th };
  };

  // Крутящаяся платформа: неподвижная втулка (всегда можно встать) + две вращающиеся перекладины-«пропеллер».
  const makeSpinner = (rp, Rn, th, top) => {
    const x = Rn * Math.cos(th), z = Rn * Math.sin(th);
    const hub = cylS(x, z, 1.3, top, 1.2, 'spinner');
    const bars = [0, 1].map((i) => {
      const b = boxS(x, z, 2.2, 0.8, rp.ph + (i * Math.PI) / 2, top - 0.12, 0.6, 'spinbar');
      b.dyn = 'spin'; b.yaw0 = b.yaw; b.w = rp.dir * SPIN_W; b.dyaw = 0;
      return b;
    });
    const coll = cylS(x, z, 2.2, top, 1.2, 'coll');
    return { kind: 'spinner', main: hub, coll, entry: hub, exit: hub, solids: [hub, ...bars], land: [hub, ...bars], bars, thAfter: th };
  };

  // Едущая платформа: ходит туда-сюда вдоль касательной к спирали. Концы пути — рядом с обычными платформами.
  const makeMover = (rp, Rn, th, top) => {
    const L = rp.L, tx = -Math.sin(th), tz = Math.cos(th);
    const cx = Rn * Math.cos(th), cz = Rn * Math.sin(th), yaw = th + Math.PI / 2;
    const ax = cx - (tx * L) / 2, az = cz - (tz * L) / 2, bx = cx + (tx * L) / 2, bz = cz + (tz * L) / 2;
    const m = boxS(ax, az, 1.7, 1.4, yaw, top, 0.7, 'mover');
    Object.assign(m, { dyn: 'slide', ax, az, bx, bz, T: MOVER_T, ph: rp.mph, dx: 0, dz: 0 });
    const k0 = 0.5 - 0.5 * Math.cos(m.ph);
    m.x = ax + (bx - ax) * k0; m.z = az + (bz - az) * k0; m.k = k0;
    const entry = boxS(ax, az, 1.7, 1.4, yaw, top, 0.7, 'mover');
    const exit = boxS(bx, bz, 1.7, 1.4, yaw, top, 0.7, 'mover');
    const coll = boxS(cx, cz, L / 2 + 1.7, 1.4, yaw, top, 0.7, 'coll');
    return { kind: 'mover', main: m, coll, entry, exit, solids: [m], land: [m], thAfter: th + Math.atan2(L / 2, Rn) };
  };

  // Платформа с шипами: по краям безопасные площадки (1.4 м), посередине полоса шипов (1.8 м), шипы торчат 4 с.
  const makeSpike = (rp, Rn, th, top) => {
    const hx = 2.3, hz = 1.5, tx = -Math.sin(th), tz = Math.cos(th);
    const cx = Rn * Math.cos(th), cz = Rn * Math.sin(th), yaw = th + Math.PI / 2;
    const main = boxS(cx, cz, hx, hz, yaw, top, 0.9, 'spikeplat');
    const end = (sg) => boxS(cx + sg * tx * (hx - 0.7), cz + sg * tz * (hx - 0.7), 0.7, hz, yaw, top, 0.9, 'safe');
    const hazard = { x: cx, z: cz, c: main.c, s: main.s, hx: 0.9, hz, top, phase: rp.sph, yaw };
    return { kind: 'spike', main, coll: main, entry: end(-1), exit: end(1), solids: [main], land: [main], hazard, thAfter: th };
  };

  let guard = 0;
  while (guard++ < 3000) {
    const h = y / FINISH_H;
    const nextH = cpIdx < CP_HEIGHTS.length ? CP_HEIGHTS[cpIdx] : FINISH_H;
    const remain = nextH - y;
    let dy, isPlaza = false;
    if (remain <= 1.45) { dy = remain; isPlaza = true; }
    else { dy = pickDy(); if (remain - dy < 0.5) dy = remain - 0.5; }
    const isFinish = isPlaza && cpIdx >= CP_HEIGHTS.length;

    let spec, special = null;
    if (isPlaza) spec = { type: 'cyl', r: isFinish ? SUMMIT_R : PLAZA_R, thick: 1.6, kind: isFinish ? 'summit' : 'plaza' };
    else if (stepsSinceRest >= restEvery) spec = { type: 'box', hx: 2.1, hz: 2.1, thick: R(0.7, 1.0), kind: 'rest', yawJit: R(-0.4, 0.4) };
    else if (!lastSpecial && y > 20 && remain > 12 && rnd() < lerp(0.12, 0.22, h)) {
      special = ['spinner', 'mover', 'spike'][Math.floor(rnd() * 3)];
      spec = { kind: special };
      if (special === 'spinner') dy = Math.min(dy, 1.3);
    } else { spec = rollSpec(h); if (spec.kind === 'pole' && (dy > 1.15 || prev.kind === 'mover' || prev.kind === 'spinner' || prev.kind === 'spike')) spec = { type: 'cyl', r: 1.5, thick: 0.9, kind: 'barrel' }; }
    const newY = y + dy;
    const rp = { dir: rnd() < 0.5 ? 1 : -1, ph: rnd() * Math.PI, L: R(4.0, 5.2), mph: rnd() * Math.PI * 2, sph: rnd() * SPIKE_CYCLE };
    const mk = (Rn, th) => (special === 'spinner' ? makeSpinner(rp, Rn, th, newY)
      : special === 'mover' ? makeMover(rp, Rn, th, newY)
      : special === 'spike' ? makeSpike(rp, Rn, th, newY)
      : makeNormal(spec, Rn, th, newY));

    const rch = reach(dy);
    const fracMax = lerp(0.42, 0.70, h);
    let target = rch * R(fracMax * 0.55, fracMax);
    if (spec.kind === 'pole' || spec.kind === 'beam' || special === 'spinner') target *= 0.85;
    if (spec.kind === 'rest') target *= 0.8;
    if (isPlaza) target = Math.min(target, 2.2);
    target = Math.max(target, 0.9);
    const maxGap = rch * (spec.kind === 'pole' || special === 'spinner' ? 0.6 : spec.kind === 'beam' ? 0.68 : 0.74);
    const bigMin = special === 'spinner' || prev.kind === 'spinner' ? 1.5 : 0; // чтобы лопасти не задевали соседей

    // радиус спирали плавно «гуляет», чтобы прыжки были не только по кругу
    wave.phase += 0.45;
    if (path.length % 30 === 0) wave.amp = R(0.3, 1.5);
    const baseR = isPlaza ? PATH_R : clamp(PATH_R + wave.amp * Math.sin(wave.phase) + R(-0.3, 0.3), 9.6, 12.2);

    let best = null;
    const radii = [baseR, PATH_R, PATH_R - 0.8, PATH_R + 0.8, PATH_R - 1.3, PATH_R + 1.0];
    for (let attempt = 0; attempt < 24 && !best; attempt++) {
      const Rn = attempt < radii.length ? radii[attempt] : R(9.6, 12.2);
      const minGap = Math.max(attempt < 8 ? 0.7 : 0.5, bigMin);
      for (let k = 1; k <= 90; k++) {
        const th = theta + k * 0.0175;
        const el = mk(Rn, th);
        if (isPlaza) { if (farExtent(el.coll) > 17.0) continue; }
        else if (farExtent(el.coll) > 14.2 || nearExtent(el.coll) < 7.0) continue;
        const gap = shapeDist(prev.exit, el.entry);
        if (gap < minGap || gap > maxGap) continue;
        if (shapeDist(pillar, el.coll) < 1.2) continue;
        if ((special || prev.kind === 'mover' || prev.kind === 'spinner') && shapeDist(prev.coll, el.coll) < 0.4) continue;
        let ok = true;
        for (let j = path.length - 1; j >= Math.max(0, path.length - 18); j--) {
          const q = path[j];
          if (q === prev || Math.abs(q.coll.top - newY) > 6) continue;
          if (shapeDist(q.coll, el.coll) < 0.6) { ok = false; break; }
        }
        if (!ok) continue;
        const score = Math.abs(gap - target);
        if (!best || score < best.score) best = { el, th, score };
      }
    }
    if (!best) throw new Error('Не удалось сгенерировать трассу на высоте ' + y.toFixed(1) + (special ? ' (' + special + ')' : ''));

    const el = best.el;
    theta = el.thAfter;
    prev = el;
    y = newY;
    solids.push(...el.solids);
    el.zone = zoneAt(newY); el.isPlaza = isPlaza; el.cpIndex = isPlaza ? cpIdx : -1;
    path.push(el);
    if (el.bars) spinBars.push(...el.bars);
    if (el.kind === 'mover') movers.push(el.main);
    if (el.hazard) hazards.push(el.hazard);
    lastSpecial = !!special;

    if (isPlaza) {
      checkpoints.push({
        index: cpIdx, height: nextH, x: el.main.x, y: newY, z: el.main.z, r: spec.r,
        solid: el.main, finish: isFinish,
      });
      cpIdx++;
      stepsSinceRest = 0; restEvery = Math.round(R(20, 28));
      if (isFinish) break;
    } else if (spec.kind === 'rest') {
      stepsSinceRest = 0; restEvery = Math.round(R(20, 28));
    } else stepsSinceRest++;
  }

  // балконы: кольца у стены и у колонны — ловят падающего игрока, чтобы падение не стоило сотен метров
  const ledges = [];
  for (let k = 1; k * LEDGE_STEP < FINISH_H - 20; k++) {
    const top = k * LEDGE_STEP;
    if (checkpoints.some((c) => Math.abs(c.y - top) < 7)) continue;
    for (const r of [LEDGE_OUT, LEDGE_IN]) {
      const l = { type: 'ring', x: 0, z: 0, rIn: r.rIn, rOut: r.rOut, top, bottom: top - LEDGE_THICK, kind: 'ledge' };
      ledges.push(l);
      solids.push(l);
    }
  }

  return { solids, path, checkpoints, ledges, start, startPad, startEl, ground, pillar, spinBars, movers, hazards };
}
