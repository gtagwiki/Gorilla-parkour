// Сохранения и лидерборд.
// Прогресс и ник — localStorage (на Android лежит в данных приложения и переживает перезапуск).
// Лидерборд: если задан VITE_API_URL (см. README) — общий онлайн через server/server.js, иначе локальный на устройстве.
const KEY_SAVE = 'gp_save_v1';
const KEY_NICK = 'gp_nick_v1';
const KEY_LB = 'gp_lb_v1';
const API = (import.meta.env && import.meta.env.VITE_API_URL ? String(import.meta.env.VITE_API_URL) : '').replace(/\/+$/, '');

const get = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const set = (k, v) => { try { localStorage.setItem(k, v); } catch { /* ignore */ } };
const del = (k) => { try { localStorage.removeItem(k); } catch { /* ignore */ } };

export function loadNick() { return get(KEY_NICK) || ''; }
export function saveNick(n) { set(KEY_NICK, n); }

// save: { cp: -1..6, t: секунды, best: макс. высота, pos: {x,y,z} }
export function loadSave() {
  try {
    const s = JSON.parse(get(KEY_SAVE) || 'null');
    if (!s || typeof s.t !== 'number' || !s.pos) return null;
    return s;
  } catch { return null; }
}
export function writeSave(s) { set(KEY_SAVE, JSON.stringify(s)); }
export function clearSave() { del(KEY_SAVE); }

export function validNick(raw) {
  const n = (raw || '').replace(/\s+/g, ' ').trim();
  if (n.length < 2) return { ok: false, err: 'Ник слишком короткий (минимум 2 символа)' };
  if (n.length > 14) return { ok: false, err: 'Ник слишком длинный (максимум 14)' };
  if (!/^[\p{L}\p{N}_\- .]+$/u.test(n)) return { ok: false, err: 'Только буквы, цифры, пробел, _ - .' };
  return { ok: true, nick: n };
}

function localTop() {
  try { const a = JSON.parse(get(KEY_LB) || '[]'); return Array.isArray(a) ? a : []; } catch { return []; }
}

export const isOnline = () => !!API;

export async function submitScore(nick, time) {
  // локально сохраняем всегда (лучший результат ника)
  const list = localTop();
  const ex = list.find((e) => e.nick.toLowerCase() === nick.toLowerCase());
  if (ex) { if (time < ex.time) { ex.time = time; ex.date = Date.now(); ex.nick = nick; } }
  else list.push({ nick, time, date: Date.now() });
  list.sort((a, b) => a.time - b.time);
  set(KEY_LB, JSON.stringify(list.slice(0, 50)));
  if (API) {
    try {
      await fetch(API + '/score', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nick, time }) });
    } catch { /* офлайн — останется в локальном списке */ }
  }
}

// -> { list: [{nick,time}], online: bool }
export async function getTop() {
  if (API) {
    try {
      const r = await fetch(API + '/leaderboard', { cache: 'no-store' });
      if (r.ok) {
        const list = await r.json();
        if (Array.isArray(list)) return { list: list.slice(0, 10), online: true };
      }
    } catch { /* fallthrough */ }
  }
  return { list: localTop().slice(0, 10), online: false };
}

export function fmtTime(sec) {
  sec = Math.max(0, sec);
  const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
  const cs = Math.floor((sec * 100) % 100);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
}
