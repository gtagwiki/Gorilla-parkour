// Хэш пароля админа (сам пароль здесь не хранится). Чтобы сменить пароль: см. README, раздел «Админ».
export const ADMIN_HASH = '17sug5yvqc1';

// Адрес общей базы Firebase Realtime Database (не секрет: он и так виден в любом приложении).
export const DB_URL = 'https://gorilla-parkour-default-rtdb.firebaseio.com';

// Необязательно: свой TURN-сервер для голосового чата (помогает тем, у кого не соединяется напрямую).
// Пример: { urls: ['turn:example.com:3478'], username: 'user', credential: 'pass' }. Пусто — работает только через STUN.
export const TURN = null;
