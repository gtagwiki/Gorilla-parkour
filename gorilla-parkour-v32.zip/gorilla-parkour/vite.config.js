import { defineConfig } from 'vite';

export default defineConfig({
  base: './',            // относительные пути — нужно для Capacitor/Android WebView
  build: { outDir: 'dist', chunkSizeWarningLimit: 1500 },
});
