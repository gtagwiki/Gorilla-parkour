// Проверка проходимости трассы: «бот» прыгает с каждой платформы на следующую,
// используя ТУ ЖЕ физику, что и игра. Запуск: npm run verify
//  • обычные прыжки проверяются с ошибкой тайминга;
//  • едущие платформы — в крайних положениях (у начала и у конца пути);
//  • крутящиеся — при нескольких положениях лопастей;
//  • платформы с шипами — прыжок на безопасные края (шипы в середине);
//  • отдельно проверяется, что движущиеся платформы действительно ПЕРЕВОЗЯТ игрока.
import { generateCourse, CP_HEIGHTS, FINISH_H, shapeDist, reach, MOVER_T } from '../src/course.js';
import { World, makeBody, stepBody, P, SPIKE_CYCLE } from '../src/physics.js';

const course = generateCourse();
const world = new World(course.solids);
const dt = 1 / 120;

function edgeDist(s, ux, uz) {
  if (s.type === 'cyl') return s.r;
  const lx = ux * s.c + uz * s.s, lz = -ux * s.s + uz * s.c;
  const tx = Math.abs(lx) > 1e-9 ? s.hx / Math.abs(lx) : Infinity;
  const tz = Math.abs(lz) > 1e-9 ? s.hz / Math.abs(lz) : Infinity;
  return Math.min(tx, tz);
}

// Ставим движущиеся тела элемента в нужное положение (время заморожено — мир не обновляется)
function setSlide(m, k) { m.x = m.ax + (m.bx - m.ax) * k; m.z = m.az + (m.bz - m.az) * k; m.dx = m.dz = 0; }
function setBars(el, ang) {
  el.bars.forEach((b, i) => { b.yaw = ang + (i * Math.PI) / 2; b.c = Math.cos(b.yaw); b.s = Math.sin(b.yaw); b.dyaw = 0; });
}

// back — за сколько метров ДО края игрок отрывается от земли (ошибка тайминга), mag — доля максимальной скорости
function simulate(a, b, back, mag = 1) {
  const A = a.exit, B = b.entry;
  const dx = B.x - A.x, dz = B.z - A.z, L = Math.hypot(dx, dz);
  const ux = dx / L, uz = dz / L;
  const edge = edgeDist(A, ux, uz);
  const jumpAt = edge - back;
  const startD = Math.max(-edge + 0.3, jumpAt - 1.2); // разбег не более 1.2 м
  const body = makeBody(A.x + ux * startD, A.top, A.z + uz * startD);
  for (let i = 0; i < 6; i++) stepBody(body, { mx: 0, mz: 0, jump: false }, dt, world);
  let jumped = false;
  for (let i = 0; i < 720; i++) {
    const along = (body.x - A.x) * ux + (body.z - A.z) * uz;
    const tdx = B.x - body.x, tdz = B.z - body.z, td = Math.hypot(tdx, tdz);
    let mx = ux * mag, mz = uz * mag;
    if (jumped) {
      if (td < 0.25) { mx = 0; mz = 0; } else { mx = (tdx / td) * mag; mz = (tdz / td) * mag; }
    }
    const wantJump = !jumped && along >= jumpAt;
    stepBody(body, { mx, mz, jump: wantJump }, dt, world);
    if (wantJump && body.vy > 0) jumped = true;
    if (jumped && body.grounded) return b.land.includes(body.onSolid);
    if (body.y < B.top - 8) return false;
  }
  return false;
}

const seq = [course.startEl, ...course.path];
const variants = [
  { name: 'отрыв у самого края', back: 0, mag: 1, must: true },
  { name: 'отрыв за 0.3 м до края', back: 0.3, mag: 1, must: true },
  { name: 'отрыв за 0.6 м до края', back: 0.6, mag: 1, must: true },
  { name: 'усталый игрок (85% скорости, -0.3 м)', back: 0.3, mag: 0.85, must: false },
];

let failed = 0;
const stats = variants.map(() => 0);
const ANGLES = [0, 0.45, 0.9, 1.35];
for (let i = 0; i < seq.length - 1; i++) {
  const a = seq[i], b = seq[i + 1];
  if (a.kind === 'mover') setSlide(a.main, 1);       // уезжаем в конец пути — оттуда прыгаем дальше
  if (b.kind === 'mover') setSlide(b.main, 0);       // а запрыгиваем на неё, когда она у начала пути
  const angles = a.bars || b.bars ? ANGLES : [0];
  variants.forEach((v, vi) => {
    let ok = true;
    for (const ang of angles) {
      if (a.bars) setBars(a, ang);
      if (b.bars) setBars(b, ang);
      if (!simulate(a, b, v.back, v.mag)) { ok = false; break; }
    }
    if (ok) stats[vi]++;
    else if (v.must) {
      failed++;
      if (failed <= 15) console.log(`  ✗ шаг ${i}→${i + 1} (${a.kind}→${b.kind}), высота ${b.main.top.toFixed(1)} м, вариант "${v.name}"`);
    }
  });
}

// ---- переезд: игрок стоит на едущей платформе и должен доехать вместе с ней ----
let rideFail = 0, rides = 0;
for (const m of course.movers) {
  const t0 = MOVER_T * (1 - m.ph / (2 * Math.PI));        // момент, когда платформа в начале пути (k = 0)
  let t = t0;
  world.update(t);
  const body = makeBody(m.x, m.top, m.z);
  for (let i = 0; i < 6; i++) { t += dt; world.update(t); stepBody(body, { mx: 0, mz: 0, jump: false }, dt, world); }
  const steps = Math.round((MOVER_T / 2) / dt);
  for (let i = 0; i < steps; i++) { t += dt; world.update(t); stepBody(body, { mx: 0, mz: 0, jump: false }, dt, world); }
  rides++;
  const off = Math.hypot(body.x - m.x, body.z - m.z);
  if (body.onSolid !== m || off > 0.3 || m.k < 0.97) { rideFail++; if (rideFail <= 5) console.log(`  ✗ платформа не довезла: off=${off.toFixed(2)} k=${m.k.toFixed(2)}`); }
}
// ---- вращение: игрок на лопасти должен вращаться вместе с ней и не слетать ----
let spinFail = 0, spins = 0;
for (const el of course.path.filter((e) => e.bars)) {
  const bar = el.bars[0];
  let t = 0;
  world.update(t);
  const r0 = 1.7;
  const body = makeBody(bar.x + Math.cos(bar.yaw) * r0, bar.top, bar.z + Math.sin(bar.yaw) * r0);
  for (let i = 0; i < 6; i++) { t += dt; world.update(t); stepBody(body, { mx: 0, mz: 0, jump: false }, dt, world); }
  for (let i = 0; i < Math.round(4 / dt); i++) { t += dt; world.update(t); stepBody(body, { mx: 0, mz: 0, jump: false }, dt, world); }
  spins++;
  const r1 = Math.hypot(body.x - bar.x, body.z - bar.z);
  if (!body.grounded || Math.abs(r1 - r0) > 0.25 || !el.land.includes(body.onSolid)) spinFail++;
}

const n = seq.length - 1;
let maxGap = 0, sumDy = 0, maxDy = 0, minGap = 99, sumGap = 0;
const kinds = {};
for (let i = 0; i < n; i++) {
  const a = seq[i], b = seq[i + 1];
  const g = shapeDist(a.exit, b.entry), dy = b.main.top - a.main.top;
  maxGap = Math.max(maxGap, g); minGap = Math.min(minGap, g); sumGap += g;
  sumDy += dy; maxDy = Math.max(maxDy, dy);
  kinds[b.kind] = (kinds[b.kind] || 0) + 1;
}

// куда падает игрок, если сорвался с платформы (проверка «страховки» нижними витками)
const falls = [];
for (let i = 1; i < course.path.length; i += 3) {
  const el = course.path[i];
  if (el.kind === 'mover') setSlide(el.main, 0.5);
  const a = el.coll.type === 'cyl' ? el.coll : el.main;
  for (let k = 0; k < 6; k++) {
    const ang = (k / 6) * Math.PI * 2;
    const ux = Math.cos(ang), uz = Math.sin(ang);
    const e = edgeDist(a, ux, uz) + 0.45;
    const body = makeBody(a.x + ux * e, a.top, a.z + uz * e);
    let steps = 0;
    while (!body.grounded && steps++ < 4000) stepBody(body, { mx: 0, mz: 0, jump: false }, dt, world);
    if (body.grounded) falls.push(a.top - body.y);
  }
}
falls.sort((x, y) => x - y);
const pct = (p) => falls[Math.min(falls.length - 1, Math.floor(falls.length * p))] || 0;

console.log('— Проверка трассы —');
console.log(`Платформ в пути: ${course.path.length} (включая ${course.checkpoints.length} площадок-чекпоинтов)`);
console.log(`Прыжков: ${n}, средний подъём ${(sumDy / n).toFixed(2)} м, макс. ${maxDy.toFixed(2)} м (потолок прыжка ≈ ${(P.JUMP_V ** 2 / (2 * P.GRAVITY)).toFixed(2)} м)`);
console.log(`Зазор между платформами: мин ${minGap.toFixed(2)} м, средний ${(sumGap / n).toFixed(2)} м, макс ${maxGap.toFixed(2)} м`);
console.log('Чекпоинты:', course.checkpoints.map((c) => c.height + ' м').join(', '));
const okCp = course.checkpoints.every((c, i) => Math.abs(c.y - (CP_HEIGHTS[i] ?? FINISH_H)) < 1e-6);
console.log('Высоты чекпоинтов точные:', okCp ? 'да' : 'НЕТ');
console.log('Виды платформ:', JSON.stringify(kinds));
console.log(`Спецплатформы: крутящихся ${course.path.filter((e) => e.bars).length}, едущих ${course.movers.length}, с шипами ${course.hazards.length} (цикл шипов ${SPIKE_CYCLE.toFixed(1)} с)`);
variants.forEach((v, vi) => console.log(`  ${v.must ? '[обязательно]' : '[справочно]  '} ${v.name}: ${stats[vi]}/${n}`));
console.log(`Перевозка едущими платформами: ${rides - rideFail}/${rides}; вращение уносит игрока вместе: ${spins - spinFail}/${spins}`);
console.log(`Падение при срыве (м): медиана ${pct(0.5).toFixed(1)}, 75% ${pct(0.75).toFixed(1)}, 90% ${pct(0.9).toFixed(1)}`);
const secs = [1.6, 2.0, 2.4].map((s) => ((n * s) / 60).toFixed(0));
console.log(`Оценка времени прохождения без падений: ${secs[0]}–${secs[2]} мин (при 1.6–2.4 с на платформу, без ожидания шипов и платформ)`);

if (failed > 0 || rideFail > 0 || spinFail > 0 || !okCp) {
  console.log(`\nПРОВАЛ: ${failed} непроходимых прыжков, ${rideFail} сбоев перевозки, ${spinFail} сбоев вращения`);
  process.exit(1);
}
console.log('\nOK: все прыжки проходимы.');
