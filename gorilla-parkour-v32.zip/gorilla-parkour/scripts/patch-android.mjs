// Запускается автоматически после `npx cap sync`: добавляет разрешение на микрофон (для голосового чата).
import fs from 'node:fs';
const f = 'android/app/src/main/AndroidManifest.xml';
if (fs.existsSync(f)) {
  let s = fs.readFileSync(f, 'utf8');
  const add = [];
  for (const p of ['RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS']) if (!s.includes('android.permission.' + p)) add.push('    <uses-permission android:name="android.permission.' + p + '" />');
  if (add.length) {
    s = s.replace('</manifest>', add.join('\n') + '\n</manifest>');
    fs.writeFileSync(f, s);
    console.log('Добавлены разрешения:', add.length);
  }
}
