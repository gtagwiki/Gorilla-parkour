// Чистая физика без three.js — используется и в игре, и в scripts/verify.mjs (проверка проходимости).
// Мир: набор "тел" (solids): коробки (с поворотом по Y) и вертикальные цилиндры.
// Игрок: вертикальный цилиндр радиуса RADIUS и высотой HEIGHT, позиция = точка под ногами.

export const P = {
  SPEED: 8,          // м/с — скорость бега
  GROUND_ACC: 70,    // разгон на земле
  GROUND_DEC: 80,    // торможение на земле
  AIR_ACC: 28,       // управление в воздухе
  AIR_DEC: 6,        // замедление в воздухе без ввода
  JUMP_V: 11,        // начальная скорость прыжка (≈2.0 м высоты)
  GRAVITY: 30,
  MAX_FALL: 55,
  RADIUS: 0.38,
  HEIGHT: 1.7,
  STEP: 0.3,         // авто-подъём на небольшой уступ
  COYOTE: 0.12,      // можно прыгнуть сразу после схода с края
  JUMP_BUFFER: 0.12, // прыжок "запоминается" перед приземлением
  WALL_R: 17.5,      // невидимая стена вокруг башни
  WALL_Y: 3,
};

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

export class World {
  constructor(solids) {
    this.solids = solids;
    this.B = 8;
    this.buckets = new Map();
    this.stamp = 0;
    this.tmp = [];
    for (const s of solids) {
      const lo = Math.floor(s.bottom / this.B);
      const hi = Math.floor(s.top / this.B);
      for (let k = lo; k <= hi; k++) {
        let arr = this.buckets.get(k);
        if (!arr) { arr = []; this.buckets.set(k, arr); }
        arr.push(s);
      }
    }
  }
  query(y0, y1) {
    const out = this.tmp;
    out.length = 0;
    const stamp = ++this.stamp;
    const lo = Math.floor(y0 / this.B), hi = Math.floor(y1 / this.B);
    for (let k = lo; k <= hi; k++) {
      const arr = this.buckets.get(k);
      if (!arr) continue;
      for (let i = 0; i < arr.length; i++) {
        const s = arr[i];
        if (s._q !== stamp) { s._q = stamp; out.push(s); }
      }
    }
    return out;
  }
}

const _o = { nx: 0, nz: 0, pen: 0 };

// Пересечение круга (px,pz,rad) с основанием тела. Возвращает true и заполняет out (нормаль выталкивания, глубина).
export function circleVsSolid(s, px, pz, rad, out) {
  const dx = px - s.x, dz = pz - s.z;
  if (s.type === 'ring') {
    // кольцо-балкон вокруг оси башни (s.x = s.z = 0), rIn..rOut
    const d = Math.sqrt(dx * dx + dz * dz);
    if (d + rad <= s.rIn || d - rad >= s.rOut || d < 1e-6) return false;
    if (d < (s.rIn + s.rOut) / 2) { out.nx = -dx / d; out.nz = -dz / d; out.pen = d + rad - s.rIn; }
    else { out.nx = dx / d; out.nz = dz / d; out.pen = s.rOut + rad - d; }
    return true;
  }
  if (s.type === 'cyl') {
    const rr = s.r + rad;
    const d2 = dx * dx + dz * dz;
    if (d2 >= rr * rr) return false;
    const d = Math.sqrt(d2);
    if (d < 1e-6) { out.nx = 1; out.nz = 0; out.pen = rr; }
    else { out.nx = dx / d; out.nz = dz / d; out.pen = rr - d; }
    return true;
  }
  const lx = dx * s.c + dz * s.s;
  const lz = -dx * s.s + dz * s.c;
  const cx = clamp(lx, -s.hx, s.hx);
  const cz = clamp(lz, -s.hz, s.hz);
  const ex = lx - cx, ez = lz - cz;
  const d2 = ex * ex + ez * ez;
  if (d2 >= rad * rad) return false;
  let nxl, nzl, pen;
  if (d2 > 1e-10) {
    const d = Math.sqrt(d2);
    nxl = ex / d; nzl = ez / d; pen = rad - d;
  } else {
    const ox = s.hx - Math.abs(lx), oz = s.hz - Math.abs(lz);
    if (ox < oz) { nxl = lx >= 0 ? 1 : -1; nzl = 0; pen = ox + rad; }
    else { nxl = 0; nzl = lz >= 0 ? 1 : -1; pen = oz + rad; }
  }
  out.nx = nxl * s.c - nzl * s.s;
  out.nz = nxl * s.s + nzl * s.c;
  out.pen = pen;
  return true;
}

export function makeBody(x = 0, y = 0, z = 0) {
  return { x, y, z, vx: 0, vz: 0, vy: 0, grounded: false, coyote: 0, jumpBuf: 0, onSolid: null };
}

// inp: { mx, mz } — желаемое направление в мировых осях (длина ≤ 1), jump — зажата ли кнопка прыжка.
export function stepBody(b, inp, dt, world) {
  const hasIn = inp.mx * inp.mx + inp.mz * inp.mz > 1e-4;
  const tx = inp.mx * P.SPEED, tz = inp.mz * P.SPEED;
  const acc = b.grounded ? (hasIn ? P.GROUND_ACC : P.GROUND_DEC) : (hasIn ? P.AIR_ACC : P.AIR_DEC);
  const dvx = tx - b.vx, dvz = tz - b.vz;
  const dl = Math.hypot(dvx, dvz), md = acc * dt;
  if (dl <= md) { b.vx = tx; b.vz = tz; }
  else { b.vx += (dvx / dl) * md; b.vz += (dvz / dl) * md; }

  if (inp.jump) b.jumpBuf = P.JUMP_BUFFER; else b.jumpBuf -= dt;
  if (b.grounded) b.coyote = P.COYOTE; else b.coyote -= dt;
  if (b.jumpBuf > 0 && b.coyote > 0) {
    b.vy = P.JUMP_V; b.grounded = false; b.coyote = 0; b.jumpBuf = 0; b.onSolid = null;
  }

  const near = world.query(b.y - 1.5, b.y + P.HEIGHT + 1.5);

  // --- горизонталь ---
  b.x += b.vx * dt;
  b.z += b.vz * dt;
  for (let it = 0; it < 2; it++) {
    for (let i = 0; i < near.length; i++) {
      const s = near[i];
      if (b.y + 0.05 >= s.top || b.y + P.HEIGHT <= s.bottom) continue;
      if (!circleVsSolid(s, b.x, b.z, P.RADIUS, _o)) continue;
      if (s.top - b.y <= P.STEP && b.vy <= 0) { b.y = s.top; b.vy = 0; continue; }
      b.x += _o.nx * _o.pen;
      b.z += _o.nz * _o.pen;
      const vn = b.vx * _o.nx + b.vz * _o.nz;
      if (vn < 0) { b.vx -= vn * _o.nx; b.vz -= vn * _o.nz; }
    }
  }
  if (b.y > P.WALL_Y) {
    const r = Math.hypot(b.x, b.z);
    if (r > P.WALL_R) { const k = P.WALL_R / r; b.x *= k; b.z *= k; }
  }

  // --- вертикаль ---
  const prevY = b.y;
  b.vy -= P.GRAVITY * dt;
  if (b.vy < -P.MAX_FALL) b.vy = -P.MAX_FALL;
  let ny = prevY + b.vy * dt;
  b.grounded = false;
  b.onSolid = null;

  if (b.vy <= 0) {
    let best = -Infinity, bs = null;
    for (let i = 0; i < near.length; i++) {
      const s = near[i];
      if (s.top > best && prevY >= s.top - 0.06 && ny <= s.top + 1e-6 &&
          circleVsSolid(s, b.x, b.z, P.RADIUS * 0.55, _o)) {
        best = s.top; bs = s;
      }
    }
    if (bs) { ny = best; b.vy = 0; b.grounded = true; b.onSolid = bs; }
  } else {
    let ceil = Infinity;
    for (let i = 0; i < near.length; i++) {
      const s = near[i];
      if (prevY + P.HEIGHT <= s.bottom + 0.05 && ny + P.HEIGHT > s.bottom && s.bottom < ceil &&
          circleVsSolid(s, b.x, b.z, P.RADIUS * 0.8, _o)) {
        ceil = s.bottom;
      }
    }
    if (ceil < Infinity) { ny = ceil - P.HEIGHT; b.vy = 0; }
  }
  b.y = ny;
}
