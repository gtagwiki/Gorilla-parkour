// Проверка проходимости трассы: «бот» прыгает с каждой платформы на следующую,
// используя ТУ ЖЕ физику, что и игра. Запуск: npm run verify
import { generateCourse, CP_HEIGHTS, FINISH_H, ZONE_NAMES, shapeDist, reach } from '../src/course.js';
import { World, makeBody, stepBody, P } from '../src/physics.js';

const course = generateCourse();
const world = new World(course.solids);
const dt = 1 / 120;

function edgeDist(s, ux, uz) {
  if (s.type === 'cyl') return s.r;
  const lx = ux * s.c + uz * s.s, lz = -ux * s.s + uz * s.c;
  const tx = Math.abs(lx) > 1e-9 ? s.hx / Math.abs(lx) : Infinity;
  const tz = Math.abs(lz) > 1e-9 ? s.hz / Math.abs(lz) : Infinity;
  return Math.min(tx, tz);
}

// back — за сколько метров ДО края игрок отрывается от земли (ошибка тайминга), mag — доля максимальной скорости
function simulate(a, b, back, mag = 1) {
  const dx = b.x - a.x, dz = b.z - a.z, L = Math.hypot(dx, dz);
  const ux = dx / L, uz = dz / L;
  const edge = edgeDist(a, ux, uz);
  const jumpAt = edge - back;
  const startD = Math.max(-edge + 0.3, jumpAt - 1.2); // разбег не более 1.2 м
  const body = makeBody(a.x + ux * startD, a.top, a.z + uz * startD);
  for (let i = 0; i < 6; i++) stepBody(body, { mx: 0, mz: 0, jump: false }, dt, world);
  let jumped = false;
  for (let i = 0; i < 720; i++) {
    const along = (body.x - a.x) * ux + (body.z - a.z) * uz;
    const tdx = b.x - body.x, tdz = b.z - body.z, td = Math.hypot(tdx, tdz);
    let mx = ux * mag, mz = uz * mag;
    if (jumped) {
      if (td < 0.25) { mx = 0; mz = 0; } else { mx = (tdx / td) * mag; mz = (tdz / td) * mag; }
    }
    const wantJump = !jumped && along >= jumpAt;
    stepBody(body, { mx, mz, jump: wantJump }, dt, world);
    if (wantJump && body.vy > 0) jumped = true;
    if (jumped && body.grounded) return body.onSolid === b;
    if (body.y < b.top - 8) return false;
  }
  return false;
}

const seq = [{ solid: course.startPad, kind: 'start' }, ...course.path];
const variants = [
  { name: 'отрыв у самого края', back: 0, mag: 1, must: true },
  { name: 'отрыв за 0.3 м до края', back: 0.3, mag: 1, must: true },
  { name: 'отрыв за 0.6 м до края', back: 0.6, mag: 1, must: true },
  { name: 'усталый игрок (85% скорости, -0.3 м)', back: 0.3, mag: 0.85, must: false },
];

let failed = 0;
const stats = variants.map(() => 0);
for (let i = 0; i < seq.length - 1; i++) {
  const a = seq[i].solid, b = seq[i + 1].solid;
  variants.forEach((v, vi) => {
    const ok = simulate(a, b, v.back, v.mag);
    if (ok) stats[vi]++;
    else if (v.must) {
      failed++;
      if (failed <= 15) console.log(`  ✗ шаг ${i}→${i + 1} (${seq[i].kind}→${seq[i + 1].kind}), высота ${b.top.toFixed(1)} м, вариант "${v.name}"`);
    }
  });
}

const n = seq.length - 1;
let maxGap = 0, sumDy = 0, maxDy = 0, minGap = 99, sumGap = 0;
const kinds = {};
for (let i = 0; i < n; i++) {
  const a = seq[i].solid, b = seq[i + 1].solid;
  const g = shapeDist(a, b), dy = b.top - a.top;
  maxGap = Math.max(maxGap, g); minGap = Math.min(minGap, g); sumGap += g;
  sumDy += dy; maxDy = Math.max(maxDy, dy);
  kinds[seq[i + 1].kind] = (kinds[seq[i + 1].kind] || 0) + 1;
}

// куда падает игрок, если сорвался с платформы (проверка «страховки» нижними витками)
const falls = [];
for (let i = 1; i < course.path.length; i += 3) {
  const a = course.path[i].solid;
  for (let k = 0; k < 6; k++) {
    const ang = (k / 6) * Math.PI * 2;
    const ux = Math.cos(ang), uz = Math.sin(ang);
    const e = edgeDist(a, ux, uz) + 0.45;
    const body = makeBody(a.x + ux * e, a.top, a.z + uz * e);
    let steps = 0;
    while (!body.grounded && steps++ < 4000) stepBody(body, { mx: 0, mz: 0, jump: false }, dt, world);
    if (body.grounded) falls.push(a.top - body.y);
  }
}
falls.sort((x, y) => x - y);
const pct = (p) => falls[Math.min(falls.length - 1, Math.floor(falls.length * p))] || 0;

console.log('— Проверка трассы —');
console.log(`Платформ в пути: ${course.path.length} (включая ${course.checkpoints.length} площадок-чекпоинтов)`);
console.log(`Прыжков: ${n}, средний подъём ${(sumDy / n).toFixed(2)} м, макс. ${maxDy.toFixed(2)} м (потолок прыжка ≈ ${(P.JUMP_V ** 2 / (2 * P.GRAVITY)).toFixed(2)} м)`);
console.log(`Зазор между платформами: мин ${minGap.toFixed(2)} м, средний ${(sumGap / n).toFixed(2)} м, макс ${maxGap.toFixed(2)} м`);
console.log('Чекпоинты:', course.checkpoints.map((c) => c.height + ' м').join(', '));
const okCp = course.checkpoints.every((c, i) => Math.abs(c.y - (CP_HEIGHTS[i] ?? FINISH_H)) < 1e-6);
console.log('Высоты чекпоинтов точные:', okCp ? 'да' : 'НЕТ');
console.log('Виды платформ:', JSON.stringify(kinds));
variants.forEach((v, vi) => console.log(`  ${v.must ? '[обязательно]' : '[справочно]  '} ${v.name}: ${stats[vi]}/${n}`));
console.log(`Падение при срыве (м): медиана ${pct(0.5).toFixed(1)}, 75% ${pct(0.75).toFixed(1)}, 90% ${pct(0.9).toFixed(1)}`);
const secs = [1.6, 2.0, 2.4].map((s) => ((n * s) / 60).toFixed(0));
console.log(`Оценка времени прохождения без падений: ${secs[0]}–${secs[2]} мин (при 1.6–2.4 с на платформу)`);

if (failed > 0 || !okCp) {
  console.log(`\nПРОВАЛ: ${failed} непроходимых прыжков`);
  process.exit(1);
}
console.log('\nOK: все прыжки проходимы.');
