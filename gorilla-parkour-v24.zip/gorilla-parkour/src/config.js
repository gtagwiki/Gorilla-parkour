// Хэш пароля админа (сам пароль здесь не хранится). Чтобы сменить пароль: см. README, раздел «Админ».
export const ADMIN_HASH = '17sug5yvqc1';

// Адрес общей базы Firebase Realtime Database (не секрет: он и так виден в любом приложении).
export const DB_URL = 'https://gorilla-parkour-default-rtdb.firebaseio.com';
