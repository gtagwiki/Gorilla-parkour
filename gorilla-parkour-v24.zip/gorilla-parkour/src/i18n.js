// Три сервера = три языка. Сервер выбирается в меню, язык интерфейса меняется вместе с ним.
export const ROOMS = [
  { id: 'en', lang: 'en', name: 'English', flag: '🇬🇧' },
  { id: 'ru', lang: 'ru', name: 'Русский', flag: '🇷🇺' },
  { id: 'kz', lang: 'kk', name: 'Қазақша', flag: '🇰🇿' },
];

const D = {
  ru: {
    tagline: 'Заберись на 1000 метров. Без падений — никак 🙂', server: 'Сервер', nickPh: 'Введи свой ник',
    play: 'ИГРАТЬ', cont: 'ПРОДОЛЖИТЬ', reset: 'Удалить прогресс', quit: 'Выход из игры',
    top10: '🏆 Топ-10 самых быстрых', empty: 'Пока никто не прошёл. Будь первым!',
    of1000: '/ 1000 м', respawnBtn: '⟲ Респавн', menuBtn: '☰ Меню', jump: 'ПРЫЖОК', down: 'ВНИЗ',
    help: 'WASD — ходьба · Пробел — прыжок · Мышь (зажать) — камера · Колесо — приближение · Esc — меню',
    pause: 'Пауза', resume: 'Продолжить', pRespawn: 'Респавн на чекпоинте', pReset: 'Удалить прогресс', pMenu: 'В главное меню',
    cTitle: 'Удалить прогресс?', cText: 'Чекпоинты и время будут сброшены, ты начнёшь с самого низа.', cYes: 'Да, удалить', cNo: 'Отмена',
    finTitle: '🎉 Вершина покорена!', finSaving: 'Сохраняю результат…', finRank: 'Ты на {n} месте в топ-10!',
    finNoRank: 'В топ-10 пока не попал — попробуй быстрее!', finCheat: 'Использован админ-режим — результат не записан в лидерборд.', fMenu: 'В главное меню',
    z0: 'Джунгли', z1: 'Руины', z2: 'Завод', z3: 'Небеса', z4: 'Ледник', z5: 'Золотая вершина',
    cpShort: 'чекпоинт {h} м', toastCp: '✔ Чекпоинт {h} м — прогресс сохранён', toastResume: 'Продолжаем с чекпоинта {h} м',
    toastSpike: '⚠ Шипы! Возврат на прошлую платформу', toastRespawn: 'Респавн', toastDeleted: 'Прогресс удалён',
    nickShort: 'Ник: минимум 2 символа', banned: 'Ты забанен. Осталось: {t}', closeTab: 'Можно закрыть вкладку',
    onl: 'онлайн', netErr: 'Нет связи с сервером — играешь офлайн', hudRoom: '{room} · {n} онлайн', hudOff: '{room} · нет связи', uD: 'д', uH: 'ч', uM: 'мин',
  },
  en: {
    tagline: 'Climb 1000 meters. No falling allowed 🙂', server: 'Server', nickPh: 'Enter your nickname',
    play: 'PLAY', cont: 'CONTINUE', reset: 'Delete progress', quit: 'Quit game',
    top10: '🏆 Top 10 fastest', empty: 'Nobody has finished yet. Be the first!',
    of1000: '/ 1000 m', respawnBtn: '⟲ Respawn', menuBtn: '☰ Menu', jump: 'JUMP', down: 'DOWN',
    help: 'WASD — move · Space — jump · Mouse (hold) — camera · Wheel — zoom · Esc — menu',
    pause: 'Paused', resume: 'Resume', pRespawn: 'Respawn at checkpoint', pReset: 'Delete progress', pMenu: 'Main menu',
    cTitle: 'Delete progress?', cText: 'Checkpoints and time will be reset. You will start from the very bottom.', cYes: 'Yes, delete', cNo: 'Cancel',
    finTitle: '🎉 You reached the top!', finSaving: 'Saving your result…', finRank: 'You are #{n} in the top 10!',
    finNoRank: 'Not in the top 10 yet — try to be faster!', finCheat: 'Admin mode was used — the result was not saved to the leaderboard.', fMenu: 'Main menu',
    z0: 'Jungle', z1: 'Ruins', z2: 'Factory', z3: 'Skies', z4: 'Glacier', z5: 'Golden Summit',
    cpShort: 'checkpoint {h} m', toastCp: '✔ Checkpoint {h} m — progress saved', toastResume: 'Continuing from checkpoint {h} m',
    toastSpike: '⚠ Spikes! Back to the previous platform', toastRespawn: 'Respawn', toastDeleted: 'Progress deleted',
    nickShort: 'Nickname: at least 2 characters', banned: 'You are banned. Time left: {t}', closeTab: 'You can close the tab',
    onl: 'online', netErr: 'No connection to the server — playing offline', hudRoom: '{room} · {n} online', hudOff: '{room} · no connection', uD: 'd', uH: 'h', uM: 'min',
  },
  kk: {
    tagline: '1000 метр биікке көтеріл! 🙂', server: 'Сервер', nickPh: 'Лақап атыңды жаз',
    play: 'ОЙНАУ', cont: 'ЖАЛҒАСТЫРУ', reset: 'Прогресті жою', quit: 'Ойыннан шығу',
    top10: '🏆 Ең жылдам 10 ойыншы', empty: 'Әзірге ешкім өткен жоқ. Бірінші бол!',
    of1000: '/ 1000 м', respawnBtn: '⟲ Респавн', menuBtn: '☰ Мәзір', jump: 'СЕКІРУ', down: 'ТӨМЕН',
    help: 'WASD — жүру · Бос орын — секіру · Тінтуір (басып тұр) — камера · Дөңгелек — жақындату · Esc — мәзір',
    pause: 'Үзіліс', resume: 'Жалғастыру', pRespawn: 'Чекпоинтте респавн', pReset: 'Прогресті жою', pMenu: 'Басты мәзірге',
    cTitle: 'Прогресс жойылсын ба?', cText: 'Чекпоинттер мен уақыт өшеді, ең төменнен бастайсың.', cYes: 'Иә, жою', cNo: 'Бас тарту',
    finTitle: '🎉 Шың бағындырылды!', finSaving: 'Нәтиже сақталуда…', finRank: 'Топ-10-да {n}-орындасың!',
    finNoRank: 'Топ-10-ға кірмедің — жылдамырақ көр!', finCheat: 'Әкімші режимі қолданылды — нәтиже рейтингке жазылмады.', fMenu: 'Басты мәзірге',
    z0: 'Джунгли', z1: 'Қирандылар', z2: 'Зауыт', z3: 'Аспан', z4: 'Мұзарт', z5: 'Алтын шың',
    cpShort: '{h} м чекпоинті', toastCp: '✔ {h} м чекпоинті — прогресс сақталды', toastResume: '{h} м чекпоинтінен жалғасамыз',
    toastSpike: '⚠ Тікенектер! Алдыңғы платформаға оралдың', toastRespawn: 'Респавн', toastDeleted: 'Прогресс жойылды',
    nickShort: 'Лақап ат: кемінде 2 таңба', banned: 'Сен бұғатталғансың. Қалды: {t}', closeTab: 'Қойындыны жабуға болады',
    onl: 'онлайн', netErr: 'Серверге қосылу мүмкін емес — офлайн ойнайсың', hudRoom: '{room} · {n} онлайн', hudOff: '{room} · байланыс жоқ', uD: 'к', uH: 'сағ', uM: 'мин',
  },
};

let lang = 'ru';
export const getLang = () => lang;
export function t(key, vars) {
  let s = (D[lang] && D[lang][key]) ?? D.ru[key] ?? key;
  if (vars) for (const k of Object.keys(vars)) s = s.split('{' + k + '}').join(String(vars[k]));
  return s;
}
export function applyI18n() {
  if (typeof document === 'undefined') return;
  document.querySelectorAll('[data-i18n]').forEach((e) => { e.textContent = t(e.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach((e) => { e.placeholder = t(e.dataset.i18nPh); });
}
export function setLang(l) {
  lang = D[l] ? l : 'ru';
  if (typeof document !== 'undefined') document.documentElement.lang = lang;
  applyI18n();
}
