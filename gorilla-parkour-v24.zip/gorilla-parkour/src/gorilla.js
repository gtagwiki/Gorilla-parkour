// Оригинальная модель гориллы из примитивов (не копия персонажа из Gorilla Tag).
import * as THREE from 'three';

export function createGorilla(tint) {
  const fur = new THREE.MeshLambertMaterial({ color: tint ?? 0x3b3b44, flatShading: true });
  const furLight = new THREE.MeshLambertMaterial({ color: tint != null ? new THREE.Color(tint).multiplyScalar(1.5) : 0x55555f, flatShading: true });
  const skin = new THREE.MeshLambertMaterial({ color: 0x8c6b58, flatShading: true });
  const white = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const black = new THREE.MeshBasicMaterial({ color: 0x111111 });

  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  const mesh = (geo, mat, x = 0, y = 0, z = 0, parent = body) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    parent.add(m);
    return m;
  };

  // туловище
  mesh(new THREE.BoxGeometry(1.05, 0.85, 0.62), fur, 0, 1.0, 0);
  mesh(new THREE.BoxGeometry(1.25, 0.42, 0.7), fur, 0, 1.32, 0.02);   // плечи
  mesh(new THREE.BoxGeometry(0.62, 0.55, 0.12), skin, 0, 1.05, 0.33);  // грудь
  mesh(new THREE.BoxGeometry(0.95, 0.4, 0.58), furLight, 0, 0.62, -0.02); // таз

  // голова
  const head = new THREE.Group();
  head.position.set(0, 1.62, 0.16);
  body.add(head);
  mesh(new THREE.SphereGeometry(0.34, 14, 10), fur, 0, 0, 0, head);
  mesh(new THREE.BoxGeometry(0.6, 0.14, 0.22), fur, 0, 0.1, 0.22, head);        // надбровная дуга
  mesh(new THREE.BoxGeometry(0.4, 0.3, 0.2), skin, 0, -0.08, 0.28, head);       // морда
  mesh(new THREE.SphereGeometry(0.05, 8, 6), black, -0.07, -0.02, 0.4, head);   // ноздри
  mesh(new THREE.SphereGeometry(0.05, 8, 6), black, 0.07, -0.02, 0.4, head);
  for (const sx of [-1, 1]) {
    mesh(new THREE.SphereGeometry(0.07, 8, 6), white, sx * 0.13, 0.04, 0.3, head);
    mesh(new THREE.SphereGeometry(0.035, 8, 6), black, sx * 0.13, 0.04, 0.36, head);
  }
  mesh(new THREE.BoxGeometry(0.22, 0.04, 0.05), black, 0, -0.16, 0.38, head);   // рот

  // руки (длинные, как у гориллы) — пивот в плече
  const arms = [];
  for (const sx of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(sx * 0.7, 1.42, 0);
    body.add(pivot);
    mesh(new THREE.CapsuleGeometry(0.17, 0.75, 4, 8), fur, 0, -0.52, 0, pivot);
    mesh(new THREE.SphereGeometry(0.22, 10, 8), furLight, 0, -1.08, 0.02, pivot);
    arms.push(pivot);
  }
  // ноги
  const legs = [];
  for (const sx of [-1, 1]) {
    const pivot = new THREE.Group();
    pivot.position.set(sx * 0.3, 0.6, 0);
    body.add(pivot);
    mesh(new THREE.CapsuleGeometry(0.19, 0.3, 4, 8), fur, 0, -0.28, 0, pivot);
    mesh(new THREE.BoxGeometry(0.3, 0.14, 0.42), furLight, 0, -0.55, 0.08, pivot);
    legs.push(pivot);
  }

  body.rotation.x = 0.08;
  let phase = 0;

  return {
    object: root,
    // speed 0..1, air — в воздухе
    animate(dt, speed, air) {
      phase += dt * (6 + speed * 8);
      const s = Math.sin(phase);
      if (air) {
        arms[0].rotation.x = arms[1].rotation.x = -2.5;
        arms[0].rotation.z = 0.35; arms[1].rotation.z = -0.35;
        legs[0].rotation.x = -0.5; legs[1].rotation.x = 0.4;
      } else {
        const a = speed * 0.9;
        arms[0].rotation.x = s * a; arms[1].rotation.x = -s * a;
        arms[0].rotation.z = 0.08; arms[1].rotation.z = -0.08;
        legs[0].rotation.x = -s * a; legs[1].rotation.x = s * a;
      }
      body.position.y = air ? 0 : Math.abs(Math.sin(phase)) * 0.06 * speed;
      head.rotation.y = 0;
    },
    // удары по груди для меню
    beat(t) {
      const k = Math.max(0, Math.sin(t * 9));
      arms[0].rotation.x = -1.2 - k * 0.6; arms[1].rotation.x = -1.2 - (1 - k) * 0.6;
      arms[0].rotation.z = -0.55; arms[1].rotation.z = 0.55;
      body.position.y = k * 0.05;
      head.rotation.y = Math.sin(t * 1.3) * 0.35;
      legs[0].rotation.x = legs[1].rotation.x = 0;
    },
  };
}
