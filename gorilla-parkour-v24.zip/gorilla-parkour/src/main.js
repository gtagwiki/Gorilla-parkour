import * as THREE from 'three';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { World, makeBody, stepBody, P, spikeExt, SPIKE_LETHAL } from './physics.js';
import { generateCourse, FINISH_H, CP_HEIGHTS, TOWER_R, zoneAt } from './course.js';
import { buildWorld, SKY } from './world.js';
import { createGorilla } from './gorilla.js';
import { cleanNick, loadNick, saveNick, loadSave, writeSave, clearSave, fetchBoard, submitScore, fmtTime, getPlayerId, isAdmin, tryAdminLogin, adminLogout, listBans, addBan, removeBan, banRemaining, normId, fmtDur } from './store.js';
import { ROOMS, t, setLang } from './i18n.js';
import { createNet, fetchCounts, fetchBoardNet, submitScoreNet, getBanNet, listBansNet, setBanNet } from './net.js';
import { createRemotes } from './remote.js';

const $ = (id) => document.getElementById(id);
const canvas = $('c');
const isTouch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
if (!isTouch) document.body.classList.add('desktop');

/* ---------------- рендер ---------------- */
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
const resize = () => {
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  menuCam.aspect = innerWidth / innerHeight; menuCam.updateProjectionMatrix();
};

const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0x8fd3ff, 60, 260);
scene.background = new THREE.Color(0x8fd3ff);
const camera = new THREE.PerspectiveCamera(65, 1, 0.1, 900);
scene.add(new THREE.HemisphereLight(0xffffff, 0x556655, 1.15));
const sun = new THREE.DirectionalLight(0xffffff, 1.4);
sun.position.set(30, 60, 20);
scene.add(sun, sun.target);

// сцена меню: большая горилла
const menuScene = new THREE.Scene();
menuScene.background = new THREE.Color(0x16323f);
menuScene.add(new THREE.HemisphereLight(0xffffff, 0x334455, 1.4));
const menuLight = new THREE.DirectionalLight(0xffe2a8, 1.6); menuLight.position.set(3, 4, 5); menuScene.add(menuLight);
const menuCam = new THREE.PerspectiveCamera(40, 1, 0.1, 50);
menuCam.position.set(0, 1.4, 5.2); menuCam.lookAt(0, 1.1, 0);
const menuGorilla = createGorilla();
menuGorilla.object.scale.setScalar(1.25);
menuScene.add(menuGorilla.object);
const menuFloor = new THREE.Mesh(new THREE.CircleGeometry(3, 40), new THREE.MeshLambertMaterial({ color: 0x244a3a }));
menuFloor.rotation.x = -Math.PI / 2; menuScene.add(menuFloor);

/* ---------------- мир и игрок ---------------- */
const course = generateCourse();
const physWorld = new World(course.solids);
const visuals = buildWorld(course, scene);

const player = createGorilla();
scene.add(player.object);
const body = makeBody();
let facing = 0;

/* ---------------- состояние ---------------- */
let state = 'loading'; // loading | menu | playing | paused | finished
let nick = loadNick();
let cp = -1;           // индекс последнего чекпоинта
let elapsed = 0;       // секунды игры
let maxH = 0;
let saveTimer = 0;
let toastTimer = 0;
const PID = getPlayerId();
let fly = false, flySpeed = 14, cheated = false, downHeld = false;
let simTime = 0, lastSafe = null, hitCool = 0, banTimer = 0;
let remoteBanUntil = 0, netOn = false, starting = false;
const banLeft = () => Math.max(banRemaining(PID), remoteBanUntil - Date.now(), 0);
const banBlocked = () => !isAdmin() && banLeft() > 0;
const banText = () => t('banned', { t: fmtDur(banLeft()) });
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
async function checkRemoteBan() {
  try { const ms = await withTimeout(getBanNet(PID), 4000); remoteBanUntil = ms > 0 ? Date.now() + ms : 0; } catch { /* нет связи — не блокируем */ }
}

/* ---------------- серверы (комнаты) и сеть ---------------- */
const net = createNet();
const remotes = createRemotes(scene);
const roomLS = { get: () => { try { return localStorage.getItem('gp_room'); } catch { return null; } }, set: (v) => { try { localStorage.setItem('gp_room', v); } catch { /* */ } } };
const guessRoom = () => { const l = (navigator.language || 'en').toLowerCase(); return l.startsWith('ru') ? 'ru' : l.startsWith('kk') ? 'kz' : 'en'; };
let room = ROOMS.some((x) => x.id === roomLS.get()) ? roomLS.get() : guessRoom();
const roomInfo = () => ROOMS.find((x) => x.id === room);
let counts = {};

const camSt = { yaw: 0, pitch: 0.45, dist: 6.5 };
const keys = {};
let jumpHeld = false;
const stick = { id: null, cx: 0, cy: 0, x: 0, y: 0 };
const look = { id: null, lx: 0, ly: 0 };

/* ---------------- UI ---------------- */
const show = (id, on) => $(id).classList.toggle('hidden', !on);
function toast(text, ms = 2200) {
  const t = $('toast'); t.textContent = text; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), ms);
}
function fillBoard(ol, rows, me) {
  ol.innerHTML = '';
  if (!rows.length) { const li = document.createElement('div'); li.className = 'empty'; li.textContent = t('empty'); ol.appendChild(li); return; }
  rows.forEach((r, i) => {
    const li = document.createElement('li');
    if (me && r.name === me) li.className = 'me';
    const n = document.createElement('span'); n.className = 'n'; n.textContent = i + 1;
    const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = r.name; // textContent — без XSS
    const t = document.createElement('span'); t.className = 't'; t.textContent = fmtTime(r.t);
    li.append(n, nm, t); ol.appendChild(li);
  });
}
let boardTok = 0;
async function loadBoard() { try { return await fetchBoardNet(room); } catch { return fetchBoard(); } }
async function refreshBoard() { const tok = ++boardTok; const rows = await loadBoard(); if (tok === boardTok) fillBoard($('lbMenu'), rows, nick); }
function renderRooms() {
  const box = $('rooms'); box.innerHTML = '';
  for (const r of ROOMS) {
    const b = document.createElement('button'); b.className = r.id === room ? 'on' : ''; b.dataset.id = r.id;
    b.append(r.flag + ' ' + r.name);
    const sm = document.createElement('small'); sm.textContent = counts[r.id] == null ? '—' : counts[r.id] + ' ' + t('onl'); b.appendChild(sm);
    b.addEventListener('click', () => setRoom(r.id));
    box.appendChild(b);
  }
}
function setRoom(id) {
  room = id; roomLS.set(id); setLang(roomInfo().lang);
  renderRooms(); refreshMenu(); refreshBoard(); refreshCounts();
}
async function refreshCounts() { counts = await fetchCounts(); if (state === 'menu') renderRooms(); }
function connectNet() {
  netOn = false;
  net.connect(room, PID, nick, (list) => remotes.set(list), (on) => { netOn = on; });
}
function leaveNet() { net.disconnect(); remotes.clear(); netOn = false; }

function refreshMenu() {
  const s = loadSave();
  $('btnPlay').textContent = s && s.cp >= -1 && (s.t > 0 || s.cp >= 0) ? t('cont') : t('play');
  show('btnReset', !!s);
  $('nick').value = nick;
  $('nickErr').textContent = banBlocked() ? banText() : '';
}
function enterMenu() {
  saveProgress(); leaveNet();
  state = 'menu'; setFly(false);
  ['hud', 'pause', 'confirm', 'finish'].forEach((i) => show(i, false));
  show('menu', true);
  renderRooms(); refreshMenu(); refreshBoard(); refreshCounts();
}

/* ---------------- прогресс ---------------- */
function saveProgress() {
  if (state !== 'playing' && state !== 'paused') return;
  writeSave({ nick, cp, t: elapsed, maxH, ch: cheated });
}
function spawnPoint(idx) {
  if (idx < 0) return { x: course.start.x, y: 0.05, z: course.start.z };
  const c = course.checkpoints[idx];
  return { x: c.x, y: c.y + 0.05, z: c.z };
}
function respawn() {
  const p = spawnPoint(cp);
  body.x = p.x; body.y = p.y; body.z = p.z; body.vx = body.vy = body.vz = 0; body.grounded = false; body.onSolid = null; lastSafe = null; hitCool = 1;
  // камера смотрит на башню (чтобы увидеть следующую платформу)
  camSt.yaw = Math.atan2(p.x, p.z) + 0.0; // камера «снаружи» от оси башни
  camSt.pitch = 0.45;
  facing = camSt.yaw + Math.PI;
}
async function startGame() {
  if (starting) return;
  if (banBlocked()) { $('nickErr').textContent = banText(); return; }
  const r = cleanNick($('nick').value);
  if (r.length < 2) { $('nickErr').textContent = t('nickShort'); $('nick').focus(); return; }
  $('nickErr').textContent = '';
  starting = true; await checkRemoteBan(); starting = false;
  if (state !== 'menu') return;
  if (banBlocked()) { $('nickErr').textContent = banText(); return; }
  const s = loadSave();
  if (s && s.nick && s.nick !== r) { // другой ник = новая игра
    clearSave(); cp = -1; elapsed = 0; maxH = 0; cheated = false;
  } else if (s) { cp = s.cp; elapsed = s.t; maxH = s.maxH; cheated = !!s.ch; }
  else { cp = -1; elapsed = 0; maxH = 0; cheated = false; }
  setFly(false); updateAdminUi();
  nick = r; saveNick(nick);
  respawn();
  show('menu', false); show('hud', true);
  state = 'playing';
  saveProgress(); connectNet();
  if (cp >= 0) toast(t('toastResume', { h: CP_HEIGHTS[cp] }));
}
function deleteProgress() {
  clearSave(); cp = -1; elapsed = 0; maxH = 0; cheated = false; setFly(false);
  show('confirm', false);
  if (state === 'paused') { respawn(); show('pause', false); state = 'playing'; toast(t('toastDeleted')); }
  else refreshMenu();
}
function pause() { if (state !== 'playing') return; state = 'paused'; saveProgress(); show('pause', true); resetInput(); }
function resume() { if (state !== 'paused') return; show('pause', false); state = 'playing'; }
function quitApp() {
  saveProgress();
  try { if (Capacitor.isNativePlatform()) { CapApp.exitApp(); return; } } catch { /* веб */ }
  window.close();
  $('btnQuit').textContent = t('closeTab');
}

async function finishGame() {
  state = 'finished'; leaveNet();
  const tm = elapsed;
  clearSave(); const myNick = nick; const wasCheated = cheated;
  cp = -1; elapsed = 0; maxH = 0; cheated = false; setFly(false);
  resetInput(); show('hud', false); show('finish', true);
  $('finTime').textContent = fmtTime(tm);
  if (wasCheated) {
    $('finRank').textContent = t('finCheat');
  } else {
    $('finRank').textContent = t('finSaving');
    let rows = null;
    try { await submitScoreNet(room, PID, myNick, tm); rows = await fetchBoardNet(room); }
    catch { await submitScore(myNick, tm); rows = await fetchBoard(); $('finRank').textContent = t('netErr'); }
    const i = rows.findIndex((e) => e.id === PID && e.t <= tm + 0.01);
    if (!$('finRank').textContent || $('finRank').textContent === t('finSaving')) $('finRank').textContent = i >= 0 ? t('finRank', { n: i + 1 }) : t('finNoRank');
    fillBoard($('lbFinish'), rows, myNick); return;
  }
  fillBoard($('lbFinish'), await loadBoard(), myNick);
}

/* ---------------- ввод ---------------- */
function resetInput() {
  for (const k in keys) keys[k] = false;
  jumpHeld = false; $('jump').classList.remove('down');
  stick.id = look.id = null; stick.x = stick.y = 0;
  $('stick').classList.remove('on'); $('knob').style.transform = '';
}
addEventListener('keydown', (e) => {
  if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT')) { if (e.key === 'Enter' && e.target.id === 'nick') $('btnPlay').click(); return; }
  if (e.code === 'Escape') { state === 'playing' ? pause() : state === 'paused' ? resume() : 0; return; }
  if (state !== 'playing') return;
  keys[e.code] = true;
  if (e.code === 'Space') { jumpHeld = true; e.preventDefault(); }
  if (e.code === 'KeyR') { respawn(); }
});
addEventListener('keyup', (e) => { keys[e.code] = false; if (e.code === 'Space') jumpHeld = false; });
addEventListener('blur', () => { resetInput(); if (!isTouch && state === 'playing') pause(); }); // на телефоне blur срабатывает от шторки/записи экрана — пауза там только через visibilitychange и событие приложения
document.addEventListener('visibilitychange', () => { if (document.hidden) { saveProgress(); if (state === 'playing') pause(); } });
addEventListener('pagehide', () => { saveProgress(); leaveNet(); });

canvas.addEventListener('contextmenu', (e) => e.preventDefault());
canvas.addEventListener('wheel', (e) => { camSt.dist = Math.min(14, Math.max(2.5, camSt.dist + Math.sign(e.deltaY) * 0.6)); }, { passive: true });

// камера и джойстик (как в Roblox: слева — ходьба, справа — вращение камеры)
canvas.addEventListener('pointerdown', (e) => {
  if (state !== 'playing') return;
  if (e.pointerType === 'mouse') { look.id = e.pointerId; look.lx = e.clientX; look.ly = e.clientY; canvas.setPointerCapture(e.pointerId); return; }
  if (e.clientX < innerWidth * 0.45 && stick.id === null) {
    stick.id = e.pointerId; stick.cx = e.clientX; stick.cy = e.clientY; stick.x = stick.y = 0;
    const el = $('stick'); el.style.left = e.clientX - 65 + 'px'; el.style.bottom = 'auto'; el.style.top = e.clientY - 65 + 'px'; el.classList.add('on');
  } else if (look.id === null) { look.id = e.pointerId; look.lx = e.clientX; look.ly = e.clientY; }
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointermove', (e) => {
  if (e.pointerId === look.id) {
    const k = e.pointerType === 'mouse' ? 0.005 : 0.0065;
    camSt.yaw -= (e.clientX - look.lx) * k;
    camSt.pitch = Math.min(1.35, Math.max(-0.25, camSt.pitch + (e.clientY - look.ly) * k));
    look.lx = e.clientX; look.ly = e.clientY;
  } else if (e.pointerId === stick.id) {
    let dx = e.clientX - stick.cx, dy = e.clientY - stick.cy;
    const L = Math.hypot(dx, dy), M = 55;
    if (L > M) { dx = dx / L * M; dy = dy / L * M; }
    stick.x = dx / M; stick.y = -dy / M;
    $('knob').style.transform = `translate(${dx}px,${dy}px)`;
  }
});
const endPtr = (e) => {
  if (e.pointerId === look.id) look.id = null;
  if (e.pointerId === stick.id) { stick.id = null; stick.x = stick.y = 0; $('stick').classList.remove('on'); $('knob').style.transform = ''; }
};
canvas.addEventListener('pointerup', endPtr);
canvas.addEventListener('pointercancel', endPtr);

const jb = $('jump');
jb.addEventListener('pointerdown', (e) => { e.preventDefault(); jumpHeld = true; jb.classList.add('down'); jb.setPointerCapture(e.pointerId); });
const jbUp = () => { jumpHeld = false; jb.classList.remove('down'); };
jb.addEventListener('pointerup', jbUp); jb.addEventListener('pointercancel', jbUp);

$('btnPlay').addEventListener('click', startGame);
$('btnQuit').addEventListener('click', quitApp);
$('btnReset').addEventListener('click', () => show('confirm', true));
$('btnRespawn').addEventListener('click', () => { if (state === 'playing') { respawn(); toast(t('toastRespawn')); } });
$('btnPause').addEventListener('click', pause);
$('pResume').addEventListener('click', resume);
$('pRespawn').addEventListener('click', () => { show('pause', false); state = 'playing'; respawn(); });
$('pReset').addEventListener('click', () => show('confirm', true));
$('pMenu').addEventListener('click', enterMenu);
$('cYes').addEventListener('click', deleteProgress);
$('cNo').addEventListener('click', () => show('confirm', false));
$('fMenu').addEventListener('click', enterMenu);
$('nick').addEventListener('input', () => { $('nickErr').textContent = ''; });
try {
  CapApp.addListener('backButton', () => {
    if (!$('confirm').classList.contains('hidden')) show('confirm', false);
    else if (state === 'playing') pause();
    else if (state === 'paused') resume();
    else if (state === 'menu') quitApp();
  });
  CapApp.addListener('pause', () => { saveProgress(); if (state === 'playing') pause(); });
} catch { /* веб-режим */ }

/* ---------------- игровой цикл ---------------- */
const skyTmp = new THREE.Color();
function updateSky(h) {
  let a = SKY[0], b = SKY[SKY.length - 1];
  for (let i = 0; i < SKY.length - 1; i++) if (h >= SKY[i][0] && h <= SKY[i + 1][0]) { a = SKY[i]; b = SKY[i + 1]; break; }
  const t = a === b ? 0 : (h - a[0]) / (b[0] - a[0]);
  skyTmp.copy(a[1]).lerp(b[1], Math.min(1, Math.max(0, t)));
  scene.background.copy(skyTmp); scene.fog.color.copy(skyTmp);
  visuals.stars.material.opacity = Math.min(1, Math.max(0, (h - 650) / 250));
}

function moveInput() {
  let ix = (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0);
  let iy = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0);
  ix += stick.x; iy += stick.y;
  const l = Math.hypot(ix, iy);
  if (l > 1) { ix /= l; iy /= l; }
  if (l < 0.12) return { mx: 0, mz: 0, ix: 0, iy: 0 };
  const s = Math.sin(camSt.yaw), c = Math.cos(camSt.yaw);
  // вперёд = от камеры к игроку (-s, -c); вправо = (c, -s)
  return { mx: -s * iy + c * ix, mz: -c * iy - s * ix, ix, iy };
}

function updateCheckpoints() {
  for (const c of course.checkpoints) {
    if (c.index <= cp) continue;
    if (Math.abs(body.y - c.y) < 0.6 && Math.hypot(body.x - c.x, body.z - c.z) < c.r) {
      if (c.finish) { finishGame(); return; }
      cp = c.index; saveProgress();
      toast(t('toastCp', { h: c.height }));
    }
  }
}

const SAFE_KINDS = new Set(['crate', 'barrel', 'beam', 'pole', 'rest', 'plaza', 'summit', 'ledge', 'ground', 'start']);
function spikeHit() {
  const p = lastSafe || spawnPoint(cp);
  body.x = p.x; body.y = p.y; body.z = p.z; body.vx = body.vy = body.vz = 0; body.grounded = false; body.onSolid = null;
  hitCool = 1; toast(t('toastSpike'));
}
function trackSafeAndHazards(dt) {
  hitCool = Math.max(0, hitCool - dt);
  const os = body.onSolid;
  if (body.grounded && os && SAFE_KINDS.has(os.kind)) {
    const own = os.kind === 'ledge' || os.kind === 'ground';
    lastSafe = { x: own ? body.x : os.x, y: os.top + 0.05, z: own ? body.z : os.z };
  }
  if (hitCool > 0) return;
  for (const h of course.hazards) {
    if (body.y < h.top - 0.3 || body.y > h.top + 0.7) continue;
    if (spikeExt(simTime, h.phase) < SPIKE_LETHAL) continue;
    const dx = body.x - h.x, dz = body.z - h.z;
    const lx = dx * h.c + dz * h.s, lz = -dx * h.s + dz * h.c;
    if (Math.abs(lx) <= h.hx + 0.2 && Math.abs(lz) <= h.hz) { spikeHit(); return; }
  }
}

function tickPhysics(dt) {
  simTime += dt; physWorld.update(simTime);
  const mv = moveInput();
  if (fly) {
    // полёт: двигаемся туда, куда смотрит камера; пробел/ВВЕРХ — вверх, Shift/C/ВНИЗ — вниз; без столкновений
    const sy = Math.sin(camSt.yaw), cy = Math.cos(camSt.yaw), sp2 = Math.sin(camSt.pitch), cp2 = Math.cos(camSt.pitch);
    const ix = mv.ix || 0, iy = mv.iy || 0;
    const up = (jumpHeld || keys.Space ? 1 : 0) - (downHeld || keys.ShiftLeft || keys.KeyC ? 1 : 0);
    const vx = -sy * cp2 * iy + cy * ix, vz = -cy * cp2 * iy - sy * ix, vy = -sp2 * iy + up;
    body.x += vx * flySpeed * dt; body.y += vy * flySpeed * dt; body.z += vz * flySpeed * dt;
    if (body.y < 0) body.y = 0;
    const r = Math.hypot(body.x, body.z); if (r > 40) { body.x *= 40 / r; body.z *= 40 / r; }
    body.vx = vx * flySpeed; body.vz = vz * flySpeed; body.vy = 0; body.grounded = false;
    const sp = Math.hypot(body.vx, body.vz);
    if (sp > 0.6) { const target = Math.atan2(body.vx, body.vz); let d = target - facing; d = Math.atan2(Math.sin(d), Math.cos(d)); facing += d * Math.min(1, dt * 14); }
    if (body.y > maxH) maxH = body.y;
    updateCheckpoints();
    return;
  }
  stepBody(body, { mx: mv.mx, mz: mv.mz, jump: jumpHeld || keys.Space }, dt, physWorld);
  if (body.y < -30) respawn();
  trackSafeAndHazards(dt);
  const sp = Math.hypot(body.vx, body.vz);
  if (sp > 0.6) { const target = Math.atan2(body.vx, body.vz); let d = target - facing; d = Math.atan2(Math.sin(d), Math.cos(d)); facing += d * Math.min(1, dt * 14); }
  if (body.y > maxH) maxH = body.y;
  updateCheckpoints();
}

let last = performance.now(), acc = 0, menuT = 0, pollT = 0, cntT = 0;
const STEP = 1 / 120;
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.1, (now - last) / 1000); last = now;

  if (state === 'menu' || state === 'loading') {
    menuT += dt; menuGorilla.beat(menuT);
    menuGorilla.object.rotation.y = Math.sin(menuT * 0.6) * 0.4;
    cntT += dt; if (cntT > 10 && state === 'menu') { cntT = 0; refreshCounts(); }
    renderer.render(menuScene, menuCam);
    return;
  }

  if (state === 'playing') {
    banTimer += dt; if (banTimer > 1) { banTimer = 0; if (banBlocked()) { enterMenu(); return; } }
    pollT += dt; if (pollT > 15) { pollT = 0; checkRemoteBan(); }
    elapsed += dt;
    saveTimer += dt; if (saveTimer > 4) { saveTimer = 0; saveProgress(); }
    acc += dt;
    while (acc >= STEP && state === 'playing') { tickPhysics(STEP); acc -= STEP; }
  }

  // визуал
  const sp = Math.min(1, Math.hypot(body.vx, body.vz) / P.SPEED);
  player.object.position.set(body.x, body.y, body.z);
  player.object.rotation.y = facing;
  player.animate(dt, sp, !body.grounded);
  net.setState({ x: body.x, y: body.y, z: body.z, f: facing, s: sp, a: !body.grounded });
  remotes.update(dt, camera.position);

  // камера от третьего лица
  const cx = Math.sin(camSt.yaw) * Math.cos(camSt.pitch), cy = Math.sin(camSt.pitch), cz = Math.cos(camSt.yaw) * Math.cos(camSt.pitch);
  const tx = body.x, ty = body.y + 1.3, tz = body.z;
  let d = camSt.dist;
  while (d > 1.2) { // не пускаем камеру внутрь центральной колонны
    const px = tx + cx * d, pz = tz + cz * d;
    if (Math.hypot(px, pz) > TOWER_R + 0.7) break;
    d -= 0.4;
  }
  camera.position.set(tx + cx * d, ty + cy * d, tz + cz * d);
  camera.lookAt(tx, ty, tz);
  sun.position.set(body.x + 30, body.y + 60, body.z + 20); sun.target.position.set(body.x, body.y, body.z);

  visuals.dyn.update(simTime, camera.position.y);
  const h = Math.max(0, body.y);
  updateSky(h);
  const clk = performance.now() / 1000;
  for (const f of visuals.flags) { f.flag.rotation.y = Math.sin(clk * 3 + f.index) * 0.25; f.ring.material.color.set(f.index <= cp ? 0x7dffb3 : 0xffffff); }

  // HUD
  if (state === 'playing') {
    $('meters').firstChild.nodeValue = Math.floor(h) + ' ';
    $('bar').firstChild.style.width = Math.min(100, h / FINISH_H * 100) + '%';
    $('timer').textContent = fmtTime(elapsed, false) + '.' + Math.floor((elapsed % 1) * 10);
    $('zone').textContent = t('z' + zoneAt(h)) + (cp >= 0 ? ' · ' + t('cpShort', { h: CP_HEIGHTS[cp] }) : '');
    $('online').textContent = netOn ? t('hudRoom', { room: roomInfo().name, n: remotes.count() + 1 }) : t('hudOff', { room: roomInfo().name });
    $('online').classList.toggle('off', !netOn);
  }
  renderer.render(scene, camera);
}

/* ---------------- ID и админ ---------------- */
function setFly(on) {
  fly = on;
  if (on) cheated = true;
  body.vy = 0; downHeld = false;
  $('flyOn').textContent = '✈ Fly: ' + (on ? 'ВКЛ' : 'выкл');
  $('flyOn').classList.toggle('sec', !on);
  $('down').classList.toggle('vis', on);
  if (on) toast('Полёт включён: результат не попадёт в лидерборд');
}
function updateAdminUi() {
  const adm = isAdmin();
  show('admBtn', adm);
  if (!adm) { show('admPanel', false); if (fly) setFly(false); }
  $('admId').textContent = 'Твой ID: ' + PID;
}
function teleport(idx) {
  const p = idx < 0 ? { x: course.start.x, y: 0.05, z: course.start.z } : spawnPoint(idx);
  body.x = p.x; body.y = p.y; body.z = p.z; body.vx = body.vy = body.vz = 0;
  camSt.yaw = Math.atan2(p.x, p.z); camSt.pitch = 0.45;
  cheated = true; toast('Телепорт на ' + (idx < 0 ? 'старт' : CP_HEIGHTS[idx] + ' м'));
}
$('pid').textContent = 'ID: ' + PID;
updateAdminUi();
$('pauseId').textContent = 'ID: ' + PID;
let pidTaps = 0, pidTimer = 0;
$('pid').addEventListener('click', () => {
  if (isAdmin()) { toast('Ты уже админ'); return; }
  pidTaps++; clearTimeout(pidTimer); pidTimer = setTimeout(() => { pidTaps = 0; }, 1500);
  if (pidTaps >= 5) { pidTaps = 0; $('admPw').value = ''; $('admErr').textContent = ''; show('adminLogin', true); $('admPw').focus(); }
});
const doLogin = () => {
  if (tryAdminLogin($('admPw').value)) { show('adminLogin', false); updateAdminUi(); $('pid').textContent = 'ID: ' + PID + ' · админ ✔'; }
  else $('admErr').textContent = 'Неверный пароль';
};
$('admOk').addEventListener('click', doLogin);
$('admPw').addEventListener('keydown', (e) => { if (e.key === 'Enter') doLogin(); e.stopPropagation(); });
$('admCancel').addEventListener('click', () => show('adminLogin', false));
$('admBtn').addEventListener('click', () => { $('admPanel').classList.toggle('hidden'); renderBans(); });
async function renderBans() {
  const box = $('banList');
  let list;
  try { list = await listBansNet(); } catch { list = listBans(); }
  box.innerHTML = '';
  if (!list.length) { box.textContent = 'Активных банов нет'; return; }
  for (const b of list) {
    const row = document.createElement('div'); row.className = 'banRow';
    const t = document.createElement('span'); t.textContent = b.id + ' · ' + fmtDur(b.until - Date.now());
    const x = document.createElement('button'); x.className = 'sec'; x.textContent = 'Снять';
    x.addEventListener('click', async () => { removeBan(b.id); try { await setBanNet(b.id, 0); } catch { $('banMsg').textContent = 'Нет связи: бан снят только локально'; } renderBans(); });
    row.append(t, x); box.appendChild(row);
  }
}
$('banId').addEventListener('input', (e) => { e.target.value = e.target.value.toUpperCase(); });
$('banDo').addEventListener('click', async () => {
  if (!isAdmin()) return;
  const id = normId($('banId').value), num = parseFloat($('banNum').value), unit = +$('banUnit').value;
  if (!id) { $('banMsg').textContent = 'Неверный ID. Формат: GP-XXXXXX'; return; }
  if (!(num > 0)) { $('banMsg').textContent = 'Введи время бана'; return; }
  const ms = Math.min(num * unit, 3650 * 86400000);
  addBan(id, ms);
  let shared = true;
  try { await setBanNet(id, ms); } catch { shared = false; }
  $('banMsg').textContent = (shared ? '' : '⚠ Нет связи с базой, бан только на этом устройстве. ') + 'Забанен ' + id + ' на ' + fmtDur(ms) + (id === PID ? ' (на тебя как админа бан не действует)' : '');
  $('banId').value = ''; $('banNum').value = ''; renderBans();
});
$('flyOn').addEventListener('click', () => { if (isAdmin()) setFly(!fly); });
$('flySpd').addEventListener('input', (e) => { flySpeed = +e.target.value; $('flySpdVal').textContent = flySpeed; });
$('admOut').addEventListener('click', () => { adminLogout(); setFly(false); updateAdminUi(); $('pid').textContent = 'ID: ' + PID; });
[['Старт', -1], ...CP_HEIGHTS.map((h, i) => [h + ' м', i])].forEach(([label, idx]) => {
  const b = document.createElement('button'); b.className = 'sec'; b.textContent = label;
  b.addEventListener('click', () => { if (isAdmin() && state === 'playing') teleport(idx); });
  $('tpRow').appendChild(b);
});
const dn = $('down');
dn.addEventListener('pointerdown', (e) => { e.preventDefault(); downHeld = true; dn.classList.add('down'); dn.setPointerCapture(e.pointerId); });
const dnUp = () => { downHeld = false; dn.classList.remove('down'); };
dn.addEventListener('pointerup', dnUp); dn.addEventListener('pointercancel', dnUp);
if (isAdmin()) $('pid').textContent = 'ID: ' + PID + ' · админ ✔';

/* ---------------- старт ---------------- */
addEventListener('resize', resize);
resize();
$('nick').value = nick;
setLang(roomInfo().lang); renderRooms();
requestAnimationFrame((t) => { last = t; frame(t); });
setTimeout(() => { show('loading', false); enterMenu(); }, 400);
