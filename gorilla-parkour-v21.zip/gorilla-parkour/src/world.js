// Построение 3D-сцены по данным трассы (всё склеивается в один меш — быстро на телефоне).
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { CP_HEIGHTS, FINISH_H, TOWER_R, GROUND_R } from './course.js';
import { spikeExt } from './physics.js';

// палитры зон: джунгли, руины, завод, небеса, ледник, золото
const PAL = [
  { crate: 0x8a5a2b, barrel: 0x5b8c3a, beam: 0x6b4423, pole: 0x7a5a3a, rest: 0x4f7a34 },
  { crate: 0x9a9384, barrel: 0x7d8a6a, beam: 0x6f6a5d, pole: 0x8a8576, rest: 0x8c8a7a },
  { crate: 0xb5651d, barrel: 0xc0392b, beam: 0x5d6d7e, pole: 0xd4ac0d, rest: 0x707b84 },
  { crate: 0xf1f5ff, barrel: 0xbfd9ff, beam: 0xd7c6ff, pole: 0xffe0f0, rest: 0xe6eeff },
  { crate: 0x9fd8ee, barrel: 0x6fbcdc, beam: 0xc9ecf7, pole: 0x86b9d6, rest: 0xd8f3fb },
  { crate: 0xe3b23c, barrel: 0xf2c94c, beam: 0xc9962b, pole: 0xfff0a8, rest: 0xffd700 },
];
const PLAZA = 0x2ec4b6, SUMMIT = 0xffd700, LEDGE = 0x555d6b, PILLAR = 0x4b5058;

export const SKY = [ // [высота, цвет неба]
  [0, 0x8fd3ff], [150, 0x7fc4f0], [350, 0xd9a066], [555, 0x6f86c9], [750, 0x2d3b78], [900, 0x1a1a3d], [1000, 0x0b0b22],
].map(([h, c]) => [h, new THREE.Color(c)]);

function colorize(geo, hex, shade = 1) {
  const c = new THREE.Color(hex).multiplyScalar(shade);
  const n = geo.attributes.position.count;
  const arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { arr[i * 3] = c.r; arr[i * 3 + 1] = c.g; arr[i * 3 + 2] = c.b; }
  geo.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return geo;
}
function std(geo) { // единый набор атрибутов для merge
  const g = geo.index ? geo.toNonIndexed() : geo;
  g.deleteAttribute('uv');
  return g;
}

function ringGeo(rIn, rOut, h) {
  const shape = new THREE.Shape();
  shape.absarc(0, 0, rOut, 0, Math.PI * 2, false);
  const hole = new THREE.Path();
  hole.absarc(0, 0, rIn, 0, Math.PI * 2, true);
  shape.holes.push(hole);
  const g = new THREE.ExtrudeGeometry(shape, { depth: h, bevelEnabled: false, curveSegments: 40 });
  g.rotateX(-Math.PI / 2);
  return g;
}

function labelSprite(text, color = '#ffffff', size = 256) {
  const cv = document.createElement('canvas');
  cv.width = size; cv.height = size / 2;
  const x = cv.getContext('2d');
  x.fillStyle = 'rgba(0,0,0,.55)';
  x.beginPath(); x.roundRect(4, 4, cv.width - 8, cv.height - 8, 22); x.fill();
  x.fillStyle = color; x.font = 'bold 64px system-ui, sans-serif';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText(text, cv.width / 2, cv.height / 2 + 4);
  const tex = new THREE.CanvasTexture(cv);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
  sp.scale.set(4.2, 2.1, 1);
  return sp;
}

export function buildWorld(course, scene) {
  const parts = [];

  // земля + колонна
  parts.push(colorize(std(new THREE.CylinderGeometry(GROUND_R, GROUND_R, 2, 48).translate(0, -1, 0)), 0x4c8b3a));
  parts.push(colorize(std(new THREE.CylinderGeometry(TOWER_R, TOWER_R + 0.2, FINISH_H + 40, 24).translate(0, (FINISH_H + 40) / 2, 0)), PILLAR));

  // стартовая площадка
  const sp = course.startPad;
  parts.push(colorize(std(new THREE.CylinderGeometry(sp.r, sp.r, 0.4, 28).translate(sp.x, -0.2, sp.z)), 0xe9c46a));

  const dummy = new THREE.Object3D();
  const placeBox = (g, x, y, z, yaw) => { dummy.position.set(x, y, z); dummy.rotation.set(0, -yaw, 0); dummy.updateMatrix(); g.applyMatrix4(dummy.matrix); return g; };
  for (const el of course.path) {
    if (el.kind === 'mover') continue; // едущие платформы рисуются отдельно (instanced)
    const s = el.main, th = s.top - s.bottom;
    const pal = PAL[el.zone];
    let hex = pal[el.kind] ?? pal.crate;
    if (el.kind === 'plaza') hex = PLAZA;
    if (el.kind === 'summit') hex = SUMMIT;
    if (el.kind === 'spinner') hex = 0xd9822b;
    if (el.kind === 'spike') hex = 0x4a4f57;
    let g;
    if (s.type === 'cyl') {
      g = new THREE.CylinderGeometry(s.r, s.r * (el.kind === 'barrel' ? 0.92 : 1), th, 20);
      g.translate(s.x, s.top - th / 2, s.z);
    } else {
      g = placeBox(new THREE.BoxGeometry(s.hx * 2, th, s.hz * 2), s.x, s.top - th / 2, s.z, s.yaw);
    }
    const shade = 0.9 + ((Math.sin(s.x * 12.9898 + s.z * 78.233 + s.top) * 43758.5453) % 1 + 1) % 1 * 0.2;
    parts.push(colorize(std(g), hex, shade));
    if (el.kind === 'spike') {
      // красная полоса — зона шипов, зелёные края — безопасные
      const hz = s.hz * 0.96;
      parts.push(colorize(std(placeBox(new THREE.BoxGeometry(el.hazard.hx * 2, 0.05, hz * 2), s.x, s.top + 0.01, s.z, s.yaw)), 0x8a1c1c));
      for (const e of [el.entry, el.exit]) parts.push(colorize(std(placeBox(new THREE.BoxGeometry(e.hx * 2 * 0.96, 0.05, hz * 2), e.x, s.top + 0.01, e.z, s.yaw)), 0x3fbf6a));
    } else if (el.kind !== 'plaza' && el.kind !== 'summit') {
      // светлая «крышка», чтобы верх читался на фоне
      let t;
      if (s.type === 'cyl') t = new THREE.CylinderGeometry(s.r * 0.98, s.r * 0.98, 0.06, 20).translate(s.x, s.top - 0.02, s.z);
      else t = placeBox(new THREE.BoxGeometry(s.hx * 2 * 0.96, 0.06, s.hz * 2 * 0.96), s.x, s.top - 0.02, s.z, s.yaw);
      parts.push(colorize(std(t), hex, 1.35));
    }
  }

  for (const l of course.ledges) {
    const g = ringGeo(l.rIn, l.rOut, l.top - l.bottom);
    g.translate(0, l.bottom, 0);
    parts.push(colorize(std(g), LEDGE));
  }

  const merged = mergeGeometries(parts, false);
  const mesh = new THREE.Mesh(merged, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }));
  scene.add(mesh);

  // метки высоты на колонне и чекпоинты
  for (let h = 50; h <= FINISH_H; h += 50) {
    if (CP_HEIGHTS.includes(h) || h === FINISH_H) continue;
    const s = labelSprite(h + ' м');
    s.position.set(0, h + 2.2, 0); s.userData.mark = true;
    s.position.x = TOWER_R + 1.0; // метка рядом с колонной (видна со спирали)
    scene.add(s);
  }
  const flags = [];
  course.checkpoints.forEach((c) => {
    const grp = new THREE.Group();
    grp.position.set(c.x, c.y, c.z);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3.2, 8), new THREE.MeshLambertMaterial({ color: 0xdddddd }));
    pole.position.y = 1.6;
    const flag = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.8, 0.05), new THREE.MeshBasicMaterial({ color: c.finish ? 0xffd700 : 0xff3d71 }));
    flag.position.set(0.7, 2.8, 0);
    const ring = new THREE.Mesh(new THREE.RingGeometry(c.r - 0.5, c.r - 0.2, 36), new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide, transparent: true, opacity: 0.8 }));
    ring.rotation.x = -Math.PI / 2; ring.position.y = 0.04;
    const lab = labelSprite(c.finish ? 'ФИНИШ 1000 м' : 'ЧЕКПОИНТ ' + c.height + ' м', c.finish ? '#ffd700' : '#7dffb3', 512);
    lab.scale.set(7, 1.75, 1); lab.position.set(0, 5.2, 0);
    grp.add(pole, flag, ring, lab);
    scene.add(grp);
    flags.push({ flag, ring, index: c.index });
  });

  // звёзды (видны на высоте)
  const starPos = [];
  for (let i = 0; i < 700; i++) {
    const a = Math.random() * Math.PI * 2, b = Math.acos(2 * Math.random() - 1);
    starPos.push(400 * Math.sin(b) * Math.cos(a), 400 * Math.cos(b), 400 * Math.sin(b) * Math.sin(a));
  }
  const sg = new THREE.BufferGeometry();
  sg.setAttribute('position', new THREE.Float32BufferAttribute(starPos, 3));
  const stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffffff, size: 1.6, sizeAttenuation: false, transparent: true, opacity: 0, fog: false }));
  scene.add(stars);

  // ---- движущиеся части: перекладины, едущие платформы, шипы (instanced, обновляются каждый кадр) ----
  const lam = (c) => new THREE.MeshLambertMaterial({ color: c, flatShading: true });
  const unit = new THREE.BoxGeometry(1, 1, 1);
  const bars = course.spinBars, movers = course.movers, hz = course.hazards;
  const barMesh = new THREE.InstancedMesh(unit, lam(0xff8a3d), Math.max(1, bars.length));
  const moverMesh = new THREE.InstancedMesh(unit, lam(0x3aa8ff), Math.max(1, movers.length));
  const COLS = [-0.675, -0.225, 0.225, 0.675], ROWS = [-1.1, -0.55, 0, 0.55, 1.1], NC = COLS.length * ROWS.length;
  const coneGeo = new THREE.ConeGeometry(0.17, 0.8, 6); coneGeo.translate(0, 0.4, 0);
  const coneMesh = new THREE.InstancedMesh(coneGeo, new THREE.MeshLambertMaterial({ color: 0xe6e6ee, emissive: 0x401010, flatShading: true }), Math.max(1, hz.length * NC));
  for (const m of [barMesh, moverMesh, coneMesh]) { m.frustumCulled = false; scene.add(m); }

  const setBox = (mesh, i, b) => {
    const th = b.top - b.bottom;
    dummy.position.set(b.x, b.top - th / 2, b.z); dummy.rotation.set(0, -b.yaw, 0); dummy.scale.set(b.hx * 2, th, b.hz * 2);
    dummy.updateMatrix(); mesh.setMatrixAt(i, dummy.matrix);
  };
  const setCones = (i, e) => {
    const h = hz[i];
    for (let c = 0; c < COLS.length; c++) for (let r = 0; r < ROWS.length; r++) {
      const lx = COLS[c], lz = ROWS[r];
      dummy.position.set(h.x + lx * h.c - lz * h.s, h.top, h.z + lx * h.s + lz * h.c);
      dummy.rotation.set(0, 0, 0); dummy.scale.set(1, Math.max(0.001, e), 1);
      dummy.updateMatrix(); coneMesh.setMatrixAt(i * NC + c * ROWS.length + r, dummy.matrix);
    }
  };
  for (let i = 0; i < hz.length; i++) setCones(i, 0);
  dummy.scale.set(1, 1, 1);
  const dyn = {
    update(t, camY) {
      for (let i = 0; i < bars.length; i++) setBox(barMesh, i, bars[i]);
      for (let i = 0; i < movers.length; i++) setBox(moverMesh, i, movers[i]);
      barMesh.instanceMatrix.needsUpdate = true; moverMesh.instanceMatrix.needsUpdate = true;
      for (let i = 0; i < hz.length; i++) if (Math.abs(hz[i].top - camY) < 150) setCones(i, spikeExt(t, hz[i].phase));
      coneMesh.instanceMatrix.needsUpdate = true;
      dummy.scale.set(1, 1, 1);
    },
  };
  dyn.update(0, 0);

  return { mesh, flags, stars, dyn };
}
