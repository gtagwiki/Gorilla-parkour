// Сохранения и лидерборд. Всё локально (localStorage); если задан VITE_LEADERBOARD_URL — ещё и общий онлайн-лидерборд.
const KEY_SAVE = 'gp_save_v1';
const KEY_NICK = 'gp_nick_v1';
const KEY_LB = 'gp_lb_v1';
import { ADMIN_HASH } from './config.js';
const API = (import.meta.env && import.meta.env.VITE_LEADERBOARD_URL) || '';

const get = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const set = (k, v) => { try { localStorage.setItem(k, v); } catch { /* приватный режим */ } };
const del = (k) => { try { localStorage.removeItem(k); } catch { /* */ } };

// ----- ID игрока: уникальный, создаётся один раз на устройстве -----
const KEY_ID = 'gp_id_v1';
const KEY_ADMIN = 'gp_admin_v1';
export function getPlayerId() {
  let id = get(KEY_ID);
  if (!/^GP-[A-Z0-9]{6}$/.test(id || '')) {
    const abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const rnd = new Uint32Array(6);
    (globalThis.crypto || { getRandomValues: (a) => a.map(() => Math.random() * 4294967296) }).getRandomValues(rnd);
    id = 'GP-' + Array.from(rnd, (n) => abc[n % abc.length]).join('');
    set(KEY_ID, id);
  }
  return id;
}

// ----- админ: вход по паролю, хранится только хэш -----
export function hashPw(str) { // cyrb53 с солью
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  const t = 'gp-salt-7f3a:' + str;
  for (let i = 0; i < t.length; i++) {
    const ch = t.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}
export const isAdmin = () => get(KEY_ADMIN) === ADMIN_HASH;
export function tryAdminLogin(pw) {
  if (hashPw(String(pw).trim()) !== ADMIN_HASH) return false;
  set(KEY_ADMIN, ADMIN_HASH); return true;
}
export const adminLogout = () => del(KEY_ADMIN);

// ----- баны по ID (пока локально: действуют на этом устройстве; общий бан появится вместе с онлайн-базой) -----
const KEY_BANS = 'gp_bans_v1';
export function normId(s) {
  const m = String(s || '').trim().toUpperCase().match(/^(?:GP-?)?([A-Z0-9]{6})$/);
  return m ? 'GP-' + m[1] : '';
}
function readBans() {
  try {
    const o = JSON.parse(get(KEY_BANS) || '{}'), now = Date.now(), out = {};
    for (const [k, v] of Object.entries(o)) if (typeof v === 'number' && v > now && /^GP-[A-Z0-9]{6}$/.test(k)) out[k] = v;
    return out;
  } catch { return {}; }
}
export const listBans = () => Object.entries(readBans()).map(([id, until]) => ({ id, until })).sort((a, b) => a.until - b.until);
export function addBan(id, ms) {
  const nid = normId(id); if (!nid || !(ms > 0)) return false;
  const b = readBans(); b[nid] = Date.now() + ms; set(KEY_BANS, JSON.stringify(b)); return true;
}
export function removeBan(id) { const b = readBans(); delete b[id]; set(KEY_BANS, JSON.stringify(b)); }
export const banRemaining = (id) => Math.max(0, (readBans()[id] || 0) - Date.now());
export function fmtDur(ms) {
  const s = Math.max(1, Math.ceil(ms / 1000));
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
  if (d) return d + ' д ' + h + ' ч';
  if (h) return h + ' ч ' + m + ' мин';
  return Math.max(1, Math.ceil(s / 60)) + ' мин';
}

export function cleanNick(s) {
  return String(s || '').replace(/[\u0000-\u001f<>&"']/g, '').replace(/\s+/g, ' ').trim().slice(0, 14);
}
export const loadNick = () => cleanNick(get(KEY_NICK) || '');
export const saveNick = (n) => set(KEY_NICK, cleanNick(n));

// { nick, cp: индекс последнего чекпоинта (-1 — старт), t: секунды, maxH }
export function loadSave() {
  try {
    const o = JSON.parse(get(KEY_SAVE) || 'null');
    if (!o || typeof o.t !== 'number') return null;
    return { nick: cleanNick(o.nick), cp: Math.max(-1, Math.min(6, o.cp | 0)), t: Math.max(0, o.t), maxH: Math.max(0, +o.maxH || 0), ch: !!o.ch };
  } catch { return null; }
}
export const writeSave = (s) => set(KEY_SAVE, JSON.stringify(s));
export const clearSave = () => del(KEY_SAVE);

function localBoard() {
  try {
    const a = JSON.parse(get(KEY_LB) || '[]');
    return Array.isArray(a) ? a.filter((e) => e && typeof e.t === 'number') : [];
  } catch { return []; }
}
const sortTop = (a) => a.slice().sort((x, y) => x.t - y.t).slice(0, 10);

export async function fetchBoard() {
  const local = sortTop(localBoard());
  if (!API) return local;
  try {
    const r = await fetch(API.replace(/\/$/, '') + '/api/leaderboard', { cache: 'no-store' });
    if (!r.ok) throw new Error(String(r.status));
    const remote = await r.json();
    return sortTop(remote.map((e) => ({ name: cleanNick(e.name), t: +e.t, id: String(e.id || '') })).filter((e) => e.name && e.t > 0));
  } catch { return local; }
}

// Возвращает место в топе (1..10) или 0
export async function submitScore(name, t) {
  const id = getPlayerId();
  let all = localBoard();
  const mine = all.find((e) => e.id === id);
  if (!mine) all.push({ name, t, id, d: Date.now() });
  else if (t < mine.t) { mine.t = t; mine.name = name; mine.d = Date.now(); } // у одного ID — только лучший результат
  else if (mine.name !== name) mine.name = name;
  set(KEY_LB, JSON.stringify(sortTop(all)));
  if (API) {
    try {
      await fetch(API.replace(/\/$/, '') + '/api/score', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, t, id }),
      });
    } catch { /* офлайн — останется только локальная запись */ }
  }
  const board = await fetchBoard();
  const i = board.findIndex((e) => (e.id ? e.id === id : e.name === name) && e.t <= t + 0.01);
  return i >= 0 ? i + 1 : 0;
}

export function fmtTime(t, cs = true) {
  const m = Math.floor(t / 60), s = t - m * 60;
  const sec = cs ? s.toFixed(2).padStart(5, '0') : Math.floor(s).toString().padStart(2, '0');
  return String(m).padStart(2, '0') + ':' + sec;
}
